#!/usr/bin/env python3
"""h1hunter builder — Part 4c of 4 (final).

Adds: tests/ (fixtures + unit + integration) and zip_it.py.
Idempotent.
"""
from pathlib import Path

ROOT = Path("h1hunter")

def w(rel: str, content: str) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if content.startswith("\n"):
        content = content[1:]
    p.write_text(content, encoding="utf-8")
    print(f"  wrote {rel}")

if not ROOT.exists():
    raise SystemExit("ERROR: ./h1hunter/ not found. Run build1-4b first.")

print(f"Extending {ROOT.resolve()}")

# ===========================================================================
# tests/__init__.py, unit/__init__.py, integration/__init__.py
# ===========================================================================
w("tests/__init__.py", "")
w("tests/unit/__init__.py", "")
w("tests/integration/__init__.py", "")

# ===========================================================================
# tests/conftest.py
# ===========================================================================
w("tests/conftest.py", r'''
"""Shared pytest fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def sample_scope_yaml() -> str:
    return (FIXTURES / "sample_scope.yaml").read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def sample_scope_path() -> Path:
    return FIXTURES / "sample_scope.yaml"
''')

# ===========================================================================
# tests/fixtures/
# ===========================================================================
w("tests/fixtures/sample_scope.yaml", r'''
program:
  name: example-program
  policy_reviewed: true
  policy_url: https://hackerone.com/example-program
  authorized_by: researcher@example.test

allowed:
  - "*.example.com"
  - "example.org"
  - "https://api.example.net/v1"
  - "203.0.113.10"
  - "198.51.100.0/24"

excluded:
  - "admin.example.com"
  - "*.internal.example.com"

settings:
  passive_recon: true
  active_checks: true
  max_concurrency: 3
  requests_per_second: 2
  timeout_seconds: 10
  max_requests: 100
  max_response_bytes: 262144
  allow_private_networks: false
''')

w("tests/fixtures/passive_assets.json", r'''
{
  "assets": [
    {"hostname": "WWW.Example.COM.", "discovered_at": "2025-01-01T00:00:00Z",
     "metadata": {"tags": ["ct-log"]}},
    {"hostname": "api.example.com", "discovered_at": "2025-02-01T00:00:00Z",
     "dns_records": {"A": ["203.0.113.10"]}, "metadata": {"tags": ["api"]}},
    {"hostname": "admin.example.com"},
    "mail.example.com"
  ]
}
''')

w("tests/fixtures/passive_hosts.txt", r'''
# Curated seed list — comments allowed anywhere.

www.example.com
api.example.com      # trailing comment
mail.example.com

# Duplicate below should collapse during dedup.
WWW.EXAMPLE.COM.
''')

# ===========================================================================
# tests/unit/test_scope_parser.py
# ===========================================================================
w("tests/unit/test_scope_parser.py", r'''
"""Scope entry and scope document parsing."""

from __future__ import annotations

import pytest

from h1hunter.exceptions import ScopeParseError
from h1hunter.models.scope import EntryKind
from h1hunter.scope.parser import parse_scope_entry, parse_scope_text


@pytest.mark.parametrize(
    ("raw", "kind", "host"),
    [
        ("example.com", EntryKind.DOMAIN, "example.com"),
        ("EXAMPLE.COM.", EntryKind.DOMAIN, "example.com"),
        ("sub.example.com", EntryKind.DOMAIN, "sub.example.com"),
        ("*.example.com", EntryKind.WILDCARD, "example.com"),
        ("*.EXAMPLE.com.", EntryKind.WILDCARD, "example.com"),
        ("https://api.example.com/v1", EntryKind.URL, "api.example.com"),
        ("203.0.113.5", EntryKind.IP, "203.0.113.5"),
        ("198.51.100.0/24", EntryKind.CIDR, None),
        ("2001:db8::/32", EntryKind.CIDR, None),
    ],
)
def test_parse_scope_entry_accepts_valid_forms(raw, kind, host):
    entry = parse_scope_entry(raw)
    assert entry.kind is kind
    if host is not None:
        assert entry.host == host


@pytest.mark.parametrize(
    "raw",
    ["", "   ", "*", "*.*", "*.", "foo.*.example.com", "example.*",
     "exa mple.com", "http://", "ftp://example.com", "example.com/path",
     "localhost", "example..com"],
)
def test_parse_scope_entry_rejects_invalid_forms(raw):
    with pytest.raises(ScopeParseError):
        parse_scope_entry(raw)


def test_url_entry_captures_scheme_port_and_path():
    entry = parse_scope_entry("https://api.example.net:8443/v2/")
    assert entry.kind is EntryKind.URL
    assert entry.scheme == "https"
    assert entry.port == 8443
    assert entry.path_prefix == "/v2"


def test_parse_scope_text_full_document(sample_scope_yaml):
    scope = parse_scope_text(sample_scope_yaml)
    assert scope.program.name == "example-program"
    assert scope.program.policy_reviewed is True
    assert len(scope.allowed) == 5
    assert len(scope.excluded) == 2


def test_scope_without_allowed_entries_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("program:\n  name: x\nallowed: []\n")


def test_scope_without_program_section_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("allowed:\n  - example.com\n")


def test_scope_with_non_list_allowed_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("program:\n  name: x\nallowed: 'example.com'\n")


def test_scope_with_invalid_settings_is_rejected():
    text = (
        "program:\n  name: x\nallowed:\n  - example.com\n"
        "settings:\n  max_concurrency: 9999\n"
    )
    with pytest.raises(ScopeParseError):
        parse_scope_text(text)


def test_empty_scope_document_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("")
''')

# ===========================================================================
# tests/unit/test_scope_matcher.py
# ===========================================================================
w("tests/unit/test_scope_matcher.py", r'''
"""Scope entry matching rules, including lookalike-host rejection."""

from __future__ import annotations

from h1hunter.scope.matcher import entry_matches
from h1hunter.scope.parser import parse_scope_entry
from h1hunter.utils.normalization import parse_target


def _m(entry_raw, target_raw):
    return entry_matches(parse_scope_entry(entry_raw), parse_target(target_raw))


def test_exact_domain_rejects_lookalikes():
    assert _m("example.com", "example.com")
    assert not _m("example.com", "example.com.attacker.test")
    assert not _m("example.com", "notexample.com")
    assert not _m("example.com", "www.example.com")


def test_wildcard_excludes_apex_and_rejects_lookalikes():
    assert _m("*.example.com", "www.example.com")
    assert _m("*.example.com", "a.b.example.com")
    assert not _m("*.example.com", "example.com")
    assert not _m("*.example.com", "example.com.attacker.test")
    assert not _m("*.example.com", "attacker-example.com")


def test_wildcard_case_and_trailing_dot_insensitive():
    assert _m("*.example.com", "WWW.Example.COM.")
    assert _m("EXAMPLE.com", "example.com.")


def test_url_entry_requires_scheme_host_and_path_prefix():
    entry = "https://api.example.net/v1"
    assert _m(entry, "https://api.example.net/v1")
    assert _m(entry, "https://api.example.net/v1/users")
    assert not _m(entry, "https://api.example.net/v1beta/users")
    assert not _m(entry, "http://api.example.net/v1/users")
    assert not _m(entry, "https://api.example.net:8443/v1")


def test_cidr_entry_matches_only_literal_ips():
    entry = "198.51.100.0/24"
    assert _m(entry, "198.51.100.7")
    assert not _m(entry, "198.51.101.7")
    assert not _m(entry, "example.com")


def test_ip_entry_is_exact():
    assert _m("203.0.113.10", "203.0.113.10")
    assert not _m("203.0.113.10", "203.0.113.11")


def test_ipv6_cidr_does_not_match_ipv4():
    assert not _m("2001:db8::/32", "198.51.100.1")
    assert _m("2001:db8::/32", "2001:db8::1")
''')

# ===========================================================================
# tests/unit/test_scope_validator.py
# ===========================================================================
w("tests/unit/test_scope_validator.py", r'''
"""ScopeValidator: exclusion precedence, default deny, active-test gating."""

from __future__ import annotations

import pytest

from h1hunter.exceptions import ScopeNotReviewedError, ScopeViolation
from h1hunter.scope.parser import parse_scope_text
from h1hunter.scope.validator import ScopeValidator

BASE_SCOPE = """
program:
  name: conflict
  policy_reviewed: true
allowed:
  - "*.example.com"
  - "example.org"
excluded:
  - "example.org"
  - "admin.example.com"
settings:
  active_checks: true
"""


@pytest.fixture
def validator():
    return ScopeValidator(parse_scope_text(BASE_SCOPE))


def test_exclusion_wins_over_wildcard(validator):
    decision = validator.evaluate("admin.example.com")
    assert decision.allowed is False
    assert "exclusion" in decision.reason
    assert decision.matched_rule == "admin.example.com"


def test_exclusion_wins_over_exact(validator):
    assert validator.evaluate("example.org").allowed is False
    assert validator.evaluate("www.example.com").allowed is True


def test_unmatched_denied(validator):
    decision = validator.evaluate("evil.test")
    assert decision.allowed is False
    assert "does not match any allowed scope entry" in decision.reason


def test_malformed_target_denied(validator):
    decision = validator.evaluate("http://")
    assert decision.allowed is False
    assert decision.normalized_host is None


def test_require_raises_for_out_of_scope(validator):
    with pytest.raises(ScopeViolation):
        validator.require("evil.test")


def test_require_returns_parsed_target_when_allowed(validator):
    parsed = validator.require("https://www.example.com/path")
    assert parsed.host == "www.example.com"


def test_active_requires_reviewed_policy():
    text = BASE_SCOPE.replace("policy_reviewed: true", "policy_reviewed: false")
    v = ScopeValidator(parse_scope_text(text))
    with pytest.raises(ScopeNotReviewedError):
        v.require_active_authorization()


def test_active_requires_opt_in():
    text = BASE_SCOPE.replace("active_checks: true", "active_checks: false")
    v = ScopeValidator(parse_scope_text(text))
    with pytest.raises(ScopeNotReviewedError):
        v.require_active_authorization()
''')

# ===========================================================================
# tests/unit/test_rate_limiter.py
# ===========================================================================
w("tests/unit/test_rate_limiter.py", r'''
"""Deterministic token-bucket tests using an injected clock and sleep."""

from __future__ import annotations

import pytest

from h1hunter.engine.rate_limiter import TokenBucketRateLimiter


class FakeClock:
    def __init__(self): self.now = 0.0
    def __call__(self): return self.now
    def advance(self, d): self.now += d


def _build(rate, capacity):
    clock = FakeClock()
    slept: list[float] = []

    async def fake_sleep(delay):
        slept.append(delay); clock.advance(delay)

    return TokenBucketRateLimiter(
        rate, capacity=capacity, clock=clock, sleep=fake_sleep,
    ), clock, slept


async def test_burst_does_not_sleep():
    lim, _, slept = _build(2.0, 2.0)
    await lim.acquire(); await lim.acquire()
    assert slept == []


async def test_exhausted_bucket_waits():
    lim, _, slept = _build(2.0, 1.0)
    await lim.acquire()
    assert slept == []
    await lim.acquire()
    assert slept == [0.5]


async def test_rate_is_enforced():
    lim, _, slept = _build(4.0, 1.0)
    for _ in range(4):
        await lim.acquire()
    assert slept == [0.25, 0.25, 0.25]


def test_zero_rate_rejected():
    with pytest.raises(ValueError):
        TokenBucketRateLimiter(rate=0)


def test_negative_capacity_rejected():
    with pytest.raises(ValueError):
        TokenBucketRateLimiter(rate=1.0, capacity=-1)


async def test_over_capacity_rejected():
    lim, _, _ = _build(5.0, 2.0)
    with pytest.raises(ValueError):
        await lim.acquire(5.0)


async def test_non_positive_token_rejected():
    lim, _, _ = _build(5.0, 2.0)
    with pytest.raises(ValueError):
        await lim.acquire(0)
''')

# ===========================================================================
# tests/unit/test_finding_models.py
# ===========================================================================
w("tests/unit/test_finding_models.py", r'''
"""Finding model validation, ID stability, dedup key."""

from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)


def _finding(**overrides):
    base = dict(
        id="abc123",
        title="Test finding",
        category="missing_header:csp",
        affected_asset="https://www.example.com/",
        detection_module="headers",
    )
    base.update(overrides)
    return Finding(**base)


def test_defaults_are_conservative():
    f = _finding()
    assert f.severity is SeverityLevel.INFO
    assert f.confidence is ConfidenceLevel.LOW
    assert f.verification_status is VerificationStatus.UNVERIFIED
    assert f.scope_validation == "unvalidated"


def test_naive_timestamp_coerced():
    f = _finding(discovered_at=datetime(2025, 1, 1))
    assert f.discovered_at.tzinfo is not None


def test_frozen():
    f = _finding()
    with pytest.raises(ValidationError):
        f.title = "new"


def test_empty_title_rejected():
    with pytest.raises(ValidationError):
        _finding(title="")


def test_extra_fields_rejected():
    with pytest.raises(ValidationError):
        Finding(  # type: ignore[call-arg]
            id="x", title="t", category="c", affected_asset="a",
            detection_module="m", surprise="nope",
        )


def test_make_id_stable_and_content_derived():
    a = Finding.make_id(module="m", category="c", asset="a", endpoint="e")
    b = Finding.make_id(module="m", category="c", asset="a", endpoint="e")
    c = Finding.make_id(module="m", category="c", asset="a", endpoint="different")
    assert a == b
    assert a != c


def test_dedup_key_shape():
    f = _finding(affected_endpoint="csp")
    assert f.dedup_key() == (
        "https://www.example.com/", "missing_header:csp", "csp", "headers",
    )


def test_severity_rank_ordering():
    assert SeverityLevel.INFO.rank < SeverityLevel.LOW.rank
    assert SeverityLevel.LOW.rank < SeverityLevel.MEDIUM.rank
    assert SeverityLevel.MEDIUM.rank < SeverityLevel.HIGH.rank
    assert SeverityLevel.HIGH.rank < SeverityLevel.CRITICAL.rank
''')

# ===========================================================================
# tests/unit/test_severity.py
# ===========================================================================
w("tests/unit/test_severity.py", r'''
"""Severity helpers."""

from __future__ import annotations

from h1hunter.models.finding import SeverityLevel
from h1hunter.reporting.severity import (
    merge_severity, missing_header_severity, severity_order,
)


def test_hsts_is_low_with_rationale():
    level, rationale = missing_header_severity("strict-transport-security")
    assert level is SeverityLevel.LOW
    assert rationale


def test_csp_is_low():
    assert missing_header_severity("content-security-policy")[0] is SeverityLevel.LOW


def test_xcto_and_referrer_are_info():
    assert missing_header_severity("x-content-type-options")[0] is SeverityLevel.INFO
    assert missing_header_severity("referrer-policy")[0] is SeverityLevel.INFO


def test_unknown_header_is_info_with_named_rationale():
    level, rationale = missing_header_severity("x-unknown")
    assert level is SeverityLevel.INFO
    assert "x-unknown" in rationale


def test_case_insensitive_lookup():
    assert missing_header_severity("Content-Security-Policy")[0] is SeverityLevel.LOW


def test_severity_order_monotonic():
    levels = [
        SeverityLevel.INFO, SeverityLevel.LOW, SeverityLevel.MEDIUM,
        SeverityLevel.HIGH, SeverityLevel.CRITICAL,
    ]
    ranks = [severity_order(l) for l in levels]
    assert ranks == sorted(ranks)


def test_merge_returns_higher():
    assert merge_severity(SeverityLevel.LOW, SeverityLevel.HIGH) is SeverityLevel.HIGH
    assert merge_severity(SeverityLevel.INFO, SeverityLevel.INFO) is SeverityLevel.INFO
''')

# ===========================================================================
# tests/integration/test_safety_regression.py
# ===========================================================================
w("tests/integration/test_safety_regression.py", r'''
"""Safety regression suite — run with ``pytest -q -m safety``.

These tests prove the controls that make active scanning safe to run:
scope enforcement, destination policy, budget, kill switch, redaction,
dry-run planning. Every test uses mocks. No test opens a socket.
"""

from __future__ import annotations

import logging

import pytest

from h1hunter import cli
from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, DestinationBlocked, KillSwitchEngaged, SafetyError,
    ScopeParseError, ScopeViolation,
)
from h1hunter.logging_config import REDACTED, configure_logging
from h1hunter.scope.parser import load_scope_file, parse_scope_text

pytestmark = pytest.mark.safety

ACTIVE_SCOPE = """
program:
  name: safety-regression
  policy_reviewed: true
allowed:
  - "*.example.com"
  - "example.org"
excluded:
  - "admin.example.com"
  - "example.org"
settings:
  active_checks: true
  max_requests: 3
  requests_per_second: 1000
  allow_private_networks: false
"""


class RecordingClient:
    """Stand-in for the HTTP client. Records every call."""

    def __init__(self): self.calls = []
    async def get(self, url): self.calls.append(url); return "response"


def _engine(t): return SafetyEngine.from_scope(parse_scope_text(t))


async def _guarded_get(engine, client, url):
    await engine.authorize(url)
    return await client.get(url)


@pytest.fixture
def restore_logging():
    root = logging.getLogger()
    saved_handlers = root.handlers[:]
    saved_level = root.level
    yield
    for h in root.handlers[:]:
        root.removeHandler(h); h.close()
    root.handlers[:] = saved_handlers
    root.setLevel(saved_level)


# ----------------------------------------------------- scope enforcement boundary


async def test_out_of_scope_host_never_reaches_client():
    engine = _engine(ACTIVE_SCOPE)
    client = RecordingClient()
    with pytest.raises(ScopeViolation):
        await _guarded_get(engine, client, "https://attacker.test/")
    assert client.calls == []
    assert engine.requests_made == 0


async def test_lookalike_host_never_reaches_client():
    engine = _engine(ACTIVE_SCOPE)
    client = RecordingClient()
    for hostile in (
        "https://example.com.attacker.test/",
        "https://notexample.com/",
        "https://example.org.attacker.test/",
    ):
        with pytest.raises(ScopeViolation):
            await _guarded_get(engine, client, hostile)
    assert client.calls == []


async def test_excluded_rejected_even_though_wildcard_allows():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://admin.example.com/")
    assert engine.requests_made == 0


async def test_excluded_rejected_even_though_exact_allows():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://example.org/")
    assert engine.requests_made == 0


# ------------------------------------------------------- missing / invalid scope


def test_missing_scope_file_prevents_active(tmp_path):
    with pytest.raises(ScopeParseError):
        load_scope_file(tmp_path / "does-not-exist.yaml")


def test_invalid_scope_fails_closed(tmp_path):
    bad = tmp_path / "scope.yaml"
    bad.write_text("program:\n  name: x\nallowed: 'not-a-list'\n", encoding="utf-8")
    with pytest.raises(ScopeParseError):
        load_scope_file(bad)


def test_scope_without_allowed_fails_closed(tmp_path):
    bad = tmp_path / "scope.yaml"
    bad.write_text("program:\n  name: x\nallowed: []\n", encoding="utf-8")
    with pytest.raises(ScopeParseError):
        load_scope_file(bad)


async def test_unreviewed_policy_prevents_active():
    text = ACTIVE_SCOPE.replace("policy_reviewed: true", "policy_reviewed: false")
    engine = _engine(text)
    assert engine.policy.active_checks is False
    with pytest.raises(SafetyError):
        await engine.authorize("https://www.example.com/")


async def test_disabled_active_prevents_active():
    text = ACTIVE_SCOPE.replace("active_checks: true", "active_checks: false")
    engine = _engine(text)
    assert engine.policy.active_checks is False
    with pytest.raises(SafetyError):
        await engine.authorize("https://www.example.com/")


# ------------------------------------------------------------------ destinations


def test_private_and_metadata_blocked_by_default():
    engine = _engine(ACTIVE_SCOPE)
    for blocked in (
        "127.0.0.1", "::1", "10.0.0.1", "192.168.1.1", "169.254.169.254",
    ):
        with pytest.raises(DestinationBlocked):
            engine.check_destination(blocked)
    engine.check_destination("93.184.216.34")  # must not raise


# ---------------------------------------------------------- budget and kill switch


async def test_budget_enforced():
    engine = _engine(ACTIVE_SCOPE)  # max_requests: 3
    for _ in range(3):
        await engine.authorize("https://www.example.com/")
    assert engine.budget_remaining == 0
    with pytest.raises(BudgetExhausted):
        await engine.authorize("https://www.example.com/")


async def test_denied_targets_do_not_consume_budget():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://attacker.test/")
    assert engine.requests_made == 0
    assert engine.budget_remaining == 3


async def test_kill_switch_prevents_new_requests():
    engine = _engine(ACTIVE_SCOPE)
    await engine.authorize("https://www.example.com/")
    engine.kill("operator stop")
    assert engine.is_killed is True
    with pytest.raises(KillSwitchEngaged):
        await engine.authorize("https://www.example.com/")


async def test_audit_trail_records_decisions():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://attacker.test/")
    await engine.authorize("https://www.example.com/")
    engine.kill("done")
    actions = [e.action for e in engine.audit_log]
    assert "authorize" in actions
    assert "kill_switch" in actions


# -------------------------------------------------------------------- redaction


def test_sensitive_values_never_reach_the_log_file(tmp_path, restore_logging):
    log_file = tmp_path / "h1hunter.jsonl"
    configure_logging(level="INFO", fmt="json", file=str(log_file), no_color=True)
    logging.getLogger("h1hunter.test").info("Authorization: Bearer leak-me-please")
    for h in logging.getLogger().handlers:
        h.flush()
    contents = log_file.read_text(encoding="utf-8")
    assert "leak-me-please" not in contents
    assert REDACTED in contents


# ------------------------------------------------------------------ dry run / CLI


def test_dry_run_plan_sends_no_traffic(tmp_path, capsys):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "plan", "--file", str(scope_path),
        "--targets", "https://www.example.com", "https://attacker.test",
    ])
    out = capsys.readouterr().out
    assert code == cli.EXIT_OK
    assert "no network traffic" in out.lower()
    assert "ALLOW" in out and "DENY" in out


def test_scope_check_returns_denied_exit_code(tmp_path, capsys):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "scope", "check", "--file", str(scope_path),
        "--target", "https://attacker.test",
    ])
    assert code == cli.EXIT_DENIED


def test_scope_check_returns_ok_for_in_scope(tmp_path):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "scope", "check", "--file", str(scope_path),
        "--target", "https://www.example.com",
    ])
    assert code == cli.EXIT_OK


def test_missing_scope_file_yields_usage_error(tmp_path):
    code = cli.main(["scope", "validate", "--file", str(tmp_path / "nope.yaml")])
    assert code == cli.EXIT_USAGE
''')

# ===========================================================================
# tests/integration/test_recon_pipeline.py
# ===========================================================================
w("tests/integration/test_recon_pipeline.py", r'''
"""Passive and active reconnaissance end-to-end with mocked transports."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from h1hunter.engine.safety import SafetyEngine
from h1hunter.recon.http_probe import HttpProber
from h1hunter.recon.passive import PassiveReconEngine
from h1hunter.recon.providers.file_source import FileSource
from h1hunter.recon.providers.text_source import TextSource
from h1hunter.recon.runner import run_concurrently
from h1hunter.scope.parser import parse_scope_text

pytestmark = pytest.mark.safety

FIXTURES = Path(__file__).parent.parent / "fixtures"

SCOPE_ACTIVE = """
program:
  name: recon-integration
  policy_reviewed: true
allowed:
  - "*.example.com"
excluded:
  - "admin.example.com"
settings:
  active_checks: true
  requests_per_second: 1000
  max_requests: 10
  max_concurrency: 2
  max_response_bytes: 512
"""


class StubResolver:
    async def resolve(self, hostname, record_type):
        return ["93.184.216.34"] if record_type == "A" else []


# ------------------------------------------------------------- passive pipeline


async def test_passive_aggregates_and_dedupes():
    file_source = FileSource("json-fixture", FIXTURES / "passive_assets.json")
    text_source = TextSource("text-fixture", FIXTURES / "passive_hosts.txt")
    result = await PassiveReconEngine([file_source, text_source]).run()

    hostnames = {a.hostname for a in result.assets}
    assert {"www.example.com", "api.example.com",
            "admin.example.com", "mail.example.com"} <= hostnames

    www = next(a for a in result.assets if a.hostname == "www.example.com")
    assert set(www.metadata["sources"]) == {"json-fixture", "text-fixture"}


async def test_passive_leaves_assets_unvalidated_without_validator():
    source = TextSource("fixture", FIXTURES / "passive_hosts.txt")
    result = await PassiveReconEngine([source]).run()
    assert all(a.scope_status.value == "unvalidated" for a in result.assets)


async def test_passive_annotates_without_authorizing():
    source = TextSource("fixture", FIXTURES / "passive_hosts.txt")
    engine = PassiveReconEngine([source])
    result = await engine.run()
    by_host = {a.hostname: a for a in result.assets}
    # Annotation is not performed without a validator — status stays unvalidated.
    assert by_host["www.example.com"].scope_status.value == "unvalidated"


async def test_passive_records_failing_source_without_aborting(tmp_path: Path):
    good = TextSource("good", FIXTURES / "passive_hosts.txt")
    bad = TextSource("bad", tmp_path / "does-not-exist.txt")
    result = await PassiveReconEngine([good, bad]).run()
    assert "good" in result.sources_run
    assert any(name == "bad" for name, _ in result.sources_failed)
    assert result.assets


# -------------------------------------------------------------- active pipeline


async def test_active_pipeline_mixes_in_and_out_of_scope():
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE_ACTIVE))
    resolver = StubResolver()
    hits: list[str] = []

    def handler(request):
        hits.append(str(request.url))
        return httpx.Response(200, content=b"ok", request=request)

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        prober = HttpProber(engine, client, resolver)
        urls = [
            "https://www.example.com/",
            "https://attacker.test/",
            "https://api.example.com/v1",
            "https://admin.example.com/",
        ]
        results = await run_concurrently(
            urls, prober.probe, engine.policy.max_concurrency,
        )

    by_url = {r.url: r for r in results}
    assert by_url["https://www.example.com/"].error is None
    assert by_url["https://api.example.com/v1"].error is None
    assert by_url["https://attacker.test/"].error is not None
    assert by_url["https://admin.example.com/"].error is not None
    assert set(hits) == {
        "https://www.example.com/", "https://api.example.com/v1",
    }


async def test_redirect_chain_revalidation():
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE_ACTIVE))
    resolver = StubResolver()
    hops: list[str] = []

    def handler(request):
        hops.append(str(request.url))
        if request.url.path == "/start":
            return httpx.Response(
                302,
                headers={"location": "https://api.example.com/middle"},
                request=request,
            )
        if request.url.path == "/middle":
            return httpx.Response(
                302,
                headers={"location": "https://attacker.test/final"},
                request=request,
            )
        return httpx.Response(200, request=request)

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        result = await HttpProber(engine, client, resolver).probe(
            "https://www.example.com/start"
        )

    assert hops == [
        "https://www.example.com/start",
        "https://api.example.com/middle",
    ]
    assert result.redirects[0].refused is False
    assert result.redirects[1].refused is True
    assert "redirect refused" in (result.error or "")
''')

# ===========================================================================
# tests/integration/test_active_checks.py
# ===========================================================================
w("tests/integration/test_active_checks.py", r'''
"""Security-check pipeline with mocked transports. No sockets."""

from __future__ import annotations

import httpx
import pytest

from h1hunter.checks.base import CheckContext
from h1hunter.checks.headers import INSPECTED_HEADERS, HeadersCheck
from h1hunter.engine.safety import SafetyEngine
from h1hunter.models.finding import SeverityLevel
from h1hunter.recon.http_probe import HttpProber
from h1hunter.scope.parser import parse_scope_text
from h1hunter.utils.deduplication import deduplicate_findings

pytestmark = pytest.mark.safety

SCOPE = """
program:
  name: checks
  policy_reviewed: true
allowed:
  - "*.example.com"
settings:
  active_checks: true
  requests_per_second: 1000
  max_requests: 20
  max_response_bytes: 4096
"""


class StubResolver:
    async def resolve(self, hostname, record_type):
        return ["93.184.216.34"] if record_type == "A" else []


def _ctx(handler):
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE))
    client = httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    )
    return CheckContext(engine=engine, client=client, resolver=StubResolver())


async def test_all_headers_present_no_findings():
    def handler(request):
        return httpx.Response(
            200, content=b"ok",
            headers={
                "Content-Security-Policy": "default-src 'self'",
                "Strict-Transport-Security": "max-age=31536000",
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer",
                "Permissions-Policy": "geolocation=()",
            },
            request=request,
        )

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)
    assert findings == []


async def test_missing_headers_produce_one_finding_each():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)

    assert {f.affected_endpoint for f in findings} == set(INSPECTED_HEADERS)


async def test_hsts_not_flagged_on_http():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("http://www.example.com/", ctx)
    assert "strict-transport-security" not in {f.affected_endpoint for f in findings}


async def test_csp_severity_is_low():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)

    csp = next(f for f in findings if f.affected_endpoint == "content-security-policy")
    assert csp.severity is SeverityLevel.LOW
    assert csp.severity_rationale


async def test_out_of_scope_produces_no_findings():
    def handler(request):
        return httpx.Response(200, request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://attacker.test/", ctx)
    assert findings == []


async def test_evidence_never_contains_body():
    def handler(request):
        return httpx.Response(200, content=b"very-secret-marker", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)
    for f in findings:
        assert "very-secret-marker" not in str(f.evidence)


async def test_findings_are_deduplicated():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE))
    resolver = StubResolver()
    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        ctx = CheckContext(engine=engine, client=client, resolver=resolver)
        check = HeadersCheck(HttpProber(engine, client, resolver))
        a = await check.run("https://www.example.com/", ctx)
        b = await check.run("https://www.example.com/", ctx)
    merged = deduplicate_findings(a + b)
    assert len(merged) == len(a)
''')

# ===========================================================================
# tests/integration/test_reporting.py
# ===========================================================================
w("tests/integration/test_reporting.py", r'''
"""JSON, CSV, Markdown exports round-trip and refuse to overwrite."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from h1hunter import cli
from h1hunter.exceptions import StorageError
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.reporting import (
    read_findings_json, render_findings_markdown,
    write_findings_csv, write_findings_json, write_findings_markdown,
)


def _finding(fid, **overrides):
    base = dict(
        id=fid,
        title=f"Test finding {fid}",
        category="missing_header:csp",
        affected_asset="https://www.example.com/",
        affected_endpoint="content-security-policy",
        detection_module="headers",
        confidence=ConfidenceLevel.HIGH,
        severity=SeverityLevel.LOW,
        severity_rationale="rationale text",
        potential_impact="impact text",
        remediation="remediation text",
        reproduction="repro steps",
        evidence={"status_code": 200},
        scope_validation="in_scope",
        discovered_at=datetime(2025, 1, 1, tzinfo=timezone.utc),
    )
    base.update(overrides)
    return Finding(**base)


def test_json_round_trip(tmp_path: Path):
    target = tmp_path / "findings.json"
    original = [_finding("a"), _finding("b", severity=SeverityLevel.MEDIUM)]
    write_findings_json(original, target)
    loaded = read_findings_json(target)
    assert {f.id for f in loaded} == {"a", "b"}
    # Ordered by severity descending.
    assert loaded[0].severity is SeverityLevel.MEDIUM


def test_json_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "findings.json"
    target.write_text("[]", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_json([_finding("a")], target)


def test_csv_columns_and_values(tmp_path: Path):
    target = tmp_path / "findings.csv"
    write_findings_csv([_finding("a")], target)
    with target.open(encoding="utf-8", newline="") as h:
        rows = list(csv.DictReader(h))
    assert len(rows) == 1
    row = rows[0]
    assert row["id"] == "a"
    assert row["severity"] == "low"
    assert row["confidence"] == "high"
    assert row["verification_status"] == "unverified"


def test_csv_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "findings.csv"
    target.write_text("x", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_csv([_finding("a")], target)


def test_markdown_contains_authorization_notice():
    text = render_findings_markdown([_finding("a")], program_name="example")
    assert "Authorization notice" in text
    assert "[LOW]" in text
    assert "example" in text


def test_markdown_summary_counts_severities():
    findings = [
        _finding("a", severity=SeverityLevel.MEDIUM),
        _finding("b"),
        _finding("c"),
    ]
    text = render_findings_markdown(findings, program_name="p")
    assert "| medium | 1 |" in text
    assert "| low | 2 |" in text


def test_markdown_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "f.md"
    target.write_text("x", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_markdown([_finding("a")], target, program_name="p")


def test_markdown_shows_verification_status():
    text = render_findings_markdown([
        _finding("a", verification_status=VerificationStatus.REQUIRES_INVESTIGATION)
    ])
    assert "requires_investigation" in text


# --------------------------------------------------------------- report CLI


def _seed_findings(tmp_path: Path) -> Path:
    src = tmp_path / "findings.json"
    write_findings_json([_finding("a"), _finding("b")], src)
    return src


def test_cli_report_markdown(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.md"
    code = cli.main([
        "report", "--input", str(src), "--format", "markdown",
        "--output", str(out),
    ])
    assert code == cli.EXIT_OK
    assert "Authorization notice" in out.read_text(encoding="utf-8")


def test_cli_report_csv(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.csv"
    code = cli.main([
        "report", "--input", str(src), "--format", "csv", "--output", str(out),
    ])
    assert code == cli.EXIT_OK
    assert out.exists()


def test_cli_report_refuses_overwrite(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.md"
    out.write_text("existing", encoding="utf-8")
    code = cli.main([
        "report", "--input", str(src), "--format", "markdown",
        "--output", str(out),
    ])
    assert code == cli.EXIT_USAGE


def test_cli_report_missing_input(tmp_path: Path):
    code = cli.main([
        "report", "--input", str(tmp_path / "missing.json"),
        "--format", "markdown",
    ])
    assert code == cli.EXIT_USAGE
''')

print("\nPart 4c complete. All source and test files written.")
print("Run `python3 zip_it.py` (next step) to build h1hunter-phase1-4.zip.")
