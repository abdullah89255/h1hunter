#!/usr/bin/env bash
# package_h1hunter.sh — produce h1hunter-phase1-4.zip from ./h1hunter/
set -euo pipefail

SRC="h1hunter"
OUT="h1hunter-phase1-4.zip"
STAGE=".package_stage"

if [[ ! -d "$SRC" ]]; then
    echo "ERROR: directory '$SRC' not found. Run build_h1hunter.sh first." >&2
    exit 1
fi

# --- 1. Clean any local artifacts that must not ship -------------------------
find "$SRC" -type d -name '__pycache__'      -prune -exec rm -rf {} +
find "$SRC" -type d -name '.pytest_cache'    -prune -exec rm -rf {} +
find "$SRC" -type d -name '.mypy_cache'      -prune -exec rm -rf {} +
find "$SRC" -type d -name '.ruff_cache'      -prune -exec rm -rf {} +
find "$SRC" -type d -name '.venv'            -prune -exec rm -rf {} +
find "$SRC" -type d -name 'venv'             -prune -exec rm -rf {} +
find "$SRC" -type f -name '*.pyc'            -delete
find "$SRC" -type f -name '*.pyo'            -delete
find "$SRC" -type f -name '*.sqlite3'        -delete
find "$SRC" -type d -name 'output'           -prune -exec rm -rf {} +
find "$SRC" -type d -name 'logs'             -prune -exec rm -rf {} +
rm -f "$SRC/.env" "$SRC/config/config.yaml" "$SRC/config/scope.yaml"

# --- 2. Fail hard if any secret-shaped file slipped through ------------------
if find "$SRC" -type f \( -name '*.pem' -o -name '*.key' -o -name 'id_rsa*' \) | grep -q .; then
    echo "ERROR: key material found in $SRC; refusing to package." >&2
    exit 1
fi

# --- 3. Verify the required project structure --------------------------------
required=(
    "pyproject.toml" "README.md" "LICENSE" ".gitignore" ".env.example"
    "config/config.example.yaml" "config/scope.example.yaml"
    "docs/architecture.md" "docs/scope_safety.md" "docs/usage.md"
    "src/h1hunter/__init__.py" "src/h1hunter/cli.py" "src/h1hunter/main.py"
    "src/h1hunter/config.py" "src/h1hunter/logging_config.py" "src/h1hunter/exceptions.py"
    "src/h1hunter/models/scope.py" "src/h1hunter/models/asset.py" "src/h1hunter/models/finding.py"
    "src/h1hunter/scope/parser.py" "src/h1hunter/scope/matcher.py" "src/h1hunter/scope/validator.py"
    "src/h1hunter/engine/rate_limiter.py" "src/h1hunter/engine/safety.py"
    "src/h1hunter/recon/passive.py" "src/h1hunter/recon/dns.py" "src/h1hunter/recon/http_probe.py"
    "src/h1hunter/recon/runner.py" "src/h1hunter/recon/registry.py"
    "src/h1hunter/recon/providers/file_source.py" "src/h1hunter/recon/providers/text_source.py"
    "src/h1hunter/checks/base.py" "src/h1hunter/checks/headers.py" "src/h1hunter/checks/tls.py"
    "src/h1hunter/checks/exposure.py" "src/h1hunter/checks/api_docs.py"
    "src/h1hunter/checks/input_reflection.py"
    "src/h1hunter/storage/database.py" "src/h1hunter/storage/repositories.py"
    "src/h1hunter/reporting/severity.py" "src/h1hunter/reporting/json_report.py"
    "src/h1hunter/reporting/csv_report.py" "src/h1hunter/reporting/markdown_report.py"
    "src/h1hunter/utils/normalization.py" "src/h1hunter/utils/networking.py"
    "src/h1hunter/utils/deduplication.py"
    "tests/conftest.py" "tests/fixtures/sample_scope.yaml"
)
missing=()
for f in "${required[@]}"; do
    [[ -f "$SRC/$f" ]] || missing+=("$f")
done
if (( ${#missing[@]} )); then
    echo "ERROR: missing required files:" >&2
    printf '  - %s\n' "${missing[@]}" >&2
    exit 1
fi
echo "Structure OK: ${#required[@]} required files present."

# --- 4. Stage with a single top-level directory ------------------------------
rm -rf "$STAGE"; mkdir -p "$STAGE"
cp -R "$SRC" "$STAGE/$SRC"

# --- 5. Zip ------------------------------------------------------------------
rm -f "$OUT"
if command -v zip >/dev/null 2>&1; then
    ( cd "$STAGE" && zip -qr "../$OUT" "$SRC" )
else
    python3 - <<'PY'
import shutil
shutil.make_archive("h1hunter-phase1-4", "zip", ".package_stage", "h1hunter")
PY
fi
rm -rf "$STAGE"

# --- 6. Verify by reopening --------------------------------------------------
echo
echo "=== Archive contents (top level) ==="
if command -v unzip >/dev/null 2>&1; then
    unzip -l "$OUT" | awk 'NR>3 {print $4}' | grep -E '^h1hunter/[^/]*/?$' | sort -u
    file_count=$(unzip -l "$OUT" | tail -1 | awk '{print $2}')
    echo "Total entries: $file_count"
else
    python3 - "$OUT" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    names = z.namelist()
    print(f"Total entries: {len(names)}")
    for n in sorted({p.split('/')[1] for p in names if p.startswith('h1hunter/') and p.count('/') == 1}):
        print(f"  h1hunter/{n}")
PY
fi

# --- 7. SHA-256 --------------------------------------------------------------
echo
echo "=== SHA-256 ==="
if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$OUT" | tee "$OUT.sha256"
elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$OUT" | tee "$OUT.sha256"
else
    python3 - "$OUT" <<'PY'
import hashlib, sys
h = hashlib.sha256()
with open(sys.argv[1], 'rb') as f:
    for chunk in iter(lambda: f.read(1 << 20), b''):
        h.update(chunk)
print(f"{h.hexdigest()}  {sys.argv[1]}")
PY
fi

echo
echo "Done: $OUT"
