#!/usr/bin/env python3
"""h1hunter builder — Part 3 of 4.

Adds: passive reconnaissance engine, passive providers (file, text), DNS
inspector, HTTP prober, bounded-concurrency runner, and provider registry.
Idempotent.
"""
from pathlib import Path

ROOT = Path("h1hunter")

def w(rel: str, content: str) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if content.startswith("\n"):
        content = content[1:]
    p.write_text(content, encoding="utf-8")
    print(f"  wrote {rel}")

if not ROOT.exists():
    raise SystemExit("ERROR: ./h1hunter/ not found. Run build1.py and build2.py first.")

print(f"Extending {ROOT.resolve()}")

# ---------------------------------------------------------------------------
# recon/__init__.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/__init__.py", r'''
"""Reconnaissance: passive discovery, DNS inspection, and HTTP probing."""

from __future__ import annotations

from h1hunter.recon.dns import (
    DEFAULT_RECORD_TYPES, DnsInspector, DnsResolver, DnsResolverProtocol, DnsResult,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult, RedirectEvent
from h1hunter.recon.passive import (
    PassiveReconEngine, PassiveReconResult, PassiveSource,
)
from h1hunter.recon.runner import run_concurrently

__all__ = [
    "DEFAULT_RECORD_TYPES", "DnsInspector", "DnsResolver", "DnsResolverProtocol",
    "DnsResult", "HttpProber", "PassiveReconEngine", "PassiveReconResult",
    "PassiveSource", "ProbeResult", "RedirectEvent", "run_concurrently",
]
''')

# ---------------------------------------------------------------------------
# recon/runner.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/runner.py", r'''
"""Bounded concurrent fan-out."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from typing import TypeVar

__all__ = ["run_concurrently"]

T = TypeVar("T")
R = TypeVar("R")


async def run_concurrently(
    items: Sequence[T],
    factory: Callable[[T], Awaitable[R]],
    limit: int,
) -> list[R]:
    """Run ``factory(item)`` for every item, at most ``limit`` at a time.

    Returns results in the same order as ``items``. Raises ``ValueError`` if
    ``limit`` < 1. Cancellation propagates.
    """
    if limit < 1:
        raise ValueError("limit must be >= 1")
    semaphore = asyncio.Semaphore(limit)

    async def one(item: T) -> R:
        async with semaphore:
            return await factory(item)

    return await asyncio.gather(*(one(item) for item in items))
''')

# ---------------------------------------------------------------------------
# recon/passive.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/passive.py", r'''
"""Passive reconnaissance engine.

Providers are pluggable and independent. The engine:
  * runs each enabled provider, tolerating per-provider failures,
  * normalizes every discovered hostname,
  * deduplicates by hostname while keeping every source,
  * optionally annotates ``scope_status`` from a ``ScopeValidator`` for
    reporting. Annotation is *informational only*. It never authorizes a probe.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable

from h1hunter.models.asset import Asset, ScopeStatus, utcnow
from h1hunter.scope.validator import ScopeValidator
from h1hunter.utils.deduplication import deduplicate_assets

__all__ = ["PassiveReconEngine", "PassiveReconResult", "PassiveSource"]

logger = logging.getLogger(__name__)


@runtime_checkable
class PassiveSource(Protocol):
    """A provider of passively discovered assets.

    Implementations must not probe program targets. Reading local files,
    consuming pre-collected OSINT, or querying approved third-party data
    services the operator has configured are valid; sending requests to
    in-scope hosts is not.
    """
    name: str

    async def discover(self) -> list[Asset]: ...


@dataclass(frozen=True, slots=True)
class PassiveReconResult:
    assets: list[Asset]
    sources_run: list[str]
    sources_failed: list[tuple[str, str]]
    started_at: datetime
    finished_at: datetime

    @property
    def duration_seconds(self) -> float:
        return (self.finished_at - self.started_at).total_seconds()


class PassiveReconEngine:
    def __init__(
        self,
        sources: Sequence[PassiveSource],
        *,
        validator: ScopeValidator | None = None,
    ) -> None:
        self._sources = list(sources)
        self._validator = validator

    @property
    def sources(self) -> tuple[PassiveSource, ...]:
        return tuple(self._sources)

    async def run(self) -> PassiveReconResult:
        started_at = utcnow()
        collected: list[Asset] = []
        run: list[str] = []
        failed: list[tuple[str, str]] = []

        for source in self._sources:
            try:
                found = await source.discover()
            except Exception as exc:  # noqa: BLE001 - provider-isolated failure
                logger.warning("passive source %r failed: %s", source.name, exc)
                failed.append((source.name, str(exc)))
                continue
            logger.info(
                "passive source %r returned %d assets", source.name, len(found)
            )
            run.append(source.name)
            collected.extend(found)

        deduped = deduplicate_assets(collected)
        if self._validator is not None:
            deduped = [self._annotate(asset) for asset in deduped]

        return PassiveReconResult(
            assets=deduped,
            sources_run=run,
            sources_failed=failed,
            started_at=started_at,
            finished_at=utcnow(),
        )

    def _annotate(self, asset: Asset) -> Asset:
        """Attach an informational ``scope_status``. Does not authorize a probe."""
        decision = self._validator.evaluate(asset.hostname)  # type: ignore[union-attr]
        if decision.allowed:
            status = ScopeStatus.IN_SCOPE
        elif decision.matched_rule is not None:
            status = ScopeStatus.EXCLUDED
        else:
            status = ScopeStatus.OUT_OF_SCOPE
        return asset.model_copy(update={"scope_status": status})
''')

# ---------------------------------------------------------------------------
# recon/dns.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/dns.py", r'''
"""Opt-in DNS inspection.

Every DNS query is scope-validated, budgeted, and rate-limited through the
centralized ``SafetyEngine``. DNS answers are informational only — they never
grant authorization to connect to the resolved hosts.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Protocol

import dns.asyncresolver
import dns.exception
import dns.rdatatype

from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, KillSwitchEngaged, SafetyError, ScopeViolation,
)

__all__ = [
    "DEFAULT_RECORD_TYPES", "DnsInspector", "DnsResolver",
    "DnsResolverProtocol", "DnsResult",
]

logger = logging.getLogger(__name__)

DEFAULT_RECORD_TYPES: tuple[str, ...] = ("A", "AAAA", "CNAME", "MX", "TXT", "NS")


@dataclass(frozen=True, slots=True)
class DnsResult:
    """The outcome of inspecting one hostname.

    ``skipped`` is set when the safety engine refused the query — the hostname
    was out of scope, the budget was exhausted, or the kill switch was engaged.
    ``errors`` holds per-record-type failures; a partial result still populates
    ``records`` with whatever succeeded.
    """
    hostname: str
    records: dict[str, list[str]] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)
    skipped: bool = False
    skip_reason: str | None = None


class DnsResolverProtocol(Protocol):
    """Injected resolver interface — enables deterministic tests."""

    async def resolve(self, hostname: str, record_type: str) -> list[str]: ...


class DnsResolver:
    """Real dnspython-backed resolver with bounded timeouts."""

    def __init__(self, timeout_seconds: float = 5.0) -> None:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        self._timeout = float(timeout_seconds)

    @property
    def timeout_seconds(self) -> float:
        return self._timeout

    async def resolve(self, hostname: str, record_type: str) -> list[str]:
        resolver = dns.asyncresolver.Resolver(configure=True)
        resolver.timeout = self._timeout
        resolver.lifetime = self._timeout
        try:
            answer = await resolver.resolve(hostname, record_type)
        except (
            dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers,
        ):
            return []
        except (dns.exception.DNSException, OSError) as exc:
            raise RuntimeError(
                f"DNS query failed for {hostname}/{record_type}: {exc}"
            ) from exc
        results: list[str] = []
        for rdata in answer:
            text = str(rdata)
            if record_type == "CNAME":
                text = text.rstrip(".")
            results.append(text)
        return results


class DnsInspector:
    def __init__(
        self,
        engine: SafetyEngine,
        resolver: DnsResolverProtocol,
        *,
        record_types: tuple[str, ...] = DEFAULT_RECORD_TYPES,
    ) -> None:
        self._engine = engine
        self._resolver = resolver
        self._record_types = tuple(record_types)

    @property
    def record_types(self) -> tuple[str, ...]:
        return self._record_types

    async def inspect(self, hostname: str) -> DnsResult:
        try:
            parsed = await self._engine.authorize(hostname)
        except (
            ScopeViolation, SafetyError, BudgetExhausted,
            CircuitOpen, KillSwitchEngaged,
        ) as exc:
            logger.info("DNS query for %r refused: %s", hostname, exc)
            return DnsResult(hostname=hostname, skipped=True, skip_reason=str(exc))

        records: dict[str, list[str]] = {}
        errors: dict[str, str] = {}
        for rtype in self._record_types:
            try:
                answers = await self._resolver.resolve(parsed.host, rtype)
            except Exception as exc:  # noqa: BLE001 — per-record isolation
                logger.debug("DNS %s/%s failed: %s", parsed.host, rtype, exc)
                errors[rtype] = str(exc)
                continue
            if answers:
                records[rtype] = answers
        return DnsResult(hostname=parsed.host, records=records, errors=errors)
''')

# ---------------------------------------------------------------------------
# recon/http_probe.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/http_probe.py", r'''
"""Opt-in, bounded HTTP probing.

Every request is scope-validated, budgeted, and rate-limited through the
centralized ``SafetyEngine``. Before any request is sent, the hostname is
resolved and every resolved IP is checked against the destination policy.
Redirects are re-validated hop by hop: an out-of-scope ``Location`` is
recorded and refused, never followed.

Response bodies are read incrementally and truncated at
``policy.max_response_bytes``. Sensitive headers are redacted before the
result reaches any caller. Response bodies are never persisted.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin

import httpx

from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged,
    SafetyError, ScopeViolation,
)
from h1hunter.logging_config import redact_mapping
from h1hunter.recon.dns import DnsResolverProtocol
from h1hunter.utils.normalization import is_ip_literal

__all__ = ["HttpProber", "ProbeResult", "RedirectEvent", "REDIRECT_STATUS_CODES"]

logger = logging.getLogger(__name__)

REDIRECT_STATUS_CODES = frozenset({301, 302, 303, 307, 308})
DEFAULT_MAX_REDIRECTS = 5
_PREVIEW_CHARS = 2048


@dataclass(frozen=True, slots=True)
class RedirectEvent:
    from_url: str
    to_url: str
    refused: bool = False
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class ProbeResult:
    url: str
    final_url: str
    status_code: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
    body_preview: str = ""
    body_bytes: int = 0
    truncated: bool = False
    duration_seconds: float = 0.0
    redirects: list[RedirectEvent] = field(default_factory=list)
    resolved_ips: dict[str, list[str]] = field(default_factory=dict)
    error: str | None = None


class HttpProber:
    def __init__(
        self,
        engine: SafetyEngine,
        client: httpx.AsyncClient,
        resolver: DnsResolverProtocol,
        *,
        max_redirects: int = DEFAULT_MAX_REDIRECTS,
    ) -> None:
        if max_redirects < 0:
            raise ValueError("max_redirects must be >= 0")
        self._engine = engine
        self._client = client
        self._resolver = resolver
        self._max_redirects = max_redirects

    @property
    def max_redirects(self) -> int:
        return self._max_redirects

    async def probe(self, url: str) -> ProbeResult:
        start = time.monotonic()
        current_url = url
        redirects: list[RedirectEvent] = []
        resolved_ips: dict[str, list[str]] = {}

        for _hop in range(self._max_redirects + 1):
            try:
                parsed = await self._engine.authorize(current_url)
            except (
                ScopeViolation, SafetyError, BudgetExhausted,
                CircuitOpen, KillSwitchEngaged,
            ) as exc:
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )

            try:
                ips = await self._resolve_and_check(parsed.host)
            except DestinationBlocked as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )
            except SafetyError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )
            resolved_ips[parsed.host] = ips

            try:
                info = await self._send(current_url)
            except httpx.TimeoutException as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"timeout: {exc}",
                )
            except httpx.HTTPError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"http error: {exc}",
                )
            except OSError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"network error: {exc}",
                )
            else:
                self._engine.record_success()

            status = info["status_code"]
            location = info["headers"].get("location")

            if status in REDIRECT_STATUS_CODES and location:
                next_url = urljoin(current_url, location)
                decision = self._engine.validator.evaluate(next_url)
                if not decision.allowed:
                    redirects.append(
                        RedirectEvent(
                            from_url=current_url, to_url=next_url,
                            refused=True, reason=decision.reason,
                        )
                    )
                    logger.info(
                        "redirect from %s to %s refused: %s",
                        current_url, next_url, decision.reason,
                    )
                    return ProbeResult(
                        url=url, final_url=current_url, status_code=status,
                        headers=info["headers"], body_preview=info["body_preview"],
                        body_bytes=info["body_bytes"], truncated=info["truncated"],
                        duration_seconds=time.monotonic() - start,
                        redirects=redirects, resolved_ips=resolved_ips,
                        error=f"redirect refused: {decision.reason}",
                    )
                redirects.append(
                    RedirectEvent(from_url=current_url, to_url=next_url)
                )
                current_url = next_url
                continue

            return ProbeResult(
                url=url, final_url=current_url, status_code=status,
                headers=info["headers"], body_preview=info["body_preview"],
                body_bytes=info["body_bytes"], truncated=info["truncated"],
                duration_seconds=time.monotonic() - start,
                redirects=redirects, resolved_ips=resolved_ips, error=None,
            )

        return self._failure(
            url, current_url, redirects, resolved_ips, start,
            f"exceeded {self._max_redirects} redirects",
        )

    async def _resolve_and_check(self, hostname: str) -> list[str]:
        if is_ip_literal(hostname):
            self._engine.check_destination(hostname)
            return [hostname]
        ips: list[str] = []
        for rtype in ("A", "AAAA"):
            try:
                answers = await self._resolver.resolve(hostname, rtype)
            except Exception as exc:  # noqa: BLE001
                logger.debug("resolve %s/%s failed: %s", hostname, rtype, exc)
                continue
            for ip in answers:
                self._engine.check_destination(ip)
                if ip not in ips:
                    ips.append(ip)
        if not ips:
            raise SafetyError(
                f"could not resolve a permitted destination for {hostname!r}"
            )
        return ips

    async def _send(self, url: str) -> dict[str, object]:
        request = self._client.build_request(
            "GET", url, timeout=self._engine.policy.timeout_seconds,
        )
        response = await self._client.send(
            request, stream=True, follow_redirects=False,
        )
        try:
            status_code = response.status_code
            raw_headers = {k: str(v) for k, v in response.headers.items()}
            headers = redact_mapping(raw_headers)
            headers = {k: str(v) for k, v in headers.items()}

            cap = self._engine.policy.max_response_bytes
            chunks: list[bytes] = []
            total = 0
            truncated = False
            async for chunk in response.aiter_bytes():
                remaining = cap - total
                if remaining <= 0:
                    truncated = True
                    break
                if len(chunk) > remaining:
                    chunks.append(chunk[:remaining])
                    total = cap
                    truncated = True
                    break
                chunks.append(chunk)
                total += len(chunk)
            body = b"".join(chunks)
            preview = _decode_preview(body)
            return {
                "status_code": status_code, "headers": headers,
                "body_preview": preview, "body_bytes": total,
                "truncated": truncated,
            }
        finally:
            await response.aclose()

    def _failure(
        self,
        original_url: str,
        current_url: str,
        redirects: list[RedirectEvent],
        resolved_ips: dict[str, list[str]],
        start: float,
        error: str,
    ) -> ProbeResult:
        return ProbeResult(
            url=original_url, final_url=current_url,
            duration_seconds=time.monotonic() - start,
            redirects=redirects, resolved_ips=resolved_ips, error=error,
        )


def _decode_preview(body: bytes) -> str:
    try:
        text = body.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return ""
    return text[:_PREVIEW_CHARS]
''')

# ---------------------------------------------------------------------------
# recon/providers/__init__.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/providers/__init__.py", r'''
"""Built-in passive reconnaissance providers.

Every provider in this package reads from local sources only.
"""

from __future__ import annotations

from h1hunter.recon.providers.file_source import FileSource
from h1hunter.recon.providers.text_source import TextSource

__all__ = ["FileSource", "TextSource"]
''')

# ---------------------------------------------------------------------------
# recon/providers/file_source.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/providers/file_source.py", r'''
"""JSON file provider.

Accepts either a bare list of hostnames, a list of asset objects, or an object
with an ``assets`` key containing either of those. Malformed individual entries
are logged and skipped; a missing or unreadable file raises
``PassiveSourceError``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from h1hunter.exceptions import PassiveSourceError
from h1hunter.models.asset import Asset
from h1hunter.utils.normalization import derive_domain, normalize_hostname

__all__ = ["FileSource"]

logger = logging.getLogger(__name__)


class FileSource:
    def __init__(self, name: str, path: str | Path) -> None:
        if not name:
            raise PassiveSourceError("FileSource requires a non-empty name")
        self.name = name
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    async def discover(self) -> list[Asset]:
        if not self._path.exists():
            raise PassiveSourceError(f"file not found: {self._path}")
        if not self._path.is_file():
            raise PassiveSourceError(f"not a file: {self._path}")
        try:
            text = self._path.read_text(encoding="utf-8")
        except OSError as exc:
            raise PassiveSourceError(f"cannot read {self._path}: {exc}") from exc
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise PassiveSourceError(f"invalid JSON in {self._path}: {exc}") from exc
        entries = self._extract_entries(data)
        assets: list[Asset] = []
        for index, entry in enumerate(entries):
            asset = self._build_asset(entry, index)
            if asset is not None:
                assets.append(asset)
        return assets

    @staticmethod
    def _extract_entries(data: Any) -> list[Any]:
        if isinstance(data, dict) and "assets" in data:
            inner = data["assets"]
            if not isinstance(inner, list):
                raise PassiveSourceError("'assets' key must contain a list")
            return inner
        if isinstance(data, list):
            return data
        raise PassiveSourceError("JSON must be a list or an object with an 'assets' key")

    def _build_asset(self, entry: Any, index: int) -> Asset | None:
        try:
            if isinstance(entry, str):
                hostname = normalize_hostname(entry)
                return Asset(
                    hostname=hostname, domain=derive_domain(hostname),
                    source=self.name,
                    discovered_at=datetime.now(timezone.utc),
                )
            if isinstance(entry, dict):
                raw_host = entry.get("hostname")
                if not isinstance(raw_host, str) or not raw_host:
                    raise ValueError("missing or invalid 'hostname'")
                hostname = normalize_hostname(raw_host)
                discovered_at = self._parse_timestamp(entry.get("discovered_at"))
                metadata = entry.get("metadata") or {}
                if not isinstance(metadata, dict):
                    raise ValueError("'metadata' must be an object")
                dns_records = entry.get("dns_records") or {}
                if not isinstance(dns_records, dict):
                    raise ValueError("'dns_records' must be an object")
                return Asset(
                    hostname=hostname,
                    domain=entry.get("domain") or derive_domain(hostname),
                    source=self.name, discovered_at=discovered_at,
                    dns_records=dns_records, metadata=metadata,
                )
        except Exception as exc:  # noqa: BLE001 - per-entry isolation
            logger.warning(
                "file source %r skipped entry %d: %s", self.name, index, exc,
            )
            return None
        logger.warning(
            "file source %r skipped entry %d: unsupported type %s",
            self.name, index, type(entry).__name__,
        )
        return None

    @staticmethod
    def _parse_timestamp(value: Any) -> datetime:
        if value is None:
            return datetime.now(timezone.utc)
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        if isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError(f"invalid timestamp {value!r}") from exc
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        raise ValueError(f"unsupported timestamp type: {type(value).__name__}")
''')

# ---------------------------------------------------------------------------
# recon/providers/text_source.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/providers/text_source.py", r'''
"""Newline-delimited hostname provider.

Blank lines and lines beginning with ``#`` are ignored. Comments may also
appear after a hostname if separated by ``#``. Malformed lines are skipped with
a warning; a missing file raises ``PassiveSourceError``.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from h1hunter.exceptions import PassiveSourceError
from h1hunter.models.asset import Asset
from h1hunter.utils.normalization import derive_domain, normalize_hostname

__all__ = ["TextSource"]

logger = logging.getLogger(__name__)


class TextSource:
    def __init__(self, name: str, path: str | Path) -> None:
        if not name:
            raise PassiveSourceError("TextSource requires a non-empty name")
        self.name = name
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    async def discover(self) -> list[Asset]:
        if not self._path.exists():
            raise PassiveSourceError(f"file not found: {self._path}")
        if not self._path.is_file():
            raise PassiveSourceError(f"not a file: {self._path}")
        try:
            text = self._path.read_text(encoding="utf-8")
        except OSError as exc:
            raise PassiveSourceError(f"cannot read {self._path}: {exc}") from exc
        assets: list[Asset] = []
        now = datetime.now(timezone.utc)
        for lineno, line in enumerate(text.splitlines(), start=1):
            candidate = line.split("#", 1)[0].strip()
            if not candidate:
                continue
            try:
                hostname = normalize_hostname(candidate)
            except Exception as exc:  # noqa: BLE001 - per-line isolation
                logger.warning(
                    "text source %r skipped line %d (%r): %s",
                    self.name, lineno, candidate, exc,
                )
                continue
            assets.append(
                Asset(
                    hostname=hostname, domain=derive_domain(hostname),
                    source=self.name, discovered_at=now,
                )
            )
        return assets
''')

# ---------------------------------------------------------------------------
# recon/registry.py
# ---------------------------------------------------------------------------
w("src/h1hunter/recon/registry.py", r'''
"""Build passive providers from application configuration."""

from __future__ import annotations

from collections.abc import Iterable

from h1hunter.config import PassiveSourceSettings
from h1hunter.exceptions import ConfigurationError, PassiveSourceError
from h1hunter.recon.passive import PassiveSource
from h1hunter.recon.providers import FileSource, TextSource

__all__ = ["build_source", "build_sources_from_config", "SUPPORTED_SOURCE_TYPES"]

SUPPORTED_SOURCE_TYPES = frozenset({"file", "text"})


def build_source(settings: PassiveSourceSettings) -> PassiveSource:
    options = settings.options or {}
    kind = options.get("type")
    if kind not in SUPPORTED_SOURCE_TYPES:
        raise ConfigurationError(
            f"passive source {settings.name!r} has unsupported type {kind!r}; "
            f"supported types are {sorted(SUPPORTED_SOURCE_TYPES)}"
        )
    path = options.get("path")
    if not isinstance(path, str) or not path:
        raise ConfigurationError(
            f"passive source {settings.name!r} is missing a string 'path' option"
        )
    try:
        if kind == "file":
            return FileSource(settings.name, path)
        return TextSource(settings.name, path)
    except PassiveSourceError as exc:
        raise ConfigurationError(
            f"cannot build passive source {settings.name!r}: {exc}"
        ) from exc


def build_sources_from_config(
    settings: Iterable[PassiveSourceSettings],
) -> list[PassiveSource]:
    sources: list[PassiveSource] = []
    for entry in settings:
        if not entry.enabled:
            continue
        sources.append(build_source(entry))
    return sources
''')

print("\nPart 3 complete. Next: build4.py (checks, storage, reporting, CLI, tests).")
