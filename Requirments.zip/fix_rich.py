#!/usr/bin/env python3
"""Patch logging_config.py for compatibility with older rich versions.

rich >= 13.0 accepts console_kwargs= on RichHandler.
Older rich does not. Passing a Console instance via console= works on
every version, so we use that instead.
"""
from pathlib import Path
import re
import sys

CANDIDATES = [
    Path("h1hunter/src/h1hunter/logging_config.py"),
    Path("src/h1hunter/logging_config.py"),
    Path.home() / "Desktop/New_Folder/h1hunter/src/h1hunter/logging_config.py",
]

path = next((p for p in CANDIDATES if p.exists()), None)
if path is None:
    sys.exit("Cannot find logging_config.py in any known location.")

text = path.read_text(encoding="utf-8")

old_block = '''        stream_handler = RichHandler(
            rich_tracebacks=True,
            show_path=False,
            markup=False,
            console_kwargs={"no_color": no_color, "stderr": True},
        )'''

new_block = '''        from rich.console import Console as _RichConsole
        _rich_console = _RichConsole(no_color=no_color, stderr=True)
        stream_handler = RichHandler(
            rich_tracebacks=True,
            show_path=False,
            markup=False,
            console=_rich_console,
        )'''

if old_block in text:
    text = text.replace(old_block, new_block)
    path.write_text(text, encoding="utf-8")
    print(f"Patched: {path}")
elif "console=_rich_console" in text:
    print(f"Already patched: {path}")
else:
    # Fallback regex in case whitespace differs
    pattern = re.compile(
        r"stream_handler\s*=\s*RichHandler\((?:[^)(]|\([^)]*\))*console_kwargs[^)]*\)",
        re.DOTALL,
    )
    match = pattern.search(text)
    if match:
        text = text[:match.start()] + new_block + text[match.end():]
        path.write_text(text, encoding="utf-8")
        print(f"Patched (regex): {path}")
    else:
        print(f"WARNING: could not locate the RichHandler call in {path}")
        print("Open the file and replace the console_kwargs= block manually.")
        sys.exit(1)
