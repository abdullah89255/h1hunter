#!/usr/bin/env python3
"""Package ./h1hunter into h1hunter-phase1-4.zip.

- Strips caches, virtualenvs, build artifacts, local configs, and databases.
- Verifies the required project structure is present.
- Refuses to ship secret-shaped files.
- Prints a content summary and SHA-256.
"""
from __future__ import annotations

import hashlib
import shutil
import sys
import zipfile
from pathlib import Path

SRC = Path("h1hunter")
OUT = Path("h1hunter-phase1-4.zip")

if not SRC.is_dir():
    sys.exit("ERROR: ./h1hunter/ not found. Run build1.py through build4c.py first.")

# --------------------------------------------------------------------- cleaning
SKIP_DIRS = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".venv", "venv", "env", "output", "logs", ".git", ".idea", ".vscode",
}
SKIP_FILE_NAMES = {
    ".env", "config.yaml", "scope.yaml", ".DS_Store",
}
SKIP_SUFFIXES = {".pyc", ".pyo", ".pyi.cache", ".sqlite", ".sqlite3"}

def _should_skip(path: Path) -> bool:
    if any(part in SKIP_DIRS for part in path.parts):
        return True
    if path.name in SKIP_FILE_NAMES:
        return True
    if path.suffix in SKIP_SUFFIXES:
        return True
    return False

# ------------------------------------------------------------------ required set
REQUIRED = [
    "pyproject.toml", "README.md", "LICENSE", ".gitignore", ".env.example",
    "config/config.example.yaml", "config/scope.example.yaml",
    "docs/architecture.md", "docs/scope_safety.md", "docs/usage.md",
    "src/h1hunter/__init__.py", "src/h1hunter/__main__.py",
    "src/h1hunter/main.py", "src/h1hunter/cli.py", "src/h1hunter/config.py",
    "src/h1hunter/logging_config.py", "src/h1hunter/exceptions.py",
    "src/h1hunter/models/__init__.py", "src/h1hunter/models/scope.py",
    "src/h1hunter/models/asset.py", "src/h1hunter/models/finding.py",
    "src/h1hunter/scope/__init__.py", "src/h1hunter/scope/parser.py",
    "src/h1hunter/scope/matcher.py", "src/h1hunter/scope/validator.py",
    "src/h1hunter/engine/__init__.py", "src/h1hunter/engine/rate_limiter.py",
    "src/h1hunter/engine/safety.py",
    "src/h1hunter/recon/__init__.py", "src/h1hunter/recon/passive.py",
    "src/h1hunter/recon/dns.py", "src/h1hunter/recon/http_probe.py",
    "src/h1hunter/recon/runner.py", "src/h1hunter/recon/registry.py",
    "src/h1hunter/recon/providers/__init__.py",
    "src/h1hunter/recon/providers/file_source.py",
    "src/h1hunter/recon/providers/text_source.py",
    "src/h1hunter/checks/__init__.py", "src/h1hunter/checks/base.py",
    "src/h1hunter/checks/headers.py", "src/h1hunter/checks/tls.py",
    "src/h1hunter/checks/exposure.py", "src/h1hunter/checks/api_docs.py",
    "src/h1hunter/checks/input_reflection.py",
    "src/h1hunter/storage/__init__.py", "src/h1hunter/storage/database.py",
    "src/h1hunter/storage/repositories.py",
    "src/h1hunter/reporting/__init__.py", "src/h1hunter/reporting/severity.py",
    "src/h1hunter/reporting/json_report.py",
    "src/h1hunter/reporting/csv_report.py",
    "src/h1hunter/reporting/markdown_report.py",
    "src/h1hunter/utils/__init__.py", "src/h1hunter/utils/normalization.py",
    "src/h1hunter/utils/networking.py", "src/h1hunter/utils/deduplication.py",
    "tests/__init__.py", "tests/conftest.py",
    "tests/fixtures/sample_scope.yaml",
    "tests/unit/__init__.py", "tests/unit/test_scope_parser.py",
    "tests/unit/test_scope_matcher.py", "tests/unit/test_scope_validator.py",
    "tests/unit/test_rate_limiter.py", "tests/unit/test_finding_models.py",
    "tests/unit/test_severity.py",
    "tests/integration/__init__.py",
    "tests/integration/test_safety_regression.py",
    "tests/integration/test_recon_pipeline.py",
    "tests/integration/test_active_checks.py",
    "tests/integration/test_reporting.py",
]

missing = [r for r in REQUIRED if not (SRC / r).is_file()]
if missing:
    print("WARNING: some required files are missing:", file=sys.stderr)
    for m in missing:
        print(f"  - {m}", file=sys.stderr)
    print("Archive will still be produced; review the missing list.", file=sys.stderr)

# -------------------------------------------------------------------- secret scan
SUSPICIOUS = []
for p in SRC.rglob("*"):
    if not p.is_file() or _should_skip(p):
        continue
    if p.suffix.lower() in {".pem", ".key", ".p12", ".pfx"}:
        SUSPICIOUS.append(p)
    if p.name.lower().startswith("id_rsa"):
        SUSPICIOUS.append(p)

if SUSPICIOUS:
    print("ERROR: potential key material found; refusing to package:", file=sys.stderr)
    for p in SUSPICIOUS:
        print(f"  - {p}", file=sys.stderr)
    sys.exit(1)

# ------------------------------------------------------------------------ zip
if OUT.exists():
    OUT.unlink()

added = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for p in sorted(SRC.rglob("*")):
        if not p.is_file() or _should_skip(p):
            continue
        # Keep the single top-level "h1hunter/" directory.
        arcname = Path("h1hunter") / p.relative_to(SRC)
        zf.write(p, arcname=str(arcname))
        added += 1

print(f"Wrote {OUT} — {added} files")
size_mb = OUT.stat().st_size / (1024 * 1024)
print(f"Archive size: {size_mb:.2f} MiB")

# ------------------------------------------------------------------- verify zip
print("\n=== Archive verification ===")
with zipfile.ZipFile(OUT) as zf:
    names = zf.namelist()
    bad = zf.testzip()
    if bad:
        sys.exit(f"ERROR: corrupted entry in archive: {bad}")
    print(f"Entries: {len(names)}")
    top = sorted({n.split("/")[1] for n in names
                  if n.startswith("h1hunter/") and n.count("/") == 1})
    print("Top-level of h1hunter/:")
    for t in top:
        print(f"  {t}")

# ------------------------------------------------------------------- checksum
h = hashlib.sha256()
with OUT.open("rb") as fh:
    for chunk in iter(lambda: fh.read(1 << 20), b""):
        h.update(chunk)
digest = h.hexdigest()
print(f"\nSHA-256: {digest}  {OUT.name}")
(OUT.with_suffix(OUT.suffix + ".sha256")).write_text(
    f"{digest}  {OUT.name}\n", encoding="utf-8"
)
print(f"Checksum written to {OUT.name}.sha256")

print("\nDone.")
