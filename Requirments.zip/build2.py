#!/usr/bin/env python3
"""h1hunter builder — Part 2 of 4.

Adds: application config, scope parser/matcher/validator, safety engine,
rate limiter, and the deduplication utilities. Extends the tree created by
build1.py. Idempotent.
"""
from pathlib import Path

ROOT = Path("h1hunter")

def w(rel: str, content: str) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if content.startswith("\n"):
        content = content[1:]
    p.write_text(content, encoding="utf-8")
    print(f"  wrote {rel}")

if not ROOT.exists():
    raise SystemExit("ERROR: ./h1hunter/ not found. Run build1.py first.")

print(f"Extending {ROOT.resolve()}")

# ---------------------------------------------------------------------------
# src/h1hunter/config.py
# ---------------------------------------------------------------------------
w("src/h1hunter/config.py", r'''
"""Application configuration loading and validation."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from h1hunter.exceptions import ConfigurationError

__all__ = [
    "AppConfig", "LoggingSettings", "PassiveSourceSettings",
    "DEFAULT_CONFIG_PATH", "DEFAULT_SCOPE_PATH",
    "load_app_config", "get_secret",
]

DEFAULT_CONFIG_PATH = Path("config/config.yaml")
DEFAULT_SCOPE_PATH = Path("config/scope.yaml")


class LoggingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "WARNING"
    format: Literal["console", "json"] = "console"
    file: str | None = None


class PassiveSourceSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    enabled: bool = False
    options: dict[str, Any] = Field(default_factory=dict)


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    timeout_seconds: float = Field(default=10.0, gt=0, le=120)
    max_concurrency: int = Field(default=3, ge=1, le=50)
    requests_per_second: float = Field(default=2.0, gt=0, le=100)
    max_retries: int = Field(default=2, ge=0, le=5)
    max_requests: int = Field(default=500, ge=1, le=100_000)
    max_response_bytes: int = Field(default=1_048_576, ge=1024, le=52_428_800)
    output_dir: Path = Path("output")
    user_agent: str = "h1hunter/0.4 (+authorized-security-research)"
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    enabled_modules: list[str] = Field(default_factory=list)
    passive_sources: list[PassiveSourceSettings] = Field(default_factory=list)


def load_app_config(path: str | Path | None = None) -> AppConfig:
    if path is None:
        return AppConfig()
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigurationError(f"configuration file not found: {config_path}")
    try:
        raw = config_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigurationError(f"cannot read configuration {config_path}: {exc}") from exc
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML in {config_path}: {exc}") from exc
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise ConfigurationError(f"configuration must be a mapping: {config_path}")
    try:
        return AppConfig(**data)
    except ValidationError as exc:
        raise ConfigurationError(f"invalid configuration {config_path}: {exc}") from exc


def get_secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None
''')

# ---------------------------------------------------------------------------
# utils/deduplication.py
# ---------------------------------------------------------------------------
w("src/h1hunter/utils/deduplication.py", r'''
"""Deterministic, source-attributing deduplication for assets and findings."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from h1hunter.models.asset import Asset
from h1hunter.models.finding import ConfidenceLevel, Finding

__all__ = ["deduplicate_assets", "deduplicate_findings"]


def _merge_dns(target: dict[str, list[str]], other: dict[str, list[str]]) -> None:
    for rtype, values in other.items():
        bucket = target.setdefault(rtype, [])
        for value in values:
            if value not in bucket:
                bucket.append(value)
        bucket.sort()


def deduplicate_assets(assets: Iterable[Asset]) -> list[Asset]:
    groups: dict[str, list[Asset]] = {}
    for asset in assets:
        groups.setdefault(asset.dedup_key(), []).append(asset)

    merged: list[Asset] = []
    for hostname in sorted(groups):
        group = groups[hostname]
        group.sort(key=lambda a: (a.discovered_at, a.source))
        primary = group[0]
        sources = sorted({a.source for a in group})
        first_seen = group[0].discovered_at
        last_seen = group[-1].discovered_at
        combined_metadata: dict[str, object] = {}
        for asset in group:
            for key, value in asset.metadata.items():
                combined_metadata.setdefault(key, value)
        combined_metadata["sources"] = sources
        combined_metadata["first_seen"] = first_seen.isoformat()
        combined_metadata["last_seen"] = last_seen.isoformat()
        combined_metadata["discovery_count"] = len(group)
        dns_records: dict[str, list[str]] = {}
        for asset in group:
            _merge_dns(dns_records, asset.dns_records)
        merged.append(
            Asset(
                hostname=primary.hostname,
                domain=primary.domain,
                source=primary.source,
                discovered_at=primary.discovered_at,
                scope_status=primary.scope_status,
                dns_records=dns_records,
                metadata=combined_metadata,
            )
        )
    return merged


_CONFIDENCE_RANK = {
    ConfidenceLevel.LOW: 0,
    ConfidenceLevel.MEDIUM: 1,
    ConfidenceLevel.HIGH: 2,
}


def deduplicate_findings(findings: Iterable[Finding]) -> list[Finding]:
    groups: dict[tuple[str, str, str, str], list[Finding]] = {}
    for finding in findings:
        groups.setdefault(finding.dedup_key(), []).append(finding)

    result: list[Finding] = []
    for key in sorted(groups):
        group = groups[key]
        group.sort(key=lambda f: (
            -f.severity.rank, -_CONFIDENCE_RANK[f.confidence], f.discovered_at,
        ))
        primary = group[0]
        if len(group) == 1:
            result.append(primary)
            continue
        merged_evidence: dict[str, Any] = {}
        for finding in group:
            merged_evidence.update(finding.evidence)
        result.append(primary.model_copy(update={"evidence": merged_evidence}))
    return result
''')

# ---------------------------------------------------------------------------
# scope/
# ---------------------------------------------------------------------------
w("src/h1hunter/scope/__init__.py", r'''
"""Scope parsing, matching, and the centralized authorization API."""

from __future__ import annotations

from h1hunter.scope.matcher import entry_matches
from h1hunter.scope.parser import load_scope_file, parse_scope_entry, parse_scope_text
from h1hunter.scope.validator import ScopeValidator

__all__ = [
    "ScopeValidator", "entry_matches", "load_scope_file",
    "parse_scope_entry", "parse_scope_text",
]
''')

w("src/h1hunter/scope/parser.py", r'''
"""Scope file parsing."""

from __future__ import annotations

import ipaddress
import logging
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from h1hunter.exceptions import ScopeParseError
from h1hunter.models.scope import (
    EntryKind, ProgramInfo, ScopeConfig, ScopeEntry, ScopeSettings,
)
from h1hunter.utils.normalization import (
    is_ip_literal, normalize_hostname, parse_target, to_ip,
)

__all__ = ["load_scope_file", "parse_scope_entry", "parse_scope_text"]

logger = logging.getLogger(__name__)

_Network = ipaddress.IPv4Network | ipaddress.IPv6Network


def _try_network(value: str) -> _Network | None:
    if "/" not in value:
        return None
    try:
        return ipaddress.ip_network(value, strict=False)
    except ValueError:
        return None


def parse_scope_entry(raw: str) -> ScopeEntry:
    if not isinstance(raw, str):
        raise ScopeParseError(f"scope entry must be a string, got {type(raw).__name__}")
    value = raw.strip()
    if not value:
        raise ScopeParseError("scope entry is empty")

    if value.startswith("*."):
        apex = value[2:]
        if not apex:
            raise ScopeParseError(f"wildcard entry has no apex domain: {raw!r}")
        if "*" in apex:
            raise ScopeParseError(f"unsupported wildcard placement: {raw!r}")
        if "/" in apex or ":" in apex:
            raise ScopeParseError(f"wildcard entry must be a bare domain: {raw!r}")
        host = normalize_hostname(apex)
        if is_ip_literal(host):
            raise ScopeParseError(f"wildcard entry cannot target an IP address: {raw!r}")
        if "." not in host:
            raise ScopeParseError(f"wildcard apex must be a registrable domain: {raw!r}")
        return ScopeEntry(raw=raw, kind=EntryKind.WILDCARD, host=host)

    if "*" in value:
        raise ScopeParseError(f"unsupported wildcard placement: {raw!r}")

    if "://" in value:
        parsed = parse_target(value)
        return ScopeEntry(
            raw=raw, kind=EntryKind.URL, host=parsed.host, scheme=parsed.scheme,
            port=parsed.port, path_prefix=parsed.path,
        )

    if is_ip_literal(value):
        addr = to_ip(value)
        return ScopeEntry(
            raw=raw, kind=EntryKind.IP, host=str(addr), network=str(addr),
        )

    network = _try_network(value)
    if network is not None:
        return ScopeEntry(raw=raw, kind=EntryKind.CIDR, network=str(network))

    host = normalize_hostname(value)
    if "." not in host:
        raise ScopeParseError(
            f"domain entry must contain at least one dot (single-label hosts are "
            f"rejected): {raw!r}"
        )
    return ScopeEntry(raw=raw, kind=EntryKind.DOMAIN, host=host)


def _parse_entry_list(value: Any, *, field: str, source: str) -> list[ScopeEntry]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ScopeParseError(f"'{field}' must be a list in {source}")
    entries: list[ScopeEntry] = []
    for item in value:
        try:
            entries.append(parse_scope_entry(item))
        except ScopeParseError as exc:
            raise ScopeParseError(
                f"invalid entry in '{field}' of {source}: {exc}"
            ) from exc
    return entries


def _log_conflicts(allowed: list[ScopeEntry], excluded: list[ScopeEntry]) -> None:
    allowed_raw = {entry.raw for entry in allowed}
    for entry in excluded:
        if entry.raw in allowed_raw:
            logger.warning(
                "entry %r appears in both 'allowed' and 'excluded'; exclusion wins",
                entry.raw,
            )


def parse_scope_text(text: str, *, source: str = "<memory>") -> ScopeConfig:
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ScopeParseError(f"invalid YAML in {source}: {exc}") from exc
    if data is None:
        raise ScopeParseError(f"scope document is empty: {source}")
    if not isinstance(data, dict):
        raise ScopeParseError(f"scope document must be a mapping: {source}")

    program_raw = data.get("program")
    if not isinstance(program_raw, dict):
        raise ScopeParseError(f"scope document is missing a 'program' mapping: {source}")
    try:
        program = ProgramInfo(**program_raw)
    except ValidationError as exc:
        raise ScopeParseError(f"invalid 'program' section in {source}: {exc}") from exc

    allowed = _parse_entry_list(data.get("allowed"), field="allowed", source=source)
    if not allowed:
        raise ScopeParseError(f"scope document defines no allowed assets: {source}")

    excluded = _parse_entry_list(data.get("excluded"), field="excluded", source=source)

    settings_raw = data.get("settings") or {}
    if not isinstance(settings_raw, dict):
        raise ScopeParseError(f"'settings' must be a mapping in {source}")
    try:
        settings = ScopeSettings(**settings_raw)
    except ValidationError as exc:
        raise ScopeParseError(f"invalid 'settings' section in {source}: {exc}") from exc

    _log_conflicts(allowed, excluded)

    try:
        return ScopeConfig(
            program=program, allowed=allowed, excluded=excluded, settings=settings,
        )
    except ValidationError as exc:
        raise ScopeParseError(f"invalid scope in {source}: {exc}") from exc


def load_scope_file(path: str | Path) -> ScopeConfig:
    scope_path = Path(path)
    if not scope_path.exists():
        raise ScopeParseError(f"scope file not found: {scope_path}")
    if not scope_path.is_file():
        raise ScopeParseError(f"scope path is not a file: {scope_path}")
    try:
        text = scope_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ScopeParseError(f"cannot read scope file {scope_path}: {exc}") from exc
    return parse_scope_text(text, source=str(scope_path))
''')

w("src/h1hunter/scope/matcher.py", r'''
"""Scope entry matching."""

from __future__ import annotations

import ipaddress

from h1hunter.models.scope import EntryKind, ScopeEntry
from h1hunter.utils.normalization import ParsedTarget, to_ip

__all__ = ["entry_matches"]

_DEFAULT_PORTS = {"http": 80, "https": 443}


def entry_matches(entry: ScopeEntry, target: ParsedTarget) -> bool:
    match entry.kind:
        case EntryKind.DOMAIN:
            return _matches_domain(entry, target)
        case EntryKind.WILDCARD:
            return _matches_wildcard(entry, target)
        case EntryKind.URL:
            return _matches_url(entry, target)
        case EntryKind.IP:
            return _matches_ip(entry, target)
        case EntryKind.CIDR:
            return _matches_cidr(entry, target)
    return False


def _matches_domain(entry: ScopeEntry, target: ParsedTarget) -> bool:
    return entry.host is not None and target.host == entry.host


def _matches_wildcard(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.host is None:
        return False
    apex = entry.host
    host = target.host
    if host == apex:
        return False
    return host.endswith("." + apex)


def _matches_ip(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.network is None or not target.is_ip:
        return False
    return to_ip(target.host) == to_ip(entry.network)


def _matches_cidr(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.network is None or not target.is_ip:
        return False
    network = ipaddress.ip_network(entry.network, strict=False)
    addr = to_ip(target.host)
    if addr.version != network.version:
        return False
    return addr in network


def _path_matches(prefix: str, path: str) -> bool:
    if prefix in ("", "/"):
        return True
    if path == prefix:
        return True
    return path.startswith(prefix.rstrip("/") + "/")


def _matches_url(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.host is None or not target.is_url:
        return False
    if target.host != entry.host:
        return False
    if entry.scheme is not None and target.scheme != entry.scheme:
        return False
    if entry.port is not None:
        if target.port != entry.port:
            return False
    else:
        default = _DEFAULT_PORTS.get(entry.scheme or "")
        if target.port is not None and default is not None and target.port != default:
            return False
    if entry.path_prefix is not None and not _path_matches(entry.path_prefix, target.path):
        return False
    return True
''')

w("src/h1hunter/scope/validator.py", r'''
"""The centralized scope-enforcement API."""

from __future__ import annotations

import logging

from h1hunter.exceptions import (
    ScopeNotReviewedError, ScopeParseError, ScopeViolation,
)
from h1hunter.models.scope import ScopeConfig, ScopeDecision
from h1hunter.scope.matcher import entry_matches
from h1hunter.utils.normalization import ParsedTarget, parse_target

__all__ = ["ScopeValidator"]

logger = logging.getLogger(__name__)


class ScopeValidator:
    def __init__(self, scope: ScopeConfig) -> None:
        self._scope = scope

    @property
    def scope(self) -> ScopeConfig:
        return self._scope

    @property
    def program_name(self) -> str:
        return self._scope.program.name

    @property
    def policy_reviewed(self) -> bool:
        return self._scope.program.policy_reviewed

    @property
    def active_checks_enabled(self) -> bool:
        return self._scope.settings.active_checks and self._scope.program.policy_reviewed

    def evaluate(self, target: str) -> ScopeDecision:
        try:
            parsed = parse_target(target)
        except ScopeParseError as exc:
            return ScopeDecision(
                target=target, normalized_host=None, allowed=False,
                reason=f"target could not be parsed: {exc}", matched_rule=None,
            )

        for entry in self._scope.excluded:
            if entry_matches(entry, parsed):
                return ScopeDecision(
                    target=target, normalized_host=parsed.host, allowed=False,
                    reason=f"target matches exclusion {entry.describe()!r}",
                    matched_rule=entry.raw,
                )

        for entry in self._scope.allowed:
            if entry_matches(entry, parsed):
                return ScopeDecision(
                    target=target, normalized_host=parsed.host, allowed=True,
                    reason=f"target matches allowed entry {entry.describe()!r}",
                    matched_rule=entry.raw,
                )

        return ScopeDecision(
            target=target, normalized_host=parsed.host, allowed=False,
            reason="target does not match any allowed scope entry",
            matched_rule=None,
        )

    def is_allowed(self, target: str) -> bool:
        return self.evaluate(target).allowed

    def require(self, target: str) -> ParsedTarget:
        decision = self.evaluate(target)
        if not decision.allowed:
            raise ScopeViolation(f"target {target!r} is out of scope: {decision.reason}")
        return parse_target(target)

    def require_active_authorization(self) -> None:
        if not self._scope.program.policy_reviewed:
            raise ScopeNotReviewedError(
                f"program {self._scope.program.name!r} has policy_reviewed=false; "
                "review the current program policy and set policy_reviewed: true "
                "before running any active test"
            )
        if not self._scope.settings.active_checks:
            raise ScopeNotReviewedError(
                "active_checks is disabled in the scope settings; enable it "
                "explicitly to permit active network testing"
            )
''')

# ---------------------------------------------------------------------------
# engine/
# ---------------------------------------------------------------------------
w("src/h1hunter/engine/__init__.py", r'''
"""Execution controls: rate limiting, budgets, and the safety engine."""

from __future__ import annotations

from h1hunter.engine.rate_limiter import TokenBucketRateLimiter
from h1hunter.engine.safety import SafetyEngine, SafetyPolicy

__all__ = ["SafetyEngine", "SafetyPolicy", "TokenBucketRateLimiter"]
''')

w("src/h1hunter/engine/rate_limiter.py", r'''
"""Async token-bucket rate limiter."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable

__all__ = ["TokenBucketRateLimiter"]


class TokenBucketRateLimiter:
    def __init__(
        self,
        rate: float,
        *,
        capacity: float | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] | None = None,
    ) -> None:
        if rate <= 0:
            raise ValueError("rate must be greater than zero")
        self._rate = float(rate)
        self._capacity = float(capacity) if capacity is not None else max(1.0, float(rate))
        if self._capacity <= 0:
            raise ValueError("capacity must be greater than zero")
        self._tokens = self._capacity
        self._clock = clock
        self._sleep: Callable[[float], Awaitable[None]] = sleep or asyncio.sleep
        self._updated = clock()
        self._lock = asyncio.Lock()

    @property
    def rate(self) -> float:
        return self._rate

    @property
    def capacity(self) -> float:
        return self._capacity

    @property
    def tokens(self) -> float:
        return self._tokens

    async def acquire(self, tokens: float = 1.0) -> float:
        if tokens <= 0:
            raise ValueError("tokens must be greater than zero")
        if tokens > self._capacity:
            raise ValueError(
                f"cannot acquire {tokens} tokens from a bucket of capacity {self._capacity}"
            )
        waited = 0.0
        async with self._lock:
            while True:
                now = self._clock()
                elapsed = now - self._updated
                if elapsed > 0:
                    self._tokens = min(
                        self._capacity, self._tokens + elapsed * self._rate
                    )
                    self._updated = now
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return waited
                delay = (tokens - self._tokens) / self._rate
                waited += delay
                await self._sleep(delay)
''')

w("src/h1hunter/engine/safety.py", r'''
"""The safety engine — the only path from target string to request."""

from __future__ import annotations

import logging
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field

from h1hunter.engine.rate_limiter import TokenBucketRateLimiter
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged, SafetyError,
)
from h1hunter.models.scope import ScopeConfig
from h1hunter.scope.validator import ScopeValidator
from h1hunter.utils.normalization import ParsedTarget
from h1hunter.utils.networking import ip_block_reason

__all__ = ["AuditEvent", "CircuitBreaker", "SafetyEngine", "SafetyPolicy"]

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SafetyPolicy:
    active_checks: bool = False
    max_concurrency: int = 3
    requests_per_second: float = 2.0
    timeout_seconds: float = 10.0
    max_response_bytes: int = 1_048_576
    max_requests: int = 500
    allow_private_networks: bool = False

    @classmethod
    def from_scope(cls, scope: ScopeConfig) -> "SafetyPolicy":
        s = scope.settings
        return cls(
            active_checks=s.active_checks and scope.program.policy_reviewed,
            max_concurrency=s.max_concurrency,
            requests_per_second=s.requests_per_second,
            timeout_seconds=s.timeout_seconds,
            max_response_bytes=s.max_response_bytes,
            max_requests=s.max_requests,
            allow_private_networks=s.allow_private_networks,
        )


@dataclass(frozen=True, slots=True)
class AuditEvent:
    timestamp: float
    action: str
    target: str
    decision: str
    detail: str = ""


@dataclass(slots=True)
class CircuitBreaker:
    failure_threshold: int = 5
    reset_timeout: float = 60.0
    _failures: int = field(default=0, init=False)
    _opened_at: float | None = field(default=None, init=False)

    def record_success(self) -> None:
        self._failures = 0
        self._opened_at = None

    def record_failure(self, *, now: float | None = None) -> None:
        self._failures += 1
        if self._failures >= self.failure_threshold and self._opened_at is None:
            self._opened_at = now if now is not None else time.monotonic()
            logger.warning(
                "circuit breaker opened after %d consecutive failures",
                self._failures,
            )

    @property
    def failure_count(self) -> int:
        return self._failures

    @property
    def is_open(self) -> bool:
        if self._opened_at is None:
            return False
        if (time.monotonic() - self._opened_at) >= self.reset_timeout:
            self._failures = 0
            self._opened_at = None
            return False
        return True


class SafetyEngine:
    def __init__(
        self,
        validator: ScopeValidator,
        policy: SafetyPolicy,
        *,
        limiter: TokenBucketRateLimiter | None = None,
        circuit_breaker: CircuitBreaker | None = None,
    ) -> None:
        self._validator = validator
        self._policy = policy
        self._limiter = limiter or TokenBucketRateLimiter(policy.requests_per_second)
        self._breaker = circuit_breaker or CircuitBreaker()
        self._requests = 0
        self._killed = False
        self._kill_reason: str | None = None
        self._audit: list[AuditEvent] = []

    @classmethod
    def from_scope(cls, scope: ScopeConfig) -> "SafetyEngine":
        return cls(ScopeValidator(scope), SafetyPolicy.from_scope(scope))

    @property
    def validator(self) -> ScopeValidator:
        return self._validator

    @property
    def policy(self) -> SafetyPolicy:
        return self._policy

    @property
    def requests_made(self) -> int:
        return self._requests

    @property
    def budget_remaining(self) -> int:
        return max(0, self._policy.max_requests - self._requests)

    @property
    def is_killed(self) -> bool:
        return self._killed

    @property
    def kill_reason(self) -> str | None:
        return self._kill_reason

    @property
    def audit_log(self) -> tuple[AuditEvent, ...]:
        return tuple(self._audit)

    def kill(self, reason: str) -> None:
        self._killed = True
        self._kill_reason = reason
        self._record("kill_switch", "-", "engaged", reason)
        logger.warning("kill switch engaged: %s", reason)

    def require_active_mode(self) -> None:
        if self._killed:
            raise KillSwitchEngaged(self._kill_reason or "kill switch engaged")
        if not self._policy.active_checks:
            raise SafetyError(
                "active checks are disabled by policy; refusing to send network "
                "traffic. Set 'active_checks: true' and 'policy_reviewed: true' "
                "in the scope file."
            )

    def check_destination(self, address: str) -> None:
        reason = ip_block_reason(
            address, allow_private=self._policy.allow_private_networks
        )
        if reason is not None:
            self._record("destination_check", address, "blocked", reason)
            raise DestinationBlocked(f"refusing to connect to {address}: {reason}")

    async def authorize(self, target: str) -> ParsedTarget:
        self.require_active_mode()
        if self._breaker.is_open:
            raise CircuitOpen("circuit breaker is open; pausing active requests")
        if self._requests >= self._policy.max_requests:
            raise BudgetExhausted(
                f"request budget of {self._policy.max_requests} exhausted"
            )
        parsed = self._validator.require(target)
        await self._limiter.acquire()
        self._requests += 1
        self._record("authorize", target, "allowed", f"normalized host {parsed.host}")
        return parsed

    def record_success(self) -> None:
        self._breaker.record_success()

    def record_failure(self) -> None:
        self._breaker.record_failure()

    @asynccontextmanager
    async def guard(self, target: str) -> AsyncIterator[ParsedTarget]:
        parsed = await self.authorize(target)
        try:
            yield parsed
        except Exception:
            self.record_failure()
            raise
        else:
            self.record_success()

    def _record(self, action: str, target: str, decision: str, detail: str = "") -> None:
        event = AuditEvent(
            timestamp=time.time(), action=action, target=target,
            decision=decision, detail=detail,
        )
        self._audit.append(event)
        logger.debug(
            "audit action=%s target=%s decision=%s detail=%s",
            action, target, decision, detail,
        )
''')

print("\nPart 2 complete. Next: build3.py (recon + providers).")
