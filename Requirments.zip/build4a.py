#!/usr/bin/env python3
"""h1hunter builder — Part 4a of 4.

Adds: checks (base + 5 modules), storage (SQLite), reporting (severity,
JSON/CSV/Markdown). Idempotent.
"""
from pathlib import Path

ROOT = Path("h1hunter")

def w(rel: str, content: str) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if content.startswith("\n"):
        content = content[1:]
    p.write_text(content, encoding="utf-8")
    print(f"  wrote {rel}")

if not ROOT.exists():
    raise SystemExit("ERROR: ./h1hunter/ not found. Run build1.py, build2.py, build3.py first.")

print(f"Extending {ROOT.resolve()}")

# ---------------------------------------------------------------------------
# checks/__init__.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/__init__.py", r'''
"""Low-impact security checks.

Every check runs through the centralized SafetyEngine and produces Finding
records. No check exploits, modifies state, or accesses data beyond what an
unauthenticated public visitor could already see.
"""

from __future__ import annotations

from h1hunter.checks.api_docs import ApiDocsCheck
from h1hunter.checks.exposure import ExposureCheck
from h1hunter.checks.headers import HeadersCheck
from h1hunter.checks.input_reflection import ReflectionCheck
from h1hunter.checks.tls import SocketTlsProbe, TlsCheck

__all__ = [
    "ApiDocsCheck", "ExposureCheck", "HeadersCheck", "ReflectionCheck",
    "SocketTlsProbe", "TlsCheck",
]
''')

# ---------------------------------------------------------------------------
# checks/base.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/base.py", r'''
"""Shared interfaces for check modules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import httpx

from h1hunter.engine.safety import SafetyEngine
from h1hunter.models.finding import Finding
from h1hunter.recon.dns import DnsResolverProtocol

__all__ = ["CheckContext", "CheckProtocol"]


@dataclass(frozen=True, slots=True)
class CheckContext:
    """Everything a check needs to run one target."""
    engine: SafetyEngine
    client: httpx.AsyncClient
    resolver: DnsResolverProtocol


class CheckProtocol(Protocol):
    """A security check module."""
    name: str
    category: str

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        """Return findings for ``target``. Must not raise on ordinary failures."""
        ...
''')

# ---------------------------------------------------------------------------
# checks/headers.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/headers.py", r'''
"""HTTP security header inspection.

Missing headers are reported with contextual severity. A missing header is
never classified as a vulnerability on its own.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult
from h1hunter.reporting.severity import missing_header_severity

__all__ = ["INSPECTED_HEADERS", "HeadersCheck"]

logger = logging.getLogger(__name__)

INSPECTED_HEADERS: tuple[str, ...] = (
    "content-security-policy",
    "strict-transport-security",
    "x-content-type-options",
    "referrer-policy",
    "permissions-policy",
)


class HeadersCheck:
    name = "headers"
    category = "security_headers"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        result = await self._prober.probe(target)
        if result.error is not None or result.status_code is None:
            logger.info("headers check skipped %s: %s", target, result.error)
            return []
        return _findings_from_probe(self, result)


def _findings_from_probe(check: HeadersCheck, result: ProbeResult) -> list[Finding]:
    findings: list[Finding] = []
    present = {k.lower() for k in result.headers}

    for header in INSPECTED_HEADERS:
        if header in present:
            continue
        if header == "strict-transport-security" and not result.final_url.startswith(
            "https://"
        ):
            continue

        severity, rationale = missing_header_severity(header)
        findings.append(
            Finding(
                id=Finding.make_id(
                    module=check.name,
                    category=f"missing_header:{header}",
                    asset=result.final_url,
                    endpoint=header,
                ),
                title=f"Missing security header: {header}",
                category=f"missing_header:{header}",
                affected_asset=result.final_url,
                affected_endpoint=header,
                detection_module=check.name,
                evidence={
                    "status_code": result.status_code,
                    "checked_headers": sorted(present),
                    "missing_header": header,
                    "response_bytes": result.body_bytes,
                },
                reproduction=(
                    f"GET {result.final_url} and inspect the response headers. "
                    f"The '{header}' header is not present."
                ),
                confidence=ConfidenceLevel.HIGH,
                severity=severity,
                severity_rationale=rationale,
                potential_impact=(
                    "Impact depends on the surrounding application and on "
                    "whether a separate injection or downgrade vector exists."
                ),
                remediation=f"Add an appropriate '{header}' response header.",
                scope_validation="in_scope",
                verification_status=VerificationStatus.UNVERIFIED,
            )
        )
    return findings
''')

# ---------------------------------------------------------------------------
# checks/tls.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/tls.py", r'''
"""TLS certificate and protocol inspection.

The check authorizes the target through the SafetyEngine, enforces the
destination policy, and then delegates the handshake to an injectable
``TlsProbe``. Certificate verification is ENABLED by default. Tests inject a
stub probe so no real socket is opened.
"""

from __future__ import annotations

import asyncio
import logging
import socket
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol

from h1hunter.checks.base import CheckContext
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged,
    SafetyError, ScopeViolation,
)
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.utils.normalization import ParsedTarget

__all__ = ["SocketTlsProbe", "TlsCheck", "TlsProbe", "TlsResult"]

logger = logging.getLogger(__name__)

_EXPIRY_WARN_DAYS = 30
_WEAK_PROTOCOLS = frozenset({"TLSv1", "TLSv1.1", "SSLv3"})


@dataclass(frozen=True, slots=True)
class TlsResult:
    host: str
    port: int
    subject: str | None = None
    issuer: str | None = None
    not_before: datetime | None = None
    not_after: datetime | None = None
    protocol: str | None = None
    cipher: str | None = None
    error: str | None = None


class TlsProbe(Protocol):
    async def inspect(self, host: str, port: int, timeout: float) -> TlsResult: ...


class SocketTlsProbe:
    """Real TLS probe using Python's ``ssl`` module.

    Certificate verification is enabled by default.
    """

    def __init__(self, *, verify: bool = True) -> None:
        self._verify = verify

    async def inspect(self, host: str, port: int, timeout: float) -> TlsResult:
        return await asyncio.get_running_loop().run_in_executor(
            None, self._inspect_sync, host, port, timeout
        )

    def _inspect_sync(self, host: str, port: int, timeout: float) -> TlsResult:
        context = ssl.create_default_context()
        if not self._verify:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        try:
            with socket.create_connection((host, port), timeout=timeout) as raw:
                with context.wrap_socket(raw, server_hostname=host) as tls:
                    cert = tls.getpeercert()
                    cipher = tls.cipher()
                    return TlsResult(
                        host=host, port=port,
                        subject=_format_name(cert.get("subject")),
                        issuer=_format_name(cert.get("issuer")),
                        not_before=_parse_cert_time(cert.get("notBefore")),
                        not_after=_parse_cert_time(cert.get("notAfter")),
                        protocol=tls.version(),
                        cipher=cipher[0] if cipher else None,
                    )
        except (ssl.SSLError, socket.error, OSError) as exc:
            return TlsResult(host=host, port=port, error=str(exc))


def _format_name(entries) -> str | None:
    if not entries:
        return None
    parts: list[str] = []
    for rdn in entries:
        for key, value in rdn:
            parts.append(f"{key}={value}")
    return ", ".join(parts) if parts else None


def _parse_cert_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.strptime(value, "%b %d %H:%M:%S %Y %Z")
    except ValueError:
        return None
    return parsed.replace(tzinfo=timezone.utc)


class TlsCheck:
    name = "tls"
    category = "tls"

    def __init__(self, probe: TlsProbe) -> None:
        self._probe = probe

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        try:
            parsed = await context.engine.authorize(target)
        except (
            ScopeViolation, SafetyError, BudgetExhausted,
            CircuitOpen, KillSwitchEngaged,
        ) as exc:
            logger.info("tls check skipped %s: %s", target, exc)
            return []

        scheme, host, port = _scheme_host_port(parsed)
        if scheme != "https":
            logger.info("tls check skipped %s: not an https target", target)
            return []

        try:
            await _enforce_destination(context, host)
        except (DestinationBlocked, SafetyError) as exc:
            logger.info("tls check refused %s: %s", host, exc)
            return []

        result = await self._probe.inspect(
            host, port, timeout=context.engine.policy.timeout_seconds
        )
        if result.error is not None:
            return [_error_finding(self, target, result)]
        return _lifetime_findings(self, target, result)


def _scheme_host_port(parsed: ParsedTarget) -> tuple[str, str, int]:
    scheme = parsed.scheme or "https"
    port = parsed.port or (443 if scheme == "https" else 80)
    return scheme, parsed.host, port


async def _enforce_destination(context: CheckContext, host: str) -> None:
    seen = False
    for rtype in ("A", "AAAA"):
        try:
            answers = await context.resolver.resolve(host, rtype)
        except Exception:  # noqa: BLE001
            continue
        for ip in answers:
            context.engine.check_destination(ip)
            seen = True
    if not seen:
        context.engine.check_destination(host)


def _error_finding(check: TlsCheck, target: str, result: TlsResult) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="tls_error", asset=target, endpoint=None,
        ),
        title="TLS handshake or certificate verification failed",
        category="tls_error",
        affected_asset=target,
        affected_endpoint=f"{result.host}:{result.port}",
        detection_module=check.name,
        evidence={"host": result.host, "port": result.port, "error": result.error},
        reproduction=(
            f"Connect to {result.host}:{result.port} with certificate "
            "verification enabled. The handshake fails."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.MEDIUM,
        severity_rationale=(
            "A failed TLS handshake prevents secure use of the endpoint. "
            "Exploitability depends on how the service is reached."
        ),
        potential_impact=(
            "Clients may be unable to establish a secure connection, or may "
            "fail closed and refuse the service."
        ),
        remediation=(
            "Renew or replace the certificate and ensure the full chain is "
            "served. Do not disable client verification to work around it."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )


def _lifetime_findings(check: TlsCheck, target: str, result: TlsResult) -> list[Finding]:
    findings: list[Finding] = []
    now = datetime.now(timezone.utc)

    if result.not_after is not None:
        remaining = (result.not_after - now).days
        if remaining <= 0:
            findings.append(
                _expiry_finding(check, target, result, remaining, expired=True)
            )
        elif remaining <= _EXPIRY_WARN_DAYS:
            findings.append(
                _expiry_finding(check, target, result, remaining, expired=False)
            )

    if result.protocol is not None and result.protocol in _WEAK_PROTOCOLS:
        findings.append(
            Finding(
                id=Finding.make_id(
                    module=check.name, category="tls_weak_protocol",
                    asset=target, endpoint=f"{result.host}:{result.port}",
                ),
                title=f"Deprecated TLS protocol negotiated: {result.protocol}",
                category="tls_weak_protocol",
                affected_asset=target,
                affected_endpoint=f"{result.host}:{result.port}",
                detection_module=check.name,
                evidence={"protocol": result.protocol, "cipher": result.cipher},
                reproduction=(
                    f"Connect to {result.host}:{result.port} and read the "
                    "negotiated protocol version."
                ),
                confidence=ConfidenceLevel.HIGH,
                severity=SeverityLevel.LOW,
                severity_rationale=(
                    "Deprecated TLS versions are weaker than TLS 1.2+. "
                    "Exploitation requires a network-position attacker."
                ),
                potential_impact=(
                    "Traffic may be recoverable or downgradeable by an "
                    "attacker positioned on the network path."
                ),
                remediation=(
                    "Disable TLS 1.0/1.1 and SSLv3; require TLS 1.2 or later."
                ),
                scope_validation="in_scope",
                verification_status=VerificationStatus.UNVERIFIED,
            )
        )
    return findings


def _expiry_finding(
    check: TlsCheck, target: str, result: TlsResult, remaining_days: int,
    *, expired: bool,
) -> Finding:
    category = "tls_certificate_expired" if expired else "tls_certificate_expiring"
    title = (
        "TLS certificate is expired" if expired
        else f"TLS certificate expires in {remaining_days} day(s)"
    )
    severity = SeverityLevel.MEDIUM if expired else SeverityLevel.LOW
    rationale = (
        "An expired certificate causes clients to fail closed. Impact is "
        "availability and trust, not direct compromise."
        if expired
        else "Imminent expiry will cause a service outage if not renewed."
    )
    return Finding(
        id=Finding.make_id(
            module=check.name, category=category, asset=target,
            endpoint=f"{result.host}:{result.port}",
        ),
        title=title,
        category=category,
        affected_asset=target,
        affected_endpoint=f"{result.host}:{result.port}",
        detection_module=check.name,
        evidence={
            "host": result.host, "port": result.port,
            "not_after": result.not_after.isoformat() if result.not_after else None,
            "subject": result.subject, "issuer": result.issuer,
            "days_remaining": remaining_days,
        },
        reproduction=f"Inspect the certificate served by {result.host}:{result.port}.",
        confidence=ConfidenceLevel.HIGH,
        severity=severity,
        severity_rationale=rationale,
        potential_impact=(
            "Clients will refuse to connect or users will see security "
            "warnings. Availability impact only."
        ),
        remediation="Renew the certificate before it expires.",
        scope_validation="in_scope",
        verification_status=VerificationStatus.UNVERIFIED,
    )
''')

# ---------------------------------------------------------------------------
# checks/exposure.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/exposure.py", r'''
"""Limited public-exposure checks.

Only a small, fixed allowlist of paths is requested. Response bodies are
NEVER stored. Evidence records only the HTTP status, content type, and
content length.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["EXPOSURE_PATHS", "ExposureCheck"]

logger = logging.getLogger(__name__)

EXPOSURE_PATHS: tuple[tuple[str, str, SeverityLevel], ...] = (
    ("/.well-known/security.txt", "expected", SeverityLevel.INFO),
    ("/robots.txt", "informational", SeverityLevel.INFO),
    ("/.env", "sensitive_file", SeverityLevel.MEDIUM),
    ("/.git/HEAD", "sensitive_file", SeverityLevel.MEDIUM),
    ("/.well-known/change-password", "informational", SeverityLevel.INFO),
)


class ExposureCheck:
    name = "exposure"
    category = "public_exposure"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        findings: list[Finding] = []
        base = target.rstrip("/")
        for path, kind, severity in EXPOSURE_PATHS:
            url = f"{base}{path}"
            result = await self._prober.probe(url)
            if result.status_code is None or result.status_code >= 400:
                continue
            if kind == "expected":
                continue
            findings.append(_finding_for(self, url, kind, severity, result))
        return findings


def _finding_for(
    check: ExposureCheck, url: str, kind: str,
    severity: SeverityLevel, result: ProbeResult,
) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category=f"exposed:{kind}", asset=url, endpoint=url,
        ),
        title=f"Publicly reachable path: {url}",
        category=f"exposed:{kind}",
        affected_asset=url,
        affected_endpoint=url,
        detection_module=check.name,
        evidence={
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "content_length": result.headers.get("content-length"),
            "body_bytes": result.body_bytes,
            "truncated": result.truncated,
        },
        reproduction=(
            f"Request {url} as an unauthenticated client and observe the "
            "status code. Do not exfiltrate any body content."
        ),
        confidence=ConfidenceLevel.LOW,
        severity=severity,
        severity_rationale=(
            "A reachable path is not proof of a vulnerability. Impact depends "
            "on whether the resource is intended to be public and whether it "
            "contains sensitive data. Manual verification is required."
        ),
        potential_impact=(
            "If the resource contains configuration, secrets, or source "
            "history, exposure could assist an attacker. This check does not "
            "download or verify any content."
        ),
        remediation=(
            "Confirm whether the path is intended to be public. If not, "
            "remove it from the web root or restrict access at the edge."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )
''')

# ---------------------------------------------------------------------------
# checks/api_docs.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/api_docs.py", r'''
"""API documentation discovery.

Checks a small set of conventional API-documentation locations. Discovery is
reported as informational. Presence of documentation is not a vulnerability.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["API_DOC_PATHS", "ApiDocsCheck"]

logger = logging.getLogger(__name__)

API_DOC_PATHS: tuple[str, ...] = (
    "/swagger.json", "/openapi.json", "/api-docs",
    "/swagger-ui.html", "/.well-known/openapi.json",
)


class ApiDocsCheck:
    name = "api_docs"
    category = "api_documentation"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        findings: list[Finding] = []
        base = target.rstrip("/")
        for path in API_DOC_PATHS:
            url = f"{base}{path}"
            result = await self._prober.probe(url)
            if result.status_code is None or result.status_code >= 400:
                continue
            findings.append(_finding_for(self, url, result))
        return findings


def _finding_for(check: ApiDocsCheck, url: str, result: ProbeResult) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="api_docs_reachable", asset=url, endpoint=url,
        ),
        title=f"Publicly reachable API documentation: {url}",
        category="api_docs_reachable",
        affected_asset=url,
        affected_endpoint=url,
        detection_module=check.name,
        evidence={
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "content_length": result.headers.get("content-length"),
            "body_bytes": result.body_bytes,
        },
        reproduction=(
            f"Request {url} as an unauthenticated client and observe the "
            "status code."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.INFO,
        severity_rationale=(
            "Publicly reachable API documentation is common and usually "
            "intended. It is informational because it may aid reconnaissance "
            "but is not a vulnerability on its own."
        ),
        potential_impact=(
            "Documentation may reveal endpoint names, parameters, or auth "
            "flows. Only meaningful when combined with an authorization flaw."
        ),
        remediation=(
            "Confirm that public documentation is intended. If not, restrict "
            "access at the edge or require authentication."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.UNVERIFIED,
    )
''')

# ---------------------------------------------------------------------------
# checks/input_reflection.py
# ---------------------------------------------------------------------------
w("src/h1hunter/checks/input_reflection.py", r'''
"""Harmless input reflection check.

A unique random marker string is inserted into one URL query parameter the
researcher has explicitly designated as a reflection test point. The response
is fetched through the SafetyEngine and inspected for the marker. No script,
no payload, no server-side code execution is attempted.

The finding explicitly states that reflection alone is NOT XSS.
"""

from __future__ import annotations

import logging
import secrets
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["ReflectionCheck"]

logger = logging.getLogger(__name__)


class ReflectionCheck:
    name = "reflection"
    category = "input_reflection"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        marker = _new_marker()
        injected_url = _inject_marker(target, marker)
        if injected_url is None:
            logger.info("reflection check skipped %s: no query parameters", target)
            return []

        result = await self._prober.probe(injected_url)
        if result.status_code is None or result.error is not None:
            return []
        if marker not in result.body_preview:
            return []
        return [_reflection_finding(self, target, injected_url, marker, result)]


def _new_marker() -> str:
    return "h1h" + secrets.token_hex(6)


def _inject_marker(url: str, marker: str) -> str | None:
    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    if not pairs:
        return None
    name, _ = pairs[0]
    new_pairs = [(name, marker)] + pairs[1:]
    return urlunsplit(
        (parts.scheme, parts.netloc, parts.path, urlencode(new_pairs), parts.fragment)
    )


def _reflection_finding(
    check: ReflectionCheck, target: str, injected_url: str,
    marker: str, result: ProbeResult,
) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="marker_reflected",
            asset=target, endpoint=injected_url,
        ),
        title="Marker string reflected in response body",
        category="marker_reflected",
        affected_asset=target,
        affected_endpoint=injected_url,
        detection_module=check.name,
        evidence={
            "marker": marker,
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "reflected": True,
        },
        reproduction=(
            f"Request {injected_url} and search the response body for the "
            f"marker {marker!r}. The marker is reflected."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.INFO,
        severity_rationale=(
            "Reflection alone is NOT cross-site scripting. Whether the "
            "reflection is exploitable depends on the execution context, "
            "encoding, and content type. Manual verification is required."
        ),
        potential_impact=(
            "If the reflection occurs in an executable context without "
            "appropriate encoding, it may be exploitable as XSS. In JSON, "
            "plain text, or properly encoded HTML, impact is low or none."
        ),
        remediation=(
            "Confirm the reflection is intentional. Contextually encode all "
            "output and add a Content-Security-Policy that would prevent "
            "script execution."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )
''')

# ---------------------------------------------------------------------------
# storage/__init__.py
# ---------------------------------------------------------------------------
w("src/h1hunter/storage/__init__.py", r'''
"""Persistence for discovered assets."""

from __future__ import annotations

from h1hunter.storage.database import Database
from h1hunter.storage.repositories import AssetRepository

__all__ = ["AssetRepository", "Database"]
''')

# ---------------------------------------------------------------------------
# storage/database.py
# ---------------------------------------------------------------------------
w("src/h1hunter/storage/database.py", r'''
"""SQLite persistence layer.

All writes use parameterized queries. Records are validated by the ``Asset``
model before they are handed to a repository, so the schema stores only
already-validated data.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from h1hunter.exceptions import StorageError

__all__ = ["Database", "SCHEMA_SQL"]

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS assets (
    hostname        TEXT PRIMARY KEY,
    domain          TEXT,
    source          TEXT NOT NULL,
    discovered_at   TEXT NOT NULL,
    scope_status    TEXT NOT NULL,
    dns_records     TEXT NOT NULL DEFAULT '{}',
    metadata        TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_assets_domain       ON assets(domain);
CREATE INDEX IF NOT EXISTS idx_assets_scope_status ON assets(scope_status);
CREATE INDEX IF NOT EXISTS idx_assets_discovered   ON assets(discovered_at);
"""


class Database:
    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._conn: sqlite3.Connection | None = None

    @property
    def path(self) -> Path:
        return self._path

    @property
    def connection(self) -> sqlite3.Connection:
        if self._conn is None:
            raise StorageError("database is not open; use it as a context manager")
        return self._conn

    def open(self) -> sqlite3.Connection:
        if self._conn is None:
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                self._conn = sqlite3.connect(str(self._path))
            except (OSError, sqlite3.Error) as exc:
                raise StorageError(
                    f"cannot open database {self._path}: {exc}"
                ) from exc
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA foreign_keys = ON")
            self._conn.execute("PRAGMA journal_mode = WAL")
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def initialize_schema(self) -> None:
        conn = self.open()
        try:
            with conn:
                conn.executescript(SCHEMA_SQL)
        except sqlite3.Error as exc:
            raise StorageError(
                f"cannot initialize schema in {self._path}: {exc}"
            ) from exc

    def __enter__(self) -> "Database":
        self.open()
        self.initialize_schema()
        return self

    def __exit__(self, *_exc_info: object) -> bool:
        self.close()
        return False
''')

# ---------------------------------------------------------------------------
# storage/repositories.py
# ---------------------------------------------------------------------------
w("src/h1hunter/storage/repositories.py", r'''
"""Repositories over the SQLite schema.

Upserts merge a new discovery into an existing record: the earliest
``discovered_at`` wins, and ``metadata.sources`` accumulates every contributing
source. The schema is never widened by data.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset, ScopeStatus
from h1hunter.storage.database import Database

__all__ = ["AssetRepository"]

logger = logging.getLogger(__name__)


def _iso(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


def _parse_iso(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _row_to_asset(row: sqlite3.Row) -> Asset:
    return Asset(
        hostname=row["hostname"],
        domain=row["domain"],
        source=row["source"],
        discovered_at=_parse_iso(row["discovered_at"]),
        scope_status=ScopeStatus(row["scope_status"]),
        dns_records=json.loads(row["dns_records"] or "{}"),
        metadata=json.loads(row["metadata"] or "{}"),
    )


class AssetRepository:
    def __init__(self, database: Database) -> None:
        self._db = database

    def upsert(self, asset: Asset) -> None:
        conn = self._db.connection
        try:
            with conn:
                existing_row = conn.execute(
                    "SELECT * FROM assets WHERE hostname = ?", (asset.hostname,),
                ).fetchone()
                if existing_row is None:
                    conn.execute(
                        """
                        INSERT INTO assets
                            (hostname, domain, source, discovered_at,
                             scope_status, dns_records, metadata)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            asset.hostname, asset.domain, asset.source,
                            _iso(asset.discovered_at), asset.scope_status.value,
                            json.dumps(asset.dns_records, sort_keys=True),
                            json.dumps(asset.metadata, sort_keys=True, default=str),
                        ),
                    )
                    return
                merged = self._merge(_row_to_asset(existing_row), asset)
                conn.execute(
                    """
                    UPDATE assets SET
                        domain = ?, source = ?, discovered_at = ?,
                        scope_status = ?, dns_records = ?, metadata = ?
                    WHERE hostname = ?
                    """,
                    (
                        merged.domain, merged.source, _iso(merged.discovered_at),
                        merged.scope_status.value,
                        json.dumps(merged.dns_records, sort_keys=True),
                        json.dumps(merged.metadata, sort_keys=True, default=str),
                        merged.hostname,
                    ),
                )
        except sqlite3.Error as exc:
            raise StorageError(f"failed to upsert {asset.hostname}: {exc}") from exc

    def upsert_many(self, assets: Iterable[Asset]) -> int:
        count = 0
        for asset in assets:
            self.upsert(asset)
            count += 1
        return count

    def get(self, hostname: str) -> Asset | None:
        conn = self._db.connection
        try:
            row = conn.execute(
                "SELECT * FROM assets WHERE hostname = ?", (hostname,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to load {hostname}: {exc}") from exc
        return _row_to_asset(row) if row is not None else None

    def list_all(self) -> list[Asset]:
        conn = self._db.connection
        try:
            rows = conn.execute("SELECT * FROM assets ORDER BY hostname").fetchall()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to list assets: {exc}") from exc
        return [_row_to_asset(row) for row in rows]

    def count(self) -> int:
        conn = self._db.connection
        try:
            row = conn.execute("SELECT COUNT(*) AS n FROM assets").fetchone()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to count assets: {exc}") from exc
        return int(row["n"]) if row is not None else 0

    @staticmethod
    def _merge(existing: Asset, incoming: Asset) -> Asset:
        earlier = existing if existing.discovered_at <= incoming.discovered_at else incoming
        later = incoming if earlier is existing else existing
        sources = set(earlier.metadata.get("sources", []))
        sources.update(later.metadata.get("sources", []))
        sources.add(earlier.source)
        sources.add(later.source)
        metadata = dict(earlier.metadata)
        for key, value in later.metadata.items():
            metadata.setdefault(key, value)
        metadata["sources"] = sorted(sources)
        metadata["first_seen"] = _iso(earlier.discovered_at)
        metadata["last_seen"] = _iso(later.discovered_at)
        dns_records: dict[str, list[str]] = {
            k: list(v) for k, v in earlier.dns_records.items()
        }
        for rtype, values in later.dns_records.items():
            bucket = dns_records.setdefault(rtype, [])
            for value in values:
                if value not in bucket:
                    bucket.append(value)
            bucket.sort()
        return Asset(
            hostname=earlier.hostname,
            domain=earlier.domain or later.domain,
            source=earlier.source,
            discovered_at=earlier.discovered_at,
            scope_status=earlier.scope_status,
            dns_records=dns_records,
            metadata=metadata,
        )
''')

# ---------------------------------------------------------------------------
# reporting/__init__.py
# ---------------------------------------------------------------------------
w("src/h1hunter/reporting/__init__.py", r'''
"""JSON, CSV, and Markdown exports for assets and findings."""

from __future__ import annotations

from h1hunter.reporting.csv_report import write_csv, write_findings_csv
from h1hunter.reporting.json_report import (
    read_findings_json, write_findings_json, write_json, write_records_json,
)
from h1hunter.reporting.markdown_report import (
    render_findings_markdown, write_findings_markdown,
)

__all__ = [
    "read_findings_json", "render_findings_markdown", "write_csv",
    "write_findings_csv", "write_findings_json", "write_findings_markdown",
    "write_json", "write_records_json",
]
''')

# ---------------------------------------------------------------------------
# reporting/severity.py
# ---------------------------------------------------------------------------
w("src/h1hunter/reporting/severity.py", r'''
"""Severity helpers.

Every severity in this toolkit is a conservative estimate. None of these
values are CVSS scores, and none of them predict a bounty outcome.
"""

from __future__ import annotations

from h1hunter.models.finding import SeverityLevel

__all__ = ["missing_header_severity", "merge_severity", "severity_order"]

_MISSING_HEADER_SEVERITY: dict[str, tuple[SeverityLevel, str]] = {
    "content-security-policy": (
        SeverityLevel.LOW,
        "CSP reduces the impact of injected content. Its absence is not "
        "exploitable on its own; impact depends on whether an injection "
        "point exists.",
    ),
    "strict-transport-security": (
        SeverityLevel.LOW,
        "HSTS prevents downgrade attacks and cookie theft on first visit. "
        "Absence requires a network-position attacker to exploit.",
    ),
    "x-content-type-options": (
        SeverityLevel.INFO,
        "X-Content-Type-Options: nosniff blocks MIME sniffing. Impact is "
        "contextual and typically secondary to another issue.",
    ),
    "referrer-policy": (
        SeverityLevel.INFO,
        "Referrer-Policy controls URL leakage to third parties. Missing "
        "policy is a privacy consideration, not a direct vulnerability.",
    ),
    "permissions-policy": (
        SeverityLevel.INFO,
        "Permissions-Policy restricts powerful browser features. Absence is "
        "informational unless a specific feature is being abused.",
    ),
}


def missing_header_severity(header_name: str) -> tuple[SeverityLevel, str]:
    key = header_name.lower()
    if key in _MISSING_HEADER_SEVERITY:
        return _MISSING_HEADER_SEVERITY[key]
    return (
        SeverityLevel.INFO,
        f"Missing {header_name} is informational without corroborating evidence.",
    )


def severity_order(level: SeverityLevel) -> int:
    return level.rank


def merge_severity(a: SeverityLevel, b: SeverityLevel) -> SeverityLevel:
    return a if a.rank >= b.rank else b
''')

# ---------------------------------------------------------------------------
# reporting/json_report.py
# ---------------------------------------------------------------------------
w("src/h1hunter/reporting/json_report.py", r'''
"""JSON export for asset and finding records."""

from __future__ import annotations

import dataclasses
import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset
from h1hunter.models.finding import Finding

__all__ = [
    "write_json", "write_records_json", "write_findings_json", "read_findings_json",
]


def write_json(assets: Iterable[Asset], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    payload = [asset.model_dump(mode="json") for asset in assets]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def _to_mapping(record: Any) -> Any:
    if dataclasses.is_dataclass(record) and not isinstance(record, type):
        return dataclasses.asdict(record)
    if hasattr(record, "model_dump"):
        return record.model_dump(mode="json")
    if isinstance(record, Mapping):
        return dict(record)
    return record


def write_records_json(records: Iterable[Any], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    payload = [_to_mapping(r) for r in records]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                payload, indent=2, sort_keys=True, ensure_ascii=False, default=str,
            ) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def write_findings_json(findings: Iterable[Finding], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    payload = [f.model_dump(mode="json") for f in ordered]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                payload, indent=2, sort_keys=True, ensure_ascii=False, default=str,
            ) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def read_findings_json(path: str | Path) -> list[Finding]:
    source = Path(path)
    if not source.exists():
        raise StorageError(f"findings file not found: {source}")
    try:
        text = source.read_text(encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot read {source}: {exc}") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise StorageError(f"invalid JSON in {source}: {exc}") from exc
    if not isinstance(data, list):
        raise StorageError(f"findings file must contain a JSON array: {source}")
    return [Finding.model_validate(entry) for entry in data]
''')

# ---------------------------------------------------------------------------
# reporting/csv_report.py
# ---------------------------------------------------------------------------
w("src/h1hunter/reporting/csv_report.py", r'''
"""CSV export for assets and findings."""

from __future__ import annotations

import csv
from collections.abc import Iterable
from pathlib import Path

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset
from h1hunter.models.finding import Finding

__all__ = [
    "CSV_COLUMNS", "FINDING_CSV_COLUMNS", "write_csv", "write_findings_csv",
]

CSV_COLUMNS = (
    "hostname", "domain", "source", "discovered_at", "scope_status",
    "sources", "first_seen", "last_seen", "discovery_count",
    "dns_record_types", "dns_record_count",
)

FINDING_CSV_COLUMNS = (
    "id", "title", "category", "severity", "confidence",
    "verification_status", "affected_asset", "affected_endpoint",
    "detection_module", "discovered_at", "severity_rationale", "remediation",
)


def _row(asset: Asset) -> dict[str, str]:
    meta = asset.metadata or {}
    sources = meta.get("sources") or [asset.source]
    return {
        "hostname": asset.hostname,
        "domain": asset.domain or "",
        "source": asset.source,
        "discovered_at": asset.discovered_at.isoformat(),
        "scope_status": asset.scope_status.value,
        "sources": ";".join(str(s) for s in sources),
        "first_seen": str(meta.get("first_seen", asset.discovered_at.isoformat())),
        "last_seen": str(meta.get("last_seen", asset.discovered_at.isoformat())),
        "discovery_count": str(meta.get("discovery_count", 1)),
        "dns_record_types": ";".join(sorted(asset.dns_records)),
        "dns_record_count": str(sum(len(v) for v in asset.dns_records.values())),
    }


def write_csv(assets: Iterable[Asset], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(assets, key=lambda a: a.hostname)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
            writer.writeheader()
            for asset in ordered:
                writer.writerow(_row(asset))
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def write_findings_csv(findings: Iterable[Finding], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FINDING_CSV_COLUMNS)
            writer.writeheader()
            for finding in ordered:
                writer.writerow({
                    "id": finding.id, "title": finding.title,
                    "category": finding.category,
                    "severity": finding.severity.value,
                    "confidence": finding.confidence.value,
                    "verification_status": finding.verification_status.value,
                    "affected_asset": finding.affected_asset,
                    "affected_endpoint": finding.affected_endpoint or "",
                    "detection_module": finding.detection_module,
                    "discovered_at": finding.discovered_at.isoformat(),
                    "severity_rationale": finding.severity_rationale,
                    "remediation": finding.remediation,
                })
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target
''')

# ---------------------------------------------------------------------------
# reporting/markdown_report.py
# ---------------------------------------------------------------------------
w("src/h1hunter/reporting/markdown_report.py", r'''
"""Markdown report for findings.

Designed as a HackerOne draft: title, severity, evidence, impact, and
remediation, with an explicit statement of what has NOT been verified.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path

from h1hunter.exceptions import StorageError
from h1hunter.models.finding import Finding, SeverityLevel

__all__ = ["render_findings_markdown", "write_findings_markdown"]

_SEVERITY_ICON = {
    SeverityLevel.CRITICAL: "[CRITICAL]",
    SeverityLevel.HIGH: "[HIGH]",
    SeverityLevel.MEDIUM: "[MEDIUM]",
    SeverityLevel.LOW: "[LOW]",
    SeverityLevel.INFO: "[INFO]",
}


def render_findings_markdown(
    findings: Iterable[Finding],
    *,
    program_name: str = "unknown",
    generated_at: datetime | None = None,
) -> str:
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    when = generated_at or datetime.now(timezone.utc)
    lines: list[str] = []
    lines.append(f"# h1hunter findings — {program_name}")
    lines.append("")
    lines.append(f"_Generated {when.isoformat()} — {len(ordered)} finding(s)._")
    lines.append("")
    lines.append(
        "> **Authorization notice.** Findings are heuristic observations "
        "produced by automated checks against assets explicitly listed in the "
        "operator's scope file. Nothing here has been verified by hand unless "
        "the finding's verification status says so. Do not paste this report "
        "directly into a HackerOne submission without manual review."
    )
    lines.append("")
    if not ordered:
        lines.append("_No findings._")
        return "\n".join(lines) + "\n"
    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("| --- | --- |")
    for level in (
        SeverityLevel.CRITICAL, SeverityLevel.HIGH, SeverityLevel.MEDIUM,
        SeverityLevel.LOW, SeverityLevel.INFO,
    ):
        count = sum(1 for f in ordered if f.severity is level)
        if count:
            lines.append(f"| {level.value} | {count} |")
    lines.append("")
    for finding in ordered:
        lines.extend(_render_finding(finding))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _render_finding(finding: Finding) -> list[str]:
    lines: list[str] = []
    lines.append(f"## {_SEVERITY_ICON[finding.severity]} {finding.title}")
    lines.append("")
    lines.append(f"- **ID:** `{finding.id}`")
    lines.append(f"- **Category:** `{finding.category}`")
    lines.append(f"- **Severity:** {finding.severity.value}")
    lines.append(f"- **Confidence:** {finding.confidence.value}")
    lines.append(f"- **Verification:** {finding.verification_status.value}")
    lines.append(f"- **Detected by:** `{finding.detection_module}`")
    lines.append(f"- **Affected asset:** `{finding.affected_asset}`")
    if finding.affected_endpoint:
        lines.append(f"- **Endpoint:** `{finding.affected_endpoint}`")
    lines.append(f"- **Discovered:** {finding.discovered_at.isoformat()}")
    lines.append("")
    if finding.severity_rationale:
        lines.append("**Severity rationale.** " + finding.severity_rationale)
        lines.append("")
    if finding.potential_impact:
        lines.append("**Potential impact.** " + finding.potential_impact)
        lines.append("")
    if finding.reproduction:
        lines.append("**Reproduction.**")
        lines.append("")
        lines.append("```")
        lines.append(finding.reproduction)
        lines.append("```")
        lines.append("")
    if finding.evidence:
        lines.append("**Evidence.**")
        lines.append("")
        lines.append("```json")
        lines.append(
            json.dumps(finding.evidence, indent=2, sort_keys=True, default=str)
        )
        lines.append("```")
        lines.append("")
    if finding.remediation:
        lines.append("**Suggested remediation.** " + finding.remediation)
        lines.append("")
    return lines


def write_findings_markdown(
    findings: Iterable[Finding],
    path: str | Path,
    *,
    program_name: str = "unknown",
) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    text = render_findings_markdown(findings, program_name=program_name)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target
''')

print("\nPart 4a complete. Next: build4b.py (CLI, docs, tests, zip).")
