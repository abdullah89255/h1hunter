#!/usr/bin/env python3
"""h1hunter builder — Part 1 of 4.

Creates the project root, config examples, utils, and models.
Idempotent: safe to re-run.
"""
from pathlib import Path
import sys

ROOT = Path("h1hunter")

def w(rel: str, content: str) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    # Normalize: strip a single leading newline from each block
    if content.startswith("\n"):
        content = content[1:]
    p.write_text(content, encoding="utf-8")
    print(f"  wrote {rel}")

def d(rel: str) -> None:
    (ROOT / rel).mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Directory tree
# ---------------------------------------------------------------------------
for sub in [
    "config",
    "docs",
    "src/h1hunter/models",
    "src/h1hunter/scope",
    "src/h1hunter/engine",
    "src/h1hunter/recon/providers",
    "src/h1hunter/checks",
    "src/h1hunter/storage",
    "src/h1hunter/reporting",
    "src/h1hunter/utils",
    "tests/unit",
    "tests/integration",
    "tests/fixtures",
]:
    d(sub)

print(f"Building in {ROOT.resolve()}")

# ---------------------------------------------------------------------------
# pyproject.toml
# ---------------------------------------------------------------------------
w("pyproject.toml", r'''
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "h1hunter"
version = "0.4.0"
description = "Safe-by-default reconnaissance and low-impact check toolkit for authorized HackerOne programs."
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }
dependencies = [
    "httpx>=0.27,<0.29",
    "dnspython>=2.6,<3",
    "pydantic>=2.7,<3",
    "PyYAML>=6.0.1,<7",
    "rich>=13.7,<14",
    "idna>=3.6,<4",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.2,<9",
    "pytest-asyncio>=0.23,<1",
    "respx>=0.21,<1",
    "ruff>=0.5",
    "mypy>=1.10",
]

[project.scripts]
h1hunter = "h1hunter.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/h1hunter"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
asyncio_mode = "auto"
asyncio_default_fixture_loop_scope = "function"
markers = [
    "safety: safety-critical regression tests (must never be skipped)",
]

[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "UP", "B", "SIM", "C4", "RET", "PTH", "S"]
ignore = ["S101"]

[tool.mypy]
python_version = "3.12"
strict = true
files = ["src/h1hunter"]
''')

# ---------------------------------------------------------------------------
# .gitignore
# ---------------------------------------------------------------------------
w(".gitignore", r'''
__pycache__/
*.py[cod]
.venv/
venv/
.env
*.egg-info/
dist/
build/
.pytest_cache/
.mypy_cache/
.ruff_cache/
output/
logs/
config/config.yaml
config/scope.yaml
*.sqlite3
''')

# ---------------------------------------------------------------------------
# .env.example
# ---------------------------------------------------------------------------
w(".env.example", r'''
# h1hunter reads optional credentials from the environment only.
# Never commit real values. Never place credentials in config/*.yaml.
#
# H1HUNTER_USER_AGENT="h1hunter/0.4 (+authorized-security-research; contact=you@example.test)"
''')

# ---------------------------------------------------------------------------
# LICENSE
# ---------------------------------------------------------------------------
w("LICENSE", r'''
MIT License

Copyright (c) 2025 h1hunter contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
''')

# ---------------------------------------------------------------------------
# README.md
# ---------------------------------------------------------------------------
w("README.md", r'''
# h1hunter

Safe-by-default reconnaissance and low-impact check toolkit for authorized
HackerOne bug bounty programs.

## Phases

- **Phase 1** — scope enforcement, safety engine, dry-run planning.
- **Phase 2** — passive reconnaissance (local files only), asset storage, JSON/CSV export.
- **Phase 3** — opt-in DNS inspection and HTTP probing with redirect re-validation,
  size caps, concurrency limits, request budgets, cancellation, kill switch.
- **Phase 4** — security-header, TLS, exposure, API-docs, and reflection checks;
  normalized finding model; deduplication; JSON/CSV/Markdown reports.

## Requirements

- Python 3.12+

## Install

### Linux / macOS

    python3.12 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

### Windows PowerShell

    py -3.12 -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

### Windows Command Prompt

    py -3.12 -m venv .venv
    .venv\Scripts\activate.bat
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

## Configure

    cp config/config.example.yaml config/config.yaml
    cp config/scope.example.yaml  config/scope.yaml

Edit `config/scope.yaml` and replace every placeholder with assets you are
authorized to test. Set `program.policy_reviewed: true` only after reading the
current program policy. Active testing also requires `settings.active_checks: true`.

## Commands

    h1hunter version
    h1hunter scope validate --file config/scope.yaml
    h1hunter scope check    --file config/scope.yaml --target https://api.example.net/v1
    h1hunter plan           --file config/scope.yaml --targets example.com attacker.test

    h1hunter recon passive  --file config/scope.yaml --config config/config.yaml \
                            --output output/passive.json --db output/assets.db
    h1hunter recon dns      --file config/scope.yaml --targets-file data/hosts.txt --dry-run
    h1hunter recon probe    --file config/scope.yaml --targets-file data/urls.txt  --dry-run

    h1hunter check headers  --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check tls      --file config/scope.yaml --targets-file data/hosts.txt --dry-run
    h1hunter check exposure --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check api-docs --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check reflection --file config/scope.yaml \
                              --target "https://www.example.com/search?q=x" --dry-run

    h1hunter report --input output/headers.json --format markdown --output output/headers.md

## Tests

    pytest -q                # full suite
    pytest -q -m safety      # safety regression suite only

Every test uses `httpx.MockTransport`, stub resolvers, or stub TLS probes.
No test opens a socket.

## Authorization

Authorization depends on the current program policy, not on domain ownership and
not on whether a host responds to a probe. Never scan a target you are not
explicitly permitted to test.
''')

# ---------------------------------------------------------------------------
# config examples
# ---------------------------------------------------------------------------
w("config/config.example.yaml", r'''
# h1hunter application configuration (example).
# Copy to config/config.yaml — that path is git-ignored.

timeout_seconds: 10.0
max_concurrency: 3
requests_per_second: 2.0
max_retries: 2
max_requests: 500
max_response_bytes: 1048576
output_dir: output
user_agent: "h1hunter/0.4 (+authorized-security-research; contact=you@example.test)"

logging:
  level: WARNING
  format: console
  file: null

enabled_modules: []

passive_sources:
  - name: imported-subdomains
    enabled: false
    options:
      type: text
      path: data/subdomains.txt
  - name: curated-assets
    enabled: false
    options:
      type: file
      path: data/assets.json
''')

w("config/scope.example.yaml", r'''
# Replace EVERY entry below with assets you are actually authorized to test.

program:
  name: example-program
  policy_reviewed: false
  policy_url: https://hackerone.com/example-program
  authorized_by: you@example.test

allowed:
  - "*.example.com"
  - "example.org"
  - "https://api.example.net/v1"
  - "203.0.113.10"
  - "198.51.100.0/24"

excluded:
  - "admin.example.com"
  - "*.internal.example.com"

settings:
  passive_recon: true
  active_checks: false
  max_concurrency: 3
  requests_per_second: 2
  timeout_seconds: 10
  max_requests: 500
  max_response_bytes: 1048576
  allow_private_networks: false
''')

# ---------------------------------------------------------------------------
# src/h1hunter root files
# ---------------------------------------------------------------------------
w("src/h1hunter/__init__.py", r'''
"""h1hunter — safe-by-default reconnaissance toolkit for authorized HackerOne programs."""

from __future__ import annotations

__version__ = "0.4.0"
__all__ = ["__version__"]
''')

w("src/h1hunter/__main__.py", r'''
"""Allow ``python -m h1hunter``."""

from __future__ import annotations

from h1hunter.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
''')

w("src/h1hunter/main.py", r'''
"""Console entry point referenced by the ``h1hunter`` script."""

from __future__ import annotations

from h1hunter.cli import main

__all__ = ["main"]

if __name__ == "__main__":
    raise SystemExit(main())
''')

w("src/h1hunter/exceptions.py", r'''
"""Exception hierarchy for h1hunter."""

from __future__ import annotations

__all__ = [
    "H1HunterError",
    "ConfigurationError",
    "ScopeError",
    "ScopeParseError",
    "ScopeViolation",
    "ScopeNotReviewedError",
    "SafetyError",
    "KillSwitchEngaged",
    "BudgetExhausted",
    "CircuitOpen",
    "DestinationBlocked",
    "PassiveSourceError",
    "StorageError",
]


class H1HunterError(Exception):
    """Base class for all h1hunter errors."""


class ConfigurationError(H1HunterError):
    """Configuration is missing, unreadable, or fails validation."""


class ScopeError(H1HunterError):
    """Base class for scope-related failures."""


class ScopeParseError(ScopeError):
    """A scope entry or scope file could not be parsed or validated."""


class ScopeViolation(ScopeError):
    """A target is not authorized by the active program scope."""


class ScopeNotReviewedError(ScopeViolation):
    """Active testing was attempted without a reviewed policy or explicit opt-in."""


class SafetyError(H1HunterError):
    """Base class for safety-control refusals."""


class KillSwitchEngaged(SafetyError):
    """The kill switch is engaged; no further requests are permitted."""


class BudgetExhausted(SafetyError):
    """The configured request budget has been exhausted."""


class CircuitOpen(SafetyError):
    """The circuit breaker is open after repeated failures."""


class DestinationBlocked(SafetyError):
    """A resolved network destination is not permitted by policy."""


class PassiveSourceError(H1HunterError):
    """A passive reconnaissance source could not be loaded or read."""


class StorageError(H1HunterError):
    """A persistence or export operation failed."""
''')

w("src/h1hunter/logging_config.py", r'''
"""Structured logging with mandatory secret redaction."""

from __future__ import annotations

import json
import logging
import re
import sys
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from rich.logging import RichHandler

__all__ = [
    "REDACTED",
    "SENSITIVE_KEYS",
    "JsonFormatter",
    "RedactionFilter",
    "configure_logging",
    "redact_mapping",
    "redact_text",
]

REDACTED = "***REDACTED***"

SENSITIVE_KEYS = frozenset(
    {
        "authorization", "proxy-authorization", "cookie", "set-cookie",
        "x-api-key", "x-auth-token", "api-key", "api_key", "apikey",
        "access-token", "access_token", "refresh-token", "refresh_token",
        "client-secret", "client_secret", "password", "passwd", "secret",
        "private-key", "private_key", "session", "sessionid", "session-id",
    }
)

_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)\b(authorization|proxy-authorization)\s*:\s*\S+"),
     r"\1: " + REDACTED),
    (re.compile(r"(?i)\b(cookie|set-cookie)\s*:\s*\S+"), r"\1: " + REDACTED),
    (re.compile(
        r"(?i)\b(api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret"
        r"|password|passwd|secret)\b\s*[=:]\s*\S+"
     ), r"\1: " + REDACTED),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/\-=]+"), "Bearer " + REDACTED),
)


def _normalize_key(key: str) -> str:
    return key.strip().lower().replace("_", "-")


def redact_text(text: str) -> str:
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def redact_mapping(data: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in data.items():
        if _normalize_key(str(key)) in SENSITIVE_KEYS:
            result[key] = REDACTED
        elif isinstance(value, Mapping):
            result[key] = redact_mapping(value)
        elif isinstance(value, (list, tuple)):
            result[key] = [
                redact_mapping(item) if isinstance(item, Mapping) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


class RedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = redact_text(record.msg)
        args = record.args
        if isinstance(args, Mapping):
            record.args = redact_mapping(args)
        elif isinstance(args, tuple):
            record.args = tuple(
                redact_text(item) if isinstance(item, str) else item
                for item in args
            )
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(
    *,
    level: str = "WARNING",
    fmt: str = "console",
    file: str | None = None,
    no_color: bool = False,
) -> None:
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
        handler.close()

    root.setLevel(level.upper())
    redaction = RedactionFilter()

    if fmt == "json":
        stream_handler: logging.Handler = logging.StreamHandler(sys.stderr)
        stream_handler.setFormatter(JsonFormatter())
    else:
        stream_handler = RichHandler(
            rich_tracebacks=True,
            show_path=False,
            markup=False,
            console_kwargs={"no_color": no_color, "stderr": True},
        )
        stream_handler.setFormatter(logging.Formatter("%(message)s"))

    stream_handler.addFilter(redaction)
    root.addHandler(stream_handler)

    if file:
        fh = logging.FileHandler(file, encoding="utf-8")
        fh.setFormatter(JsonFormatter())
        fh.addFilter(redaction)
        root.addHandler(fh)
''')

# ---------------------------------------------------------------------------
# utils
# ---------------------------------------------------------------------------
w("src/h1hunter/utils/__init__.py", r'''
"""Pure helpers with no project-internal dependencies."""

from __future__ import annotations
''')

w("src/h1hunter/utils/normalization.py", r'''
"""Hostname, path, and target normalization."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from urllib.parse import urlsplit

import idna

from h1hunter.exceptions import ScopeParseError

__all__ = [
    "ParsedTarget", "normalize_hostname", "normalize_path", "parse_target",
    "is_ip_literal", "to_ip", "derive_domain",
]

Address = ipaddress.IPv4Address | ipaddress.IPv6Address

_ASCII_LABEL_RE = re.compile(r"^[a-z0-9_]([a-z0-9_-]*[a-z0-9_])?$")
_SUPPORTED_SCHEMES = frozenset({"http", "https"})


def _strip_brackets(value: str) -> str:
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        return value[1:-1]
    return value


def is_ip_literal(value: str) -> bool:
    if not isinstance(value, str):
        return False
    try:
        ipaddress.ip_address(_strip_brackets(value))
    except ValueError:
        return False
    return True


def to_ip(value: str) -> Address:
    try:
        return ipaddress.ip_address(_strip_brackets(value))
    except ValueError as exc:
        raise ScopeParseError(f"not an IP address: {value!r}") from exc


def _to_ascii(host: str) -> str:
    try:
        return idna.encode(host, uts46=True).decode("ascii")
    except idna.IDNAError as exc:
        if _ascii_fallback(host) is not None:
            return host
        raise ScopeParseError(f"invalid hostname {host!r}: {exc}") from exc


def _ascii_fallback(host: str) -> str | None:
    labels = host.split(".")
    if not labels:
        return None
    for label in labels:
        if not label or len(label) > 63:
            return None
        if not _ASCII_LABEL_RE.match(label):
            return None
    if len(host) > 253:
        return None
    return host


def normalize_hostname(host: str) -> str:
    if not isinstance(host, str):
        raise ScopeParseError(f"hostname must be a string, got {type(host).__name__}")
    candidate = _strip_brackets(host).rstrip(".")
    if not candidate:
        raise ScopeParseError(f"hostname is empty: {host!r}")
    if " " in candidate or "\t" in candidate:
        raise ScopeParseError(f"hostname contains whitespace: {host!r}")
    if "/" in candidate or "@" in candidate or "?" in candidate or "#" in candidate:
        raise ScopeParseError(f"hostname contains a URL component: {host!r}")
    candidate = candidate.lower()
    if is_ip_literal(candidate):
        return str(to_ip(candidate))
    if ".." in candidate:
        raise ScopeParseError(f"hostname contains an empty label: {host!r}")
    return _to_ascii(candidate)


def normalize_path(path: str) -> str:
    if not path:
        return "/"
    if not path.startswith("/"):
        path = "/" + path
    while "//" in path:
        path = path.replace("//", "/")
    if len(path) > 1:
        path = path.rstrip("/") or "/"
    return path


def derive_domain(hostname: str) -> str | None:
    """Approximate registrable domain (final two labels). Not PSL-correct."""
    if is_ip_literal(hostname):
        return None
    labels = hostname.split(".")
    if len(labels) < 2:
        return None
    return ".".join(labels[-2:])


@dataclass(frozen=True, slots=True)
class ParsedTarget:
    raw: str
    host: str
    scheme: str | None
    port: int | None
    path: str
    is_url: bool

    @property
    def is_ip(self) -> bool:
        return is_ip_literal(self.host)

    def display(self) -> str:
        if not self.is_url:
            return self.host
        port = f":{self.port}" if self.port is not None else ""
        return f"{self.scheme}://{self.host}{port}{self.path}"


def _parse_port(parts) -> int | None:
    try:
        return parts.port
    except ValueError as exc:
        raise ScopeParseError(f"invalid port in {parts.geturl()!r}: {exc}") from exc


def _parse_url(raw: str) -> ParsedTarget:
    parts = urlsplit(raw)
    scheme = (parts.scheme or "").lower()
    if scheme not in _SUPPORTED_SCHEMES:
        raise ScopeParseError(f"unsupported URL scheme {scheme!r} in {raw!r}")
    if not parts.hostname:
        raise ScopeParseError(f"URL has no hostname: {raw!r}")
    return ParsedTarget(
        raw=raw, host=normalize_hostname(parts.hostname), scheme=scheme,
        port=_parse_port(parts), path=normalize_path(parts.path), is_url=True,
    )


def parse_target(target: str) -> ParsedTarget:
    if not isinstance(target, str):
        raise ScopeParseError(f"target must be a string, got {type(target).__name__}")
    raw = target.strip()
    if not raw:
        raise ScopeParseError("target is empty")
    if "://" in raw:
        return _parse_url(raw)
    if is_ip_literal(raw):
        return ParsedTarget(
            raw=raw, host=str(to_ip(raw)), scheme=None, port=None, path="/",
            is_url=False,
        )
    parts = urlsplit("//" + raw)
    if not parts.hostname:
        raise ScopeParseError(f"cannot parse target: {raw!r}")
    return ParsedTarget(
        raw=raw, host=normalize_hostname(parts.hostname), scheme=None,
        port=_parse_port(parts), path=normalize_path(parts.path), is_url=False,
    )
''')

w("src/h1hunter/utils/networking.py", r'''
"""Network destination classification."""

from __future__ import annotations

import ipaddress

__all__ = [
    "METADATA_ADDRESSES", "ip_block_reason", "is_metadata_endpoint",
    "is_public_destination",
]

Address = ipaddress.IPv4Address | ipaddress.IPv6Address

METADATA_ADDRESSES = frozenset(
    {
        "169.254.169.254", "169.254.170.2", "100.100.100.200",
        "192.0.0.192", "fd00:ec2::254",
    }
)


def _as_address(value: str | Address) -> Address:
    if isinstance(value, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
        return value
    if isinstance(value, (ipaddress.IPv4Network, ipaddress.IPv6Network)):
        return value.network_address
    try:
        return ipaddress.ip_address(str(value).strip().strip("[]"))
    except ValueError as exc:
        raise ValueError(f"not an IP address: {value!r}") from exc


def _unwrap(addr: Address) -> Address:
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        return addr.ipv4_mapped
    return addr


def is_metadata_endpoint(value: str | Address) -> bool:
    return str(_unwrap(_as_address(value))) in METADATA_ADDRESSES


def ip_block_reason(
    value: str | Address, *, allow_private: bool = False
) -> str | None:
    addr = _unwrap(_as_address(value))
    if addr.is_multicast:
        return "multicast address"
    if addr.is_unspecified:
        return "unspecified address"
    if addr.is_loopback:
        return "loopback address"
    if is_metadata_endpoint(addr):
        return "cloud metadata endpoint"
    if addr.is_link_local:
        return "link-local address"
    if addr.is_reserved:
        return "reserved address"
    if addr.is_private:
        return None if allow_private else "private address"
    if not addr.is_global:
        return None if allow_private else "non-globally-routable address"
    return None


def is_public_destination(value: str | Address, *, allow_private: bool = False) -> bool:
    return ip_block_reason(value, allow_private=allow_private) is None
''')

# ---------------------------------------------------------------------------
# models
# ---------------------------------------------------------------------------
w("src/h1hunter/models/__init__.py", r'''
"""Validated data records shared across layers."""

from __future__ import annotations

from h1hunter.models.asset import Asset, ScopeStatus, utcnow
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.models.scope import (
    EntryKind, ProgramInfo, ScopeConfig, ScopeDecision, ScopeEntry, ScopeSettings,
)

__all__ = [
    "Asset", "ConfidenceLevel", "EntryKind", "Finding", "ProgramInfo",
    "ScopeConfig", "ScopeDecision", "ScopeEntry", "ScopeSettings",
    "ScopeStatus", "SeverityLevel", "VerificationStatus", "utcnow",
]
''')

w("src/h1hunter/models/scope.py", r'''
"""Scope data model."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "EntryKind", "ProgramInfo", "ScopeConfig", "ScopeDecision",
    "ScopeEntry", "ScopeSettings",
]


class EntryKind(str, Enum):
    DOMAIN = "domain"
    WILDCARD = "wildcard"
    URL = "url"
    IP = "ip"
    CIDR = "cidr"


class ScopeEntry(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    raw: str
    kind: EntryKind
    host: str | None = None
    scheme: str | None = None
    port: int | None = None
    path_prefix: str | None = None
    network: str | None = None

    def describe(self) -> str:
        match self.kind:
            case EntryKind.WILDCARD:
                return f"*.{self.host}"
            case EntryKind.URL:
                port = f":{self.port}" if self.port is not None else ""
                return f"{self.scheme}://{self.host}{port}{self.path_prefix or '/'}"
            case EntryKind.CIDR | EntryKind.IP:
                return self.network or self.raw
            case _:
                return self.host or self.raw


class ProgramInfo(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str = Field(min_length=1)
    policy_reviewed: bool = False
    policy_url: str | None = None
    authorized_by: str | None = None


class ScopeSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    passive_recon: bool = True
    active_checks: bool = False
    max_concurrency: int = Field(default=3, ge=1, le=50)
    requests_per_second: float = Field(default=2.0, gt=0, le=100)
    timeout_seconds: float = Field(default=10.0, gt=0, le=120)
    max_requests: int = Field(default=500, ge=1, le=100_000)
    max_response_bytes: int = Field(default=1_048_576, ge=1024, le=52_428_800)
    allow_private_networks: bool = False


class ScopeConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    program: ProgramInfo
    allowed: list[ScopeEntry] = Field(min_length=1)
    excluded: list[ScopeEntry] = Field(default_factory=list)
    settings: ScopeSettings = Field(default_factory=ScopeSettings)


class ScopeDecision(BaseModel):
    model_config = ConfigDict(frozen=True)
    target: str
    normalized_host: str | None
    allowed: bool
    reason: str
    matched_rule: str | None = None
''')

w("src/h1hunter/models/asset.py", r'''
"""Asset data model."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from h1hunter.utils.normalization import normalize_hostname

__all__ = ["Asset", "ScopeStatus", "utcnow"]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ScopeStatus(str, Enum):
    UNVALIDATED = "unvalidated"
    IN_SCOPE = "in_scope"
    OUT_OF_SCOPE = "out_of_scope"
    EXCLUDED = "excluded"


class Asset(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    hostname: str
    domain: str | None = None
    source: str = Field(min_length=1)
    discovered_at: datetime = Field(default_factory=utcnow)
    scope_status: ScopeStatus = ScopeStatus.UNVALIDATED
    dns_records: dict[str, list[str]] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("hostname")
    @classmethod
    def _normalize_hostname(cls, value: str) -> str:
        return normalize_hostname(value)

    @field_validator("discovered_at")
    @classmethod
    def _require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value

    def dedup_key(self) -> str:
        return self.hostname
''')

w("src/h1hunter/models/finding.py", r'''
"""Normalized finding model."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = [
    "ConfidenceLevel", "Finding", "SeverityLevel", "VerificationStatus", "utcnow",
]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ConfidenceLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SeverityLevel(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return _SEVERITY_ORDER[self]


_SEVERITY_ORDER = {
    SeverityLevel.INFO: 0,
    SeverityLevel.LOW: 1,
    SeverityLevel.MEDIUM: 2,
    SeverityLevel.HIGH: 3,
    SeverityLevel.CRITICAL: 4,
}


class VerificationStatus(str, Enum):
    UNVERIFIED = "unverified"
    REQUIRES_INVESTIGATION = "requires_investigation"
    MANUALLY_VERIFIED = "manually_verified"


class Finding(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str
    title: str = Field(min_length=1)
    category: str = Field(min_length=1)
    affected_asset: str = Field(min_length=1)
    affected_endpoint: str | None = None
    detection_module: str = Field(min_length=1)
    evidence: dict[str, Any] = Field(default_factory=dict)
    reproduction: str = ""
    confidence: ConfidenceLevel = ConfidenceLevel.LOW
    severity: SeverityLevel = SeverityLevel.INFO
    severity_rationale: str = ""
    potential_impact: str = ""
    remediation: str = ""
    scope_validation: str = "unvalidated"
    discovered_at: datetime = Field(default_factory=utcnow)
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED

    @field_validator("discovered_at")
    @classmethod
    def _require_tz(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value

    @classmethod
    def make_id(
        cls, *, module: str, category: str, asset: str, endpoint: str | None
    ) -> str:
        raw = f"{module}|{category}|{asset}|{endpoint or ''}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def dedup_key(self) -> tuple[str, str, str, str]:
        return (
            self.affected_asset, self.category,
            self.affected_endpoint or "", self.detection_module,
        )
''')

print("\nPart 1 complete. Next: build2.py (config, scope, engine).")
