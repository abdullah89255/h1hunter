#!/usr/bin/env bash
# build_h1hunter.sh — reconstruct h1hunter Phases 1-4 and zip it.
set -euo pipefail

ROOT="h1hunter"
rm -rf "$ROOT" h1hunter.zip
mkdir -p "$ROOT"
cd "$ROOT"

mkdir -p config \
         src/h1hunter/models src/h1hunter/scope src/h1hunter/engine \
         src/h1hunter/utils src/h1hunter/recon/providers src/h1hunter/checks \
         src/h1hunter/storage src/h1hunter/reporting \
         tests/unit tests/integration tests/fixtures docs

# ============================================================================
# Root files
# ============================================================================

cat > pyproject.toml <<'H1EOF'
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "h1hunter"
version = "0.4.0"
description = "Safe-by-default, scope-enforced reconnaissance and low-impact check toolkit for authorized HackerOne programs."
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }
dependencies = [
    "httpx>=0.27,<0.29",
    "dnspython>=2.6,<3",
    "pydantic>=2.7,<3",
    "PyYAML>=6.0.1,<7",
    "rich>=13.7,<14",
    "idna>=3.6,<4",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.2,<9",
    "pytest-asyncio>=0.23,<1",
    "respx>=0.21,<1",
    "ruff>=0.5",
    "mypy>=1.10",
]

[project.scripts]
h1hunter = "h1hunter.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/h1hunter"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
asyncio_mode = "auto"
asyncio_default_fixture_loop_scope = "function"
markers = [
    "safety: safety-critical regression tests (must never be skipped)",
]

[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "UP", "B", "SIM", "C4", "RET", "PTH", "S"]
ignore = ["S101"]

[tool.mypy]
python_version = "3.12"
strict = true
files = ["src/h1hunter"]
H1EOF

cat > .gitignore <<'H1EOF'
__pycache__/
*.py[cod]
.venv/
venv/
.env
*.egg-info/
dist/
build/
.pytest_cache/
.mypy_cache/
.ruff_cache/
output/
logs/
config/config.yaml
config/scope.yaml
*.sqlite3
H1EOF

cat > .env.example <<'H1EOF'
# h1hunter reads optional credentials from the environment only.
# Never commit real values. Never place credentials in config/*.yaml.
#
# H1HUNTER_USER_AGENT="h1hunter/0.4 (+authorized-security-research; contact=you@example.test)"
H1EOF

cat > LICENSE <<'H1EOF'
MIT License

Copyright (c) 2025 h1hunter contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
H1EOF

cat > README.md <<'H1EOF'
# h1hunter

A safe-by-default reconnaissance and low-impact check toolkit for **authorized**
HackerOne bug bounty programs.

Phases delivered:

- **Phase 1** — scope enforcement, safety engine, dry-run planning.
- **Phase 2** — passive reconnaissance (local files only), asset storage, JSON/CSV export.
- **Phase 3** — opt-in DNS inspection and HTTP probing with redirect re-validation, size caps, concurrency limits, request budgets, cancellation, kill switch.
- **Phase 4** — low-impact security checks (headers, TLS, exposure, API docs, reflection), a normalized finding model, evidence sanitization, deduplication, and JSON/CSV/Markdown reports.

## Requirements

- Python 3.12+
- No network access is required for Phase 1 and Phase 2 commands.

## Install

```bash
python3.12 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
