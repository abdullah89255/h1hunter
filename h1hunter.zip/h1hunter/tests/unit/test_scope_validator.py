"""ScopeValidator: exclusion precedence, default deny, active-test gating."""

from __future__ import annotations

import pytest

from h1hunter.exceptions import ScopeNotReviewedError, ScopeViolation
from h1hunter.scope.parser import parse_scope_text
from h1hunter.scope.validator import ScopeValidator

BASE_SCOPE = """
program:
  name: conflict
  policy_reviewed: true
allowed:
  - "*.example.com"
  - "example.org"
excluded:
  - "example.org"
  - "admin.example.com"
settings:
  active_checks: true
"""


@pytest.fixture
def validator():
    return ScopeValidator(parse_scope_text(BASE_SCOPE))


def test_exclusion_wins_over_wildcard(validator):
    decision = validator.evaluate("admin.example.com")
    assert decision.allowed is False
    assert "exclusion" in decision.reason
    assert decision.matched_rule == "admin.example.com"


def test_exclusion_wins_over_exact(validator):
    assert validator.evaluate("example.org").allowed is False
    assert validator.evaluate("www.example.com").allowed is True


def test_unmatched_denied(validator):
    decision = validator.evaluate("evil.test")
    assert decision.allowed is False
    assert "does not match any allowed scope entry" in decision.reason


def test_malformed_target_denied(validator):
    decision = validator.evaluate("http://")
    assert decision.allowed is False
    assert decision.normalized_host is None


def test_require_raises_for_out_of_scope(validator):
    with pytest.raises(ScopeViolation):
        validator.require("evil.test")


def test_require_returns_parsed_target_when_allowed(validator):
    parsed = validator.require("https://www.example.com/path")
    assert parsed.host == "www.example.com"


def test_active_requires_reviewed_policy():
    text = BASE_SCOPE.replace("policy_reviewed: true", "policy_reviewed: false")
    v = ScopeValidator(parse_scope_text(text))
    with pytest.raises(ScopeNotReviewedError):
        v.require_active_authorization()


def test_active_requires_opt_in():
    text = BASE_SCOPE.replace("active_checks: true", "active_checks: false")
    v = ScopeValidator(parse_scope_text(text))
    with pytest.raises(ScopeNotReviewedError):
        v.require_active_authorization()
