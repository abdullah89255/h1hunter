"""Finding model validation, ID stability, dedup key."""

from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)


def _finding(**overrides):
    base = dict(
        id="abc123",
        title="Test finding",
        category="missing_header:csp",
        affected_asset="https://www.example.com/",
        detection_module="headers",
    )
    base.update(overrides)
    return Finding(**base)


def test_defaults_are_conservative():
    f = _finding()
    assert f.severity is SeverityLevel.INFO
    assert f.confidence is ConfidenceLevel.LOW
    assert f.verification_status is VerificationStatus.UNVERIFIED
    assert f.scope_validation == "unvalidated"


def test_naive_timestamp_coerced():
    f = _finding(discovered_at=datetime(2025, 1, 1))
    assert f.discovered_at.tzinfo is not None


def test_frozen():
    f = _finding()
    with pytest.raises(ValidationError):
        f.title = "new"


def test_empty_title_rejected():
    with pytest.raises(ValidationError):
        _finding(title="")


def test_extra_fields_rejected():
    with pytest.raises(ValidationError):
        Finding(  # type: ignore[call-arg]
            id="x", title="t", category="c", affected_asset="a",
            detection_module="m", surprise="nope",
        )


def test_make_id_stable_and_content_derived():
    a = Finding.make_id(module="m", category="c", asset="a", endpoint="e")
    b = Finding.make_id(module="m", category="c", asset="a", endpoint="e")
    c = Finding.make_id(module="m", category="c", asset="a", endpoint="different")
    assert a == b
    assert a != c


def test_dedup_key_shape():
    f = _finding(affected_endpoint="csp")
    assert f.dedup_key() == (
        "https://www.example.com/", "missing_header:csp", "csp", "headers",
    )


def test_severity_rank_ordering():
    assert SeverityLevel.INFO.rank < SeverityLevel.LOW.rank
    assert SeverityLevel.LOW.rank < SeverityLevel.MEDIUM.rank
    assert SeverityLevel.MEDIUM.rank < SeverityLevel.HIGH.rank
    assert SeverityLevel.HIGH.rank < SeverityLevel.CRITICAL.rank
