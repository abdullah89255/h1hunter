"""Severity helpers."""

from __future__ import annotations

from h1hunter.models.finding import SeverityLevel
from h1hunter.reporting.severity import (
    merge_severity, missing_header_severity, severity_order,
)


def test_hsts_is_low_with_rationale():
    level, rationale = missing_header_severity("strict-transport-security")
    assert level is SeverityLevel.LOW
    assert rationale


def test_csp_is_low():
    assert missing_header_severity("content-security-policy")[0] is SeverityLevel.LOW


def test_xcto_and_referrer_are_info():
    assert missing_header_severity("x-content-type-options")[0] is SeverityLevel.INFO
    assert missing_header_severity("referrer-policy")[0] is SeverityLevel.INFO


def test_unknown_header_is_info_with_named_rationale():
    level, rationale = missing_header_severity("x-unknown")
    assert level is SeverityLevel.INFO
    assert "x-unknown" in rationale


def test_case_insensitive_lookup():
    assert missing_header_severity("Content-Security-Policy")[0] is SeverityLevel.LOW


def test_severity_order_monotonic():
    levels = [
        SeverityLevel.INFO, SeverityLevel.LOW, SeverityLevel.MEDIUM,
        SeverityLevel.HIGH, SeverityLevel.CRITICAL,
    ]
    ranks = [severity_order(l) for l in levels]
    assert ranks == sorted(ranks)


def test_merge_returns_higher():
    assert merge_severity(SeverityLevel.LOW, SeverityLevel.HIGH) is SeverityLevel.HIGH
    assert merge_severity(SeverityLevel.INFO, SeverityLevel.INFO) is SeverityLevel.INFO
