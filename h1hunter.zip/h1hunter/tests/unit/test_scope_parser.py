"""Scope entry and scope document parsing."""

from __future__ import annotations

import pytest

from h1hunter.exceptions import ScopeParseError
from h1hunter.models.scope import EntryKind
from h1hunter.scope.parser import parse_scope_entry, parse_scope_text


@pytest.mark.parametrize(
    ("raw", "kind", "host"),
    [
        ("example.com", EntryKind.DOMAIN, "example.com"),
        ("EXAMPLE.COM.", EntryKind.DOMAIN, "example.com"),
        ("sub.example.com", EntryKind.DOMAIN, "sub.example.com"),
        ("*.example.com", EntryKind.WILDCARD, "example.com"),
        ("*.EXAMPLE.com.", EntryKind.WILDCARD, "example.com"),
        ("https://api.example.com/v1", EntryKind.URL, "api.example.com"),
        ("203.0.113.5", EntryKind.IP, "203.0.113.5"),
        ("198.51.100.0/24", EntryKind.CIDR, None),
        ("2001:db8::/32", EntryKind.CIDR, None),
    ],
)
def test_parse_scope_entry_accepts_valid_forms(raw, kind, host):
    entry = parse_scope_entry(raw)
    assert entry.kind is kind
    if host is not None:
        assert entry.host == host


@pytest.mark.parametrize(
    "raw",
    ["", "   ", "*", "*.*", "*.", "foo.*.example.com", "example.*",
     "exa mple.com", "http://", "ftp://example.com", "example.com/path",
     "localhost", "example..com"],
)
def test_parse_scope_entry_rejects_invalid_forms(raw):
    with pytest.raises(ScopeParseError):
        parse_scope_entry(raw)


def test_url_entry_captures_scheme_port_and_path():
    entry = parse_scope_entry("https://api.example.net:8443/v2/")
    assert entry.kind is EntryKind.URL
    assert entry.scheme == "https"
    assert entry.port == 8443
    assert entry.path_prefix == "/v2"


def test_parse_scope_text_full_document(sample_scope_yaml):
    scope = parse_scope_text(sample_scope_yaml)
    assert scope.program.name == "example-program"
    assert scope.program.policy_reviewed is True
    assert len(scope.allowed) == 5
    assert len(scope.excluded) == 2


def test_scope_without_allowed_entries_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("program:\n  name: x\nallowed: []\n")


def test_scope_without_program_section_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("allowed:\n  - example.com\n")


def test_scope_with_non_list_allowed_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("program:\n  name: x\nallowed: 'example.com'\n")


def test_scope_with_invalid_settings_is_rejected():
    text = (
        "program:\n  name: x\nallowed:\n  - example.com\n"
        "settings:\n  max_concurrency: 9999\n"
    )
    with pytest.raises(ScopeParseError):
        parse_scope_text(text)


def test_empty_scope_document_is_rejected():
    with pytest.raises(ScopeParseError):
        parse_scope_text("")
