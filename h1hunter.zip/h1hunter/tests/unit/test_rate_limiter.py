"""Deterministic token-bucket tests using an injected clock and sleep."""

from __future__ import annotations

import pytest

from h1hunter.engine.rate_limiter import TokenBucketRateLimiter


class FakeClock:
    def __init__(self): self.now = 0.0
    def __call__(self): return self.now
    def advance(self, d): self.now += d


def _build(rate, capacity):
    clock = FakeClock()
    slept: list[float] = []

    async def fake_sleep(delay):
        slept.append(delay); clock.advance(delay)

    return TokenBucketRateLimiter(
        rate, capacity=capacity, clock=clock, sleep=fake_sleep,
    ), clock, slept


async def test_burst_does_not_sleep():
    lim, _, slept = _build(2.0, 2.0)
    await lim.acquire(); await lim.acquire()
    assert slept == []


async def test_exhausted_bucket_waits():
    lim, _, slept = _build(2.0, 1.0)
    await lim.acquire()
    assert slept == []
    await lim.acquire()
    assert slept == [0.5]


async def test_rate_is_enforced():
    lim, _, slept = _build(4.0, 1.0)
    for _ in range(4):
        await lim.acquire()
    assert slept == [0.25, 0.25, 0.25]


def test_zero_rate_rejected():
    with pytest.raises(ValueError):
        TokenBucketRateLimiter(rate=0)


def test_negative_capacity_rejected():
    with pytest.raises(ValueError):
        TokenBucketRateLimiter(rate=1.0, capacity=-1)


async def test_over_capacity_rejected():
    lim, _, _ = _build(5.0, 2.0)
    with pytest.raises(ValueError):
        await lim.acquire(5.0)


async def test_non_positive_token_rejected():
    lim, _, _ = _build(5.0, 2.0)
    with pytest.raises(ValueError):
        await lim.acquire(0)
