"""Scope entry matching rules, including lookalike-host rejection."""

from __future__ import annotations

from h1hunter.scope.matcher import entry_matches
from h1hunter.scope.parser import parse_scope_entry
from h1hunter.utils.normalization import parse_target


def _m(entry_raw, target_raw):
    return entry_matches(parse_scope_entry(entry_raw), parse_target(target_raw))


def test_exact_domain_rejects_lookalikes():
    assert _m("example.com", "example.com")
    assert not _m("example.com", "example.com.attacker.test")
    assert not _m("example.com", "notexample.com")
    assert not _m("example.com", "www.example.com")


def test_wildcard_excludes_apex_and_rejects_lookalikes():
    assert _m("*.example.com", "www.example.com")
    assert _m("*.example.com", "a.b.example.com")
    assert not _m("*.example.com", "example.com")
    assert not _m("*.example.com", "example.com.attacker.test")
    assert not _m("*.example.com", "attacker-example.com")


def test_wildcard_case_and_trailing_dot_insensitive():
    assert _m("*.example.com", "WWW.Example.COM.")
    assert _m("EXAMPLE.com", "example.com.")


def test_url_entry_requires_scheme_host_and_path_prefix():
    entry = "https://api.example.net/v1"
    assert _m(entry, "https://api.example.net/v1")
    assert _m(entry, "https://api.example.net/v1/users")
    assert not _m(entry, "https://api.example.net/v1beta/users")
    assert not _m(entry, "http://api.example.net/v1/users")
    assert not _m(entry, "https://api.example.net:8443/v1")


def test_cidr_entry_matches_only_literal_ips():
    entry = "198.51.100.0/24"
    assert _m(entry, "198.51.100.7")
    assert not _m(entry, "198.51.101.7")
    assert not _m(entry, "example.com")


def test_ip_entry_is_exact():
    assert _m("203.0.113.10", "203.0.113.10")
    assert not _m("203.0.113.10", "203.0.113.11")


def test_ipv6_cidr_does_not_match_ipv4():
    assert not _m("2001:db8::/32", "198.51.100.1")
    assert _m("2001:db8::/32", "2001:db8::1")
