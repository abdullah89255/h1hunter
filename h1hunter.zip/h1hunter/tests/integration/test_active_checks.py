"""Security-check pipeline with mocked transports. No sockets."""

from __future__ import annotations

import httpx
import pytest

from h1hunter.checks.base import CheckContext
from h1hunter.checks.headers import INSPECTED_HEADERS, HeadersCheck
from h1hunter.engine.safety import SafetyEngine
from h1hunter.models.finding import SeverityLevel
from h1hunter.recon.http_probe import HttpProber
from h1hunter.scope.parser import parse_scope_text
from h1hunter.utils.deduplication import deduplicate_findings

pytestmark = pytest.mark.safety

SCOPE = """
program:
  name: checks
  policy_reviewed: true
allowed:
  - "*.example.com"
settings:
  active_checks: true
  requests_per_second: 1000
  max_requests: 20
  max_response_bytes: 4096
"""


class StubResolver:
    async def resolve(self, hostname, record_type):
        return ["93.184.216.34"] if record_type == "A" else []


def _ctx(handler):
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE))
    client = httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    )
    return CheckContext(engine=engine, client=client, resolver=StubResolver())


async def test_all_headers_present_no_findings():
    def handler(request):
        return httpx.Response(
            200, content=b"ok",
            headers={
                "Content-Security-Policy": "default-src 'self'",
                "Strict-Transport-Security": "max-age=31536000",
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer",
                "Permissions-Policy": "geolocation=()",
            },
            request=request,
        )

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)
    assert findings == []


async def test_missing_headers_produce_one_finding_each():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)

    assert {f.affected_endpoint for f in findings} == set(INSPECTED_HEADERS)


async def test_hsts_not_flagged_on_http():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("http://www.example.com/", ctx)
    assert "strict-transport-security" not in {f.affected_endpoint for f in findings}


async def test_csp_severity_is_low():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)

    csp = next(f for f in findings if f.affected_endpoint == "content-security-policy")
    assert csp.severity is SeverityLevel.LOW
    assert csp.severity_rationale


async def test_out_of_scope_produces_no_findings():
    def handler(request):
        return httpx.Response(200, request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://attacker.test/", ctx)
    assert findings == []


async def test_evidence_never_contains_body():
    def handler(request):
        return httpx.Response(200, content=b"very-secret-marker", request=request)

    ctx = _ctx(handler)
    async with ctx.client:
        findings = await HeadersCheck(
            HttpProber(ctx.engine, ctx.client, ctx.resolver)
        ).run("https://www.example.com/", ctx)
    for f in findings:
        assert "very-secret-marker" not in str(f.evidence)


async def test_findings_are_deduplicated():
    def handler(request):
        return httpx.Response(200, content=b"ok", request=request)

    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE))
    resolver = StubResolver()
    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        ctx = CheckContext(engine=engine, client=client, resolver=resolver)
        check = HeadersCheck(HttpProber(engine, client, resolver))
        a = await check.run("https://www.example.com/", ctx)
        b = await check.run("https://www.example.com/", ctx)
    merged = deduplicate_findings(a + b)
    assert len(merged) == len(a)
