"""JSON, CSV, Markdown exports round-trip and refuse to overwrite."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from h1hunter import cli
from h1hunter.exceptions import StorageError
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.reporting import (
    read_findings_json, render_findings_markdown,
    write_findings_csv, write_findings_json, write_findings_markdown,
)


def _finding(fid, **overrides):
    base = dict(
        id=fid,
        title=f"Test finding {fid}",
        category="missing_header:csp",
        affected_asset="https://www.example.com/",
        affected_endpoint="content-security-policy",
        detection_module="headers",
        confidence=ConfidenceLevel.HIGH,
        severity=SeverityLevel.LOW,
        severity_rationale="rationale text",
        potential_impact="impact text",
        remediation="remediation text",
        reproduction="repro steps",
        evidence={"status_code": 200},
        scope_validation="in_scope",
        discovered_at=datetime(2025, 1, 1, tzinfo=timezone.utc),
    )
    base.update(overrides)
    return Finding(**base)


def test_json_round_trip(tmp_path: Path):
    target = tmp_path / "findings.json"
    original = [_finding("a"), _finding("b", severity=SeverityLevel.MEDIUM)]
    write_findings_json(original, target)
    loaded = read_findings_json(target)
    assert {f.id for f in loaded} == {"a", "b"}
    # Ordered by severity descending.
    assert loaded[0].severity is SeverityLevel.MEDIUM


def test_json_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "findings.json"
    target.write_text("[]", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_json([_finding("a")], target)


def test_csv_columns_and_values(tmp_path: Path):
    target = tmp_path / "findings.csv"
    write_findings_csv([_finding("a")], target)
    with target.open(encoding="utf-8", newline="") as h:
        rows = list(csv.DictReader(h))
    assert len(rows) == 1
    row = rows[0]
    assert row["id"] == "a"
    assert row["severity"] == "low"
    assert row["confidence"] == "high"
    assert row["verification_status"] == "unverified"


def test_csv_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "findings.csv"
    target.write_text("x", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_csv([_finding("a")], target)


def test_markdown_contains_authorization_notice():
    text = render_findings_markdown([_finding("a")], program_name="example")
    assert "Authorization notice" in text
    assert "[LOW]" in text
    assert "example" in text


def test_markdown_summary_counts_severities():
    findings = [
        _finding("a", severity=SeverityLevel.MEDIUM),
        _finding("b"),
        _finding("c"),
    ]
    text = render_findings_markdown(findings, program_name="p")
    assert "| medium | 1 |" in text
    assert "| low | 2 |" in text


def test_markdown_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "f.md"
    target.write_text("x", encoding="utf-8")
    with pytest.raises(StorageError):
        write_findings_markdown([_finding("a")], target, program_name="p")


def test_markdown_shows_verification_status():
    text = render_findings_markdown([
        _finding("a", verification_status=VerificationStatus.REQUIRES_INVESTIGATION)
    ])
    assert "requires_investigation" in text


# --------------------------------------------------------------- report CLI


def _seed_findings(tmp_path: Path) -> Path:
    src = tmp_path / "findings.json"
    write_findings_json([_finding("a"), _finding("b")], src)
    return src


def test_cli_report_markdown(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.md"
    code = cli.main([
        "report", "--input", str(src), "--format", "markdown",
        "--output", str(out),
    ])
    assert code == cli.EXIT_OK
    assert "Authorization notice" in out.read_text(encoding="utf-8")


def test_cli_report_csv(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.csv"
    code = cli.main([
        "report", "--input", str(src), "--format", "csv", "--output", str(out),
    ])
    assert code == cli.EXIT_OK
    assert out.exists()


def test_cli_report_refuses_overwrite(tmp_path: Path):
    src = _seed_findings(tmp_path)
    out = tmp_path / "report.md"
    out.write_text("existing", encoding="utf-8")
    code = cli.main([
        "report", "--input", str(src), "--format", "markdown",
        "--output", str(out),
    ])
    assert code == cli.EXIT_USAGE


def test_cli_report_missing_input(tmp_path: Path):
    code = cli.main([
        "report", "--input", str(tmp_path / "missing.json"),
        "--format", "markdown",
    ])
    assert code == cli.EXIT_USAGE
