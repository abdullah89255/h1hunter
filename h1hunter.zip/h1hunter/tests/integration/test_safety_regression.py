"""Safety regression suite — run with ``pytest -q -m safety``.

These tests prove the controls that make active scanning safe to run:
scope enforcement, destination policy, budget, kill switch, redaction,
dry-run planning. Every test uses mocks. No test opens a socket.
"""

from __future__ import annotations

import logging

import pytest

from h1hunter import cli
from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, DestinationBlocked, KillSwitchEngaged, SafetyError,
    ScopeParseError, ScopeViolation,
)
from h1hunter.logging_config import REDACTED, configure_logging
from h1hunter.scope.parser import load_scope_file, parse_scope_text

pytestmark = pytest.mark.safety

ACTIVE_SCOPE = """
program:
  name: safety-regression
  policy_reviewed: true
allowed:
  - "*.example.com"
  - "example.org"
excluded:
  - "admin.example.com"
  - "example.org"
settings:
  active_checks: true
  max_requests: 3
  requests_per_second: 1000
  allow_private_networks: false
"""


class RecordingClient:
    """Stand-in for the HTTP client. Records every call."""

    def __init__(self): self.calls = []
    async def get(self, url): self.calls.append(url); return "response"


def _engine(t): return SafetyEngine.from_scope(parse_scope_text(t))


async def _guarded_get(engine, client, url):
    await engine.authorize(url)
    return await client.get(url)


@pytest.fixture
def restore_logging():
    root = logging.getLogger()
    saved_handlers = root.handlers[:]
    saved_level = root.level
    yield
    for h in root.handlers[:]:
        root.removeHandler(h); h.close()
    root.handlers[:] = saved_handlers
    root.setLevel(saved_level)


# ----------------------------------------------------- scope enforcement boundary


async def test_out_of_scope_host_never_reaches_client():
    engine = _engine(ACTIVE_SCOPE)
    client = RecordingClient()
    with pytest.raises(ScopeViolation):
        await _guarded_get(engine, client, "https://attacker.test/")
    assert client.calls == []
    assert engine.requests_made == 0


async def test_lookalike_host_never_reaches_client():
    engine = _engine(ACTIVE_SCOPE)
    client = RecordingClient()
    for hostile in (
        "https://example.com.attacker.test/",
        "https://notexample.com/",
        "https://example.org.attacker.test/",
    ):
        with pytest.raises(ScopeViolation):
            await _guarded_get(engine, client, hostile)
    assert client.calls == []


async def test_excluded_rejected_even_though_wildcard_allows():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://admin.example.com/")
    assert engine.requests_made == 0


async def test_excluded_rejected_even_though_exact_allows():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://example.org/")
    assert engine.requests_made == 0


# ------------------------------------------------------- missing / invalid scope


def test_missing_scope_file_prevents_active(tmp_path):
    with pytest.raises(ScopeParseError):
        load_scope_file(tmp_path / "does-not-exist.yaml")


def test_invalid_scope_fails_closed(tmp_path):
    bad = tmp_path / "scope.yaml"
    bad.write_text("program:\n  name: x\nallowed: 'not-a-list'\n", encoding="utf-8")
    with pytest.raises(ScopeParseError):
        load_scope_file(bad)


def test_scope_without_allowed_fails_closed(tmp_path):
    bad = tmp_path / "scope.yaml"
    bad.write_text("program:\n  name: x\nallowed: []\n", encoding="utf-8")
    with pytest.raises(ScopeParseError):
        load_scope_file(bad)


async def test_unreviewed_policy_prevents_active():
    text = ACTIVE_SCOPE.replace("policy_reviewed: true", "policy_reviewed: false")
    engine = _engine(text)
    assert engine.policy.active_checks is False
    with pytest.raises(SafetyError):
        await engine.authorize("https://www.example.com/")


async def test_disabled_active_prevents_active():
    text = ACTIVE_SCOPE.replace("active_checks: true", "active_checks: false")
    engine = _engine(text)
    assert engine.policy.active_checks is False
    with pytest.raises(SafetyError):
        await engine.authorize("https://www.example.com/")


# ------------------------------------------------------------------ destinations


def test_private_and_metadata_blocked_by_default():
    engine = _engine(ACTIVE_SCOPE)
    for blocked in (
        "127.0.0.1", "::1", "10.0.0.1", "192.168.1.1", "169.254.169.254",
    ):
        with pytest.raises(DestinationBlocked):
            engine.check_destination(blocked)
    engine.check_destination("93.184.216.34")  # must not raise


# ---------------------------------------------------------- budget and kill switch


async def test_budget_enforced():
    engine = _engine(ACTIVE_SCOPE)  # max_requests: 3
    for _ in range(3):
        await engine.authorize("https://www.example.com/")
    assert engine.budget_remaining == 0
    with pytest.raises(BudgetExhausted):
        await engine.authorize("https://www.example.com/")


async def test_denied_targets_do_not_consume_budget():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://attacker.test/")
    assert engine.requests_made == 0
    assert engine.budget_remaining == 3


async def test_kill_switch_prevents_new_requests():
    engine = _engine(ACTIVE_SCOPE)
    await engine.authorize("https://www.example.com/")
    engine.kill("operator stop")
    assert engine.is_killed is True
    with pytest.raises(KillSwitchEngaged):
        await engine.authorize("https://www.example.com/")


async def test_audit_trail_records_decisions():
    engine = _engine(ACTIVE_SCOPE)
    with pytest.raises(ScopeViolation):
        await engine.authorize("https://attacker.test/")
    await engine.authorize("https://www.example.com/")
    engine.kill("done")
    actions = [e.action for e in engine.audit_log]
    assert "authorize" in actions
    assert "kill_switch" in actions


# -------------------------------------------------------------------- redaction


def test_sensitive_values_never_reach_the_log_file(tmp_path, restore_logging):
    log_file = tmp_path / "h1hunter.jsonl"
    configure_logging(level="INFO", fmt="json", file=str(log_file), no_color=True)
    logging.getLogger("h1hunter.test").info("Authorization: Bearer leak-me-please")
    for h in logging.getLogger().handlers:
        h.flush()
    contents = log_file.read_text(encoding="utf-8")
    assert "leak-me-please" not in contents
    assert REDACTED in contents


# ------------------------------------------------------------------ dry run / CLI


def test_dry_run_plan_sends_no_traffic(tmp_path, capsys):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "plan", "--file", str(scope_path),
        "--targets", "https://www.example.com", "https://attacker.test",
    ])
    out = capsys.readouterr().out
    assert code == cli.EXIT_OK
    assert "no network traffic" in out.lower()
    assert "ALLOW" in out and "DENY" in out


def test_scope_check_returns_denied_exit_code(tmp_path, capsys):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "scope", "check", "--file", str(scope_path),
        "--target", "https://attacker.test",
    ])
    assert code == cli.EXIT_DENIED


def test_scope_check_returns_ok_for_in_scope(tmp_path):
    scope_path = tmp_path / "s.yaml"
    scope_path.write_text(ACTIVE_SCOPE, encoding="utf-8")
    code = cli.main([
        "scope", "check", "--file", str(scope_path),
        "--target", "https://www.example.com",
    ])
    assert code == cli.EXIT_OK


def test_missing_scope_file_yields_usage_error(tmp_path):
    code = cli.main(["scope", "validate", "--file", str(tmp_path / "nope.yaml")])
    assert code == cli.EXIT_USAGE
