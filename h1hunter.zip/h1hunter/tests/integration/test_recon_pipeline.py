"""Passive and active reconnaissance end-to-end with mocked transports."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from h1hunter.engine.safety import SafetyEngine
from h1hunter.recon.http_probe import HttpProber
from h1hunter.recon.passive import PassiveReconEngine
from h1hunter.recon.providers.file_source import FileSource
from h1hunter.recon.providers.text_source import TextSource
from h1hunter.recon.runner import run_concurrently
from h1hunter.scope.parser import parse_scope_text

pytestmark = pytest.mark.safety

FIXTURES = Path(__file__).parent.parent / "fixtures"

SCOPE_ACTIVE = """
program:
  name: recon-integration
  policy_reviewed: true
allowed:
  - "*.example.com"
excluded:
  - "admin.example.com"
settings:
  active_checks: true
  requests_per_second: 1000
  max_requests: 10
  max_concurrency: 2
  max_response_bytes: 512
"""


class StubResolver:
    async def resolve(self, hostname, record_type):
        return ["93.184.216.34"] if record_type == "A" else []


# ------------------------------------------------------------- passive pipeline


async def test_passive_aggregates_and_dedupes():
    file_source = FileSource("json-fixture", FIXTURES / "passive_assets.json")
    text_source = TextSource("text-fixture", FIXTURES / "passive_hosts.txt")
    result = await PassiveReconEngine([file_source, text_source]).run()

    hostnames = {a.hostname for a in result.assets}
    assert {"www.example.com", "api.example.com",
            "admin.example.com", "mail.example.com"} <= hostnames

    www = next(a for a in result.assets if a.hostname == "www.example.com")
    assert set(www.metadata["sources"]) == {"json-fixture", "text-fixture"}


async def test_passive_leaves_assets_unvalidated_without_validator():
    source = TextSource("fixture", FIXTURES / "passive_hosts.txt")
    result = await PassiveReconEngine([source]).run()
    assert all(a.scope_status.value == "unvalidated" for a in result.assets)


async def test_passive_annotates_without_authorizing():
    source = TextSource("fixture", FIXTURES / "passive_hosts.txt")
    engine = PassiveReconEngine([source])
    result = await engine.run()
    by_host = {a.hostname: a for a in result.assets}
    # Annotation is not performed without a validator — status stays unvalidated.
    assert by_host["www.example.com"].scope_status.value == "unvalidated"


async def test_passive_records_failing_source_without_aborting(tmp_path: Path):
    good = TextSource("good", FIXTURES / "passive_hosts.txt")
    bad = TextSource("bad", tmp_path / "does-not-exist.txt")
    result = await PassiveReconEngine([good, bad]).run()
    assert "good" in result.sources_run
    assert any(name == "bad" for name, _ in result.sources_failed)
    assert result.assets


# -------------------------------------------------------------- active pipeline


async def test_active_pipeline_mixes_in_and_out_of_scope():
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE_ACTIVE))
    resolver = StubResolver()
    hits: list[str] = []

    def handler(request):
        hits.append(str(request.url))
        return httpx.Response(200, content=b"ok", request=request)

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        prober = HttpProber(engine, client, resolver)
        urls = [
            "https://www.example.com/",
            "https://attacker.test/",
            "https://api.example.com/v1",
            "https://admin.example.com/",
        ]
        results = await run_concurrently(
            urls, prober.probe, engine.policy.max_concurrency,
        )

    by_url = {r.url: r for r in results}
    assert by_url["https://www.example.com/"].error is None
    assert by_url["https://api.example.com/v1"].error is None
    assert by_url["https://attacker.test/"].error is not None
    assert by_url["https://admin.example.com/"].error is not None
    assert set(hits) == {
        "https://www.example.com/", "https://api.example.com/v1",
    }


async def test_redirect_chain_revalidation():
    engine = SafetyEngine.from_scope(parse_scope_text(SCOPE_ACTIVE))
    resolver = StubResolver()
    hops: list[str] = []

    def handler(request):
        hops.append(str(request.url))
        if request.url.path == "/start":
            return httpx.Response(
                302,
                headers={"location": "https://api.example.com/middle"},
                request=request,
            )
        if request.url.path == "/middle":
            return httpx.Response(
                302,
                headers={"location": "https://attacker.test/final"},
                request=request,
            )
        return httpx.Response(200, request=request)

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler), trust_env=False,
    ) as client:
        result = await HttpProber(engine, client, resolver).probe(
            "https://www.example.com/start"
        )

    assert hops == [
        "https://www.example.com/start",
        "https://api.example.com/middle",
    ]
    assert result.redirects[0].refused is False
    assert result.redirects[1].refused is True
    assert "redirect refused" in (result.error or "")
