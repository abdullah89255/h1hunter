"""Shared pytest fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def sample_scope_yaml() -> str:
    return (FIXTURES / "sample_scope.yaml").read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def sample_scope_path() -> Path:
    return FIXTURES / "sample_scope.yaml"
