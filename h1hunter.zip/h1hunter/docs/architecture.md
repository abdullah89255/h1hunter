# h1hunter architecture

## Layers

    cli → config → models
     │              ▲
     ├─→ scope/parser ─┘
     ├─→ scope/validator → scope/matcher → utils/normalization
     ├─→ engine/safety → scope/validator
     │                 → engine/rate_limiter
     │                 → utils/networking
     ├─→ recon/ → engine/safety
     ├─→ checks/ → engine/safety, recon/
     └─→ reporting/ → models/

## Invariants

1. **One scope validator.** No module implements its own scope comparison.
2. **One safety engine.** Every outbound operation calls
   `SafetyEngine.authorize()`.
3. **Destination policy enforced before connect.**
   `check_destination()` is called on every resolved IP immediately before
   the socket is opened.
4. **Redirect chains re-validated hop by hop.**
5. **Response bodies truncated and never persisted by checks.**
6. **Findings are heuristic.** The `verification_status` field carries the
   distinction between observations and manually verified issues.

## Passive vs active

`recon passive` reads local files only. `recon dns`, `recon probe`, and every
`check` subcommand are active: they require `active_checks: true` and
`policy_reviewed: true`, and they refuse to start otherwise.

## Extending the toolkit

New check modules implement `CheckProtocol`:

    class MyCheck:
        name = "my-check"
        category = "my_category"
        async def run(self, target: str, context: CheckContext) -> list[Finding]:
            ...

Rules for new checks:

- Route every request through `context.engine` and `context.client`.
- Record at most the minimum evidence needed to explain the observation.
- Set `severity_rationale` — never a bare severity value.
- Default to `VerificationStatus.UNVERIFIED` unless the observation is
  directly observable without contextual judgment.
- Never modify server state.
- Never persist response bodies.
