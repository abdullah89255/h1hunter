# h1hunter usage guide

## Installation

    python3.12 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

For Windows activation commands, see the top-level `README.md`.

## First steps

1. Copy the example configs.

       cp config/config.example.yaml config/config.yaml
       cp config/scope.example.yaml  config/scope.yaml

2. Edit `config/scope.yaml`. Replace every placeholder with assets you are
   authorized to test. Set `program.policy_reviewed: true` only after reading
   the current program policy.

3. Validate the scope.

       h1hunter scope validate --file config/scope.yaml

## Scope inspection

    h1hunter scope check --file config/scope.yaml --target https://api.example.net/v1
    h1hunter scope check --file config/scope.yaml --target https://admin.example.com
    h1hunter scope check --file config/scope.yaml --target https://example.com.attacker.test

The first is authorized; the second is excluded; the third is out of scope.

## Dry-run planning

    h1hunter plan --file config/scope.yaml \
      --targets example.com attacker.test https://api.example.net/v1/users

Prints a plan table. Sends no packets.

## Passive reconnaissance

Local files only:

    printf 'www.example.com\napi.example.com\n' > data/subdomains.txt

    # config.yaml
    # passive_sources:
    #   - name: imported-subdomains
    #     enabled: true
    #     options:
    #       type: text
    #       path: data/subdomains.txt

    h1hunter recon passive --file config/scope.yaml --config config/config.yaml \
      --output output/passive.json --db output/assets.db

Discovered assets are recorded as `unvalidated`. To promote them:

    h1hunter scope check --file config/scope.yaml --target www.example.com

## Active reconnaissance

Every active command supports `--dry-run` first.

    printf 'https://www.example.com/\nhttps://attacker.test/\n' > data/urls.txt

    h1hunter recon probe --file config/scope.yaml \
      --targets-file data/urls.txt --dry-run

    h1hunter recon dns --file config/scope.yaml \
      --targets-file data/hosts.txt --dry-run

Real runs require `active_checks: true` and `policy_reviewed: true`:

    h1hunter recon probe --file config/scope.yaml \
      --targets-file data/urls.txt --output output/probe.json

## Security checks

    h1hunter check headers  --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check tls      --file config/scope.yaml --targets-file data/hosts.txt --dry-run
    h1hunter check exposure --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check api-docs --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check reflection --file config/scope.yaml \
      --target "https://www.example.com/search?q=x" --dry-run

Each writes JSON, CSV, or Markdown when `--output` is given:

    h1hunter check headers --file config/scope.yaml --targets-file data/urls.txt \
      --output output/headers.json
    h1hunter check headers --file config/scope.yaml --targets-file data/urls.txt \
      --output output/headers.md --format markdown

## Reporting

    h1hunter report --input output/headers.json --format markdown --output output/headers.md
    h1hunter report --input output/headers.json --format csv      --output output/headers.csv
    h1hunter report --input output/headers.json --format json     --output output/headers-2.json

The Markdown report includes an authorization notice reminding the operator
that findings are heuristic and must be verified manually before submission.

## Exit codes

| Code | Meaning |
| --- | --- |
| 0 | Success |
| 1 | A scope decision denied the request |
| 2 | Usage, configuration, or storage error |
| 130 | Interrupted by the operator |

## Troubleshooting

- **"active checks are disabled"** — set `active_checks: true` *and*
  `policy_reviewed: true` in the scope file.
- **"refusing to overwrite existing file"** — remove the existing output or
  choose a new path. Reports never overwrite silently.
- **"scope file not found"** — pass `--file` explicitly, or copy
  `config/scope.example.yaml` to `config/scope.yaml`.
- **DNS lookups fail** — the resolver inherits system configuration. Confirm
  that `dig` or `nslookup` works for the same name from the same host.
- **TLS handshake fails** — the destination policy may have blocked the
  resolved address. Run with `-v` to see the destination check result.
