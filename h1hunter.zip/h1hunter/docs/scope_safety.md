# Scope and safety model

## Scope matching

- `example.com` matches `example.com` exactly. It does **not** match
  `www.example.com` or `example.com.attacker.test`.
- `*.example.com` matches subdomains, not the apex, and not lookalikes such
  as `attacker-example.com`.
- `https://api.example.net/v1` requires the scheme, host, default port, and
  a path prefix match.
- CIDR entries match IP literals only. A hostname that resolves into an
  authorized CIDR is not authorized by that entry.
- Exclusions are evaluated **before** inclusions.
- Unparseable targets are denied, never passed through.

## Active gating

Active checks require **both**:

- `program.policy_reviewed: true`
- `settings.active_checks: true`

Either alone is insufficient.

## Destination policy

Blocked by default:

- Loopback (`127.0.0.0/8`, `::1`)
- Private (`10/8`, `172.16/12`, `192.168/16`, `fc00::/7`)
- Link-local (`169.254/16`, `fe80::/10`)
- Multicast, unspecified, reserved
- Cloud metadata endpoints — blocked even when
  `allow_private_networks: true`

## Budgets, rate limits, kill switch

- A global token-bucket rate limiter is shared across the whole run.
- A hard request budget applies. Denied targets do not consume budget.
- The circuit breaker opens on repeated failures.
- The kill switch stops new requests immediately.

## Redirects

Every redirect hop is re-validated before being fetched. An out-of-scope
`Location` is recorded and refused; the hop is not followed.

## Evidence

- Response bodies are never written to disk.
- Sensitive response headers are redacted by the logging filter.
- Reports refuse to overwrite existing files.
- Every finding is content-addressed and deduplicated by
  `(asset, category, endpoint, module)`.

## What this toolkit does NOT do

- No destructive exploitation.
- No credential attacks, brute force, or password spraying.
- No denial-of-service testing.
- No unauthorized access to private data.
- No proxy rotation, identity rotation, or rate-limit evasion.
- No CAPTCHA bypass.
