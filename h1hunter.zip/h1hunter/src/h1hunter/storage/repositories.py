"""Repositories over the SQLite schema.

Upserts merge a new discovery into an existing record: the earliest
``discovered_at`` wins, and ``metadata.sources`` accumulates every contributing
source. The schema is never widened by data.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset, ScopeStatus
from h1hunter.storage.database import Database

__all__ = ["AssetRepository"]

logger = logging.getLogger(__name__)


def _iso(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


def _parse_iso(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _row_to_asset(row: sqlite3.Row) -> Asset:
    return Asset(
        hostname=row["hostname"],
        domain=row["domain"],
        source=row["source"],
        discovered_at=_parse_iso(row["discovered_at"]),
        scope_status=ScopeStatus(row["scope_status"]),
        dns_records=json.loads(row["dns_records"] or "{}"),
        metadata=json.loads(row["metadata"] or "{}"),
    )


class AssetRepository:
    def __init__(self, database: Database) -> None:
        self._db = database

    def upsert(self, asset: Asset) -> None:
        conn = self._db.connection
        try:
            with conn:
                existing_row = conn.execute(
                    "SELECT * FROM assets WHERE hostname = ?", (asset.hostname,),
                ).fetchone()
                if existing_row is None:
                    conn.execute(
                        """
                        INSERT INTO assets
                            (hostname, domain, source, discovered_at,
                             scope_status, dns_records, metadata)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            asset.hostname, asset.domain, asset.source,
                            _iso(asset.discovered_at), asset.scope_status.value,
                            json.dumps(asset.dns_records, sort_keys=True),
                            json.dumps(asset.metadata, sort_keys=True, default=str),
                        ),
                    )
                    return
                merged = self._merge(_row_to_asset(existing_row), asset)
                conn.execute(
                    """
                    UPDATE assets SET
                        domain = ?, source = ?, discovered_at = ?,
                        scope_status = ?, dns_records = ?, metadata = ?
                    WHERE hostname = ?
                    """,
                    (
                        merged.domain, merged.source, _iso(merged.discovered_at),
                        merged.scope_status.value,
                        json.dumps(merged.dns_records, sort_keys=True),
                        json.dumps(merged.metadata, sort_keys=True, default=str),
                        merged.hostname,
                    ),
                )
        except sqlite3.Error as exc:
            raise StorageError(f"failed to upsert {asset.hostname}: {exc}") from exc

    def upsert_many(self, assets: Iterable[Asset]) -> int:
        count = 0
        for asset in assets:
            self.upsert(asset)
            count += 1
        return count

    def get(self, hostname: str) -> Asset | None:
        conn = self._db.connection
        try:
            row = conn.execute(
                "SELECT * FROM assets WHERE hostname = ?", (hostname,),
            ).fetchone()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to load {hostname}: {exc}") from exc
        return _row_to_asset(row) if row is not None else None

    def list_all(self) -> list[Asset]:
        conn = self._db.connection
        try:
            rows = conn.execute("SELECT * FROM assets ORDER BY hostname").fetchall()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to list assets: {exc}") from exc
        return [_row_to_asset(row) for row in rows]

    def count(self) -> int:
        conn = self._db.connection
        try:
            row = conn.execute("SELECT COUNT(*) AS n FROM assets").fetchone()
        except sqlite3.Error as exc:
            raise StorageError(f"failed to count assets: {exc}") from exc
        return int(row["n"]) if row is not None else 0

    @staticmethod
    def _merge(existing: Asset, incoming: Asset) -> Asset:
        earlier = existing if existing.discovered_at <= incoming.discovered_at else incoming
        later = incoming if earlier is existing else existing
        sources = set(earlier.metadata.get("sources", []))
        sources.update(later.metadata.get("sources", []))
        sources.add(earlier.source)
        sources.add(later.source)
        metadata = dict(earlier.metadata)
        for key, value in later.metadata.items():
            metadata.setdefault(key, value)
        metadata["sources"] = sorted(sources)
        metadata["first_seen"] = _iso(earlier.discovered_at)
        metadata["last_seen"] = _iso(later.discovered_at)
        dns_records: dict[str, list[str]] = {
            k: list(v) for k, v in earlier.dns_records.items()
        }
        for rtype, values in later.dns_records.items():
            bucket = dns_records.setdefault(rtype, [])
            for value in values:
                if value not in bucket:
                    bucket.append(value)
            bucket.sort()
        return Asset(
            hostname=earlier.hostname,
            domain=earlier.domain or later.domain,
            source=earlier.source,
            discovered_at=earlier.discovered_at,
            scope_status=earlier.scope_status,
            dns_records=dns_records,
            metadata=metadata,
        )
