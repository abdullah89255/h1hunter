"""Persistence for discovered assets."""

from __future__ import annotations

from h1hunter.storage.database import Database
from h1hunter.storage.repositories import AssetRepository

__all__ = ["AssetRepository", "Database"]
