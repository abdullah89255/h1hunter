"""SQLite persistence layer.

All writes use parameterized queries. Records are validated by the ``Asset``
model before they are handed to a repository, so the schema stores only
already-validated data.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from h1hunter.exceptions import StorageError

__all__ = ["Database", "SCHEMA_SQL"]

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS assets (
    hostname        TEXT PRIMARY KEY,
    domain          TEXT,
    source          TEXT NOT NULL,
    discovered_at   TEXT NOT NULL,
    scope_status    TEXT NOT NULL,
    dns_records     TEXT NOT NULL DEFAULT '{}',
    metadata        TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_assets_domain       ON assets(domain);
CREATE INDEX IF NOT EXISTS idx_assets_scope_status ON assets(scope_status);
CREATE INDEX IF NOT EXISTS idx_assets_discovered   ON assets(discovered_at);
"""


class Database:
    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._conn: sqlite3.Connection | None = None

    @property
    def path(self) -> Path:
        return self._path

    @property
    def connection(self) -> sqlite3.Connection:
        if self._conn is None:
            raise StorageError("database is not open; use it as a context manager")
        return self._conn

    def open(self) -> sqlite3.Connection:
        if self._conn is None:
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                self._conn = sqlite3.connect(str(self._path))
            except (OSError, sqlite3.Error) as exc:
                raise StorageError(
                    f"cannot open database {self._path}: {exc}"
                ) from exc
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA foreign_keys = ON")
            self._conn.execute("PRAGMA journal_mode = WAL")
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def initialize_schema(self) -> None:
        conn = self.open()
        try:
            with conn:
                conn.executescript(SCHEMA_SQL)
        except sqlite3.Error as exc:
            raise StorageError(
                f"cannot initialize schema in {self._path}: {exc}"
            ) from exc

    def __enter__(self) -> "Database":
        self.open()
        self.initialize_schema()
        return self

    def __exit__(self, *_exc_info: object) -> bool:
        self.close()
        return False
