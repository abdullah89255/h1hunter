"""Asset data model."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from h1hunter.utils.normalization import normalize_hostname

__all__ = ["Asset", "ScopeStatus", "utcnow"]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ScopeStatus(str, Enum):
    UNVALIDATED = "unvalidated"
    IN_SCOPE = "in_scope"
    OUT_OF_SCOPE = "out_of_scope"
    EXCLUDED = "excluded"


class Asset(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    hostname: str
    domain: str | None = None
    source: str = Field(min_length=1)
    discovered_at: datetime = Field(default_factory=utcnow)
    scope_status: ScopeStatus = ScopeStatus.UNVALIDATED
    dns_records: dict[str, list[str]] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("hostname")
    @classmethod
    def _normalize_hostname(cls, value: str) -> str:
        return normalize_hostname(value)

    @field_validator("discovered_at")
    @classmethod
    def _require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value

    def dedup_key(self) -> str:
        return self.hostname
