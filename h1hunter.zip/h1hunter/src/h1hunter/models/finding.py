"""Normalized finding model."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = [
    "ConfidenceLevel", "Finding", "SeverityLevel", "VerificationStatus", "utcnow",
]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ConfidenceLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SeverityLevel(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return _SEVERITY_ORDER[self]


_SEVERITY_ORDER = {
    SeverityLevel.INFO: 0,
    SeverityLevel.LOW: 1,
    SeverityLevel.MEDIUM: 2,
    SeverityLevel.HIGH: 3,
    SeverityLevel.CRITICAL: 4,
}


class VerificationStatus(str, Enum):
    UNVERIFIED = "unverified"
    REQUIRES_INVESTIGATION = "requires_investigation"
    MANUALLY_VERIFIED = "manually_verified"


class Finding(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str
    title: str = Field(min_length=1)
    category: str = Field(min_length=1)
    affected_asset: str = Field(min_length=1)
    affected_endpoint: str | None = None
    detection_module: str = Field(min_length=1)
    evidence: dict[str, Any] = Field(default_factory=dict)
    reproduction: str = ""
    confidence: ConfidenceLevel = ConfidenceLevel.LOW
    severity: SeverityLevel = SeverityLevel.INFO
    severity_rationale: str = ""
    potential_impact: str = ""
    remediation: str = ""
    scope_validation: str = "unvalidated"
    discovered_at: datetime = Field(default_factory=utcnow)
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED

    @field_validator("discovered_at")
    @classmethod
    def _require_tz(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value

    @classmethod
    def make_id(
        cls, *, module: str, category: str, asset: str, endpoint: str | None
    ) -> str:
        raw = f"{module}|{category}|{asset}|{endpoint or ''}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def dedup_key(self) -> tuple[str, str, str, str]:
        return (
            self.affected_asset, self.category,
            self.affected_endpoint or "", self.detection_module,
        )
