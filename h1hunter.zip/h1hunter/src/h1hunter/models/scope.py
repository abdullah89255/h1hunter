"""Scope data model."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "EntryKind", "ProgramInfo", "ScopeConfig", "ScopeDecision",
    "ScopeEntry", "ScopeSettings",
]


class EntryKind(str, Enum):
    DOMAIN = "domain"
    WILDCARD = "wildcard"
    URL = "url"
    IP = "ip"
    CIDR = "cidr"


class ScopeEntry(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    raw: str
    kind: EntryKind
    host: str | None = None
    scheme: str | None = None
    port: int | None = None
    path_prefix: str | None = None
    network: str | None = None

    def describe(self) -> str:
        match self.kind:
            case EntryKind.WILDCARD:
                return f"*.{self.host}"
            case EntryKind.URL:
                port = f":{self.port}" if self.port is not None else ""
                return f"{self.scheme}://{self.host}{port}{self.path_prefix or '/'}"
            case EntryKind.CIDR | EntryKind.IP:
                return self.network or self.raw
            case _:
                return self.host or self.raw


class ProgramInfo(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str = Field(min_length=1)
    policy_reviewed: bool = False
    policy_url: str | None = None
    authorized_by: str | None = None


class ScopeSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    passive_recon: bool = True
    active_checks: bool = False
    max_concurrency: int = Field(default=3, ge=1, le=50)
    requests_per_second: float = Field(default=2.0, gt=0, le=100)
    timeout_seconds: float = Field(default=10.0, gt=0, le=120)
    max_requests: int = Field(default=500, ge=1, le=100_000)
    max_response_bytes: int = Field(default=1_048_576, ge=1024, le=52_428_800)
    allow_private_networks: bool = False


class ScopeConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    program: ProgramInfo
    allowed: list[ScopeEntry] = Field(min_length=1)
    excluded: list[ScopeEntry] = Field(default_factory=list)
    settings: ScopeSettings = Field(default_factory=ScopeSettings)


class ScopeDecision(BaseModel):
    model_config = ConfigDict(frozen=True)
    target: str
    normalized_host: str | None
    allowed: bool
    reason: str
    matched_rule: str | None = None
