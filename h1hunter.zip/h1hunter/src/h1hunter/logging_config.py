"""Structured logging with mandatory secret redaction."""

from __future__ import annotations

import json
import logging
import re
import sys
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from rich.logging import RichHandler

__all__ = [
    "REDACTED",
    "SENSITIVE_KEYS",
    "JsonFormatter",
    "RedactionFilter",
    "configure_logging",
    "redact_mapping",
    "redact_text",
]

REDACTED = "***REDACTED***"

SENSITIVE_KEYS = frozenset(
    {
        "authorization", "proxy-authorization", "cookie", "set-cookie",
        "x-api-key", "x-auth-token", "api-key", "api_key", "apikey",
        "access-token", "access_token", "refresh-token", "refresh_token",
        "client-secret", "client_secret", "password", "passwd", "secret",
        "private-key", "private_key", "session", "sessionid", "session-id",
    }
)

_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)\b(authorization|proxy-authorization)\s*:\s*\S+"),
     r"\1: " + REDACTED),
    (re.compile(r"(?i)\b(cookie|set-cookie)\s*:\s*\S+"), r"\1: " + REDACTED),
    (re.compile(
        r"(?i)\b(api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret"
        r"|password|passwd|secret)\b\s*[=:]\s*\S+"
     ), r"\1: " + REDACTED),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/\-=]+"), "Bearer " + REDACTED),
)


def _normalize_key(key: str) -> str:
    return key.strip().lower().replace("_", "-")


def redact_text(text: str) -> str:
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def redact_mapping(data: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in data.items():
        if _normalize_key(str(key)) in SENSITIVE_KEYS:
            result[key] = REDACTED
        elif isinstance(value, Mapping):
            result[key] = redact_mapping(value)
        elif isinstance(value, (list, tuple)):
            result[key] = [
                redact_mapping(item) if isinstance(item, Mapping) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


class RedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = redact_text(record.msg)
        args = record.args
        if isinstance(args, Mapping):
            record.args = redact_mapping(args)
        elif isinstance(args, tuple):
            record.args = tuple(
                redact_text(item) if isinstance(item, str) else item
                for item in args
            )
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(
    *,
    level: str = "WARNING",
    fmt: str = "console",
    file: str | None = None,
    no_color: bool = False,
) -> None:
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
        handler.close()

    root.setLevel(level.upper())
    redaction = RedactionFilter()

    if fmt == "json":
        stream_handler: logging.Handler = logging.StreamHandler(sys.stderr)
        stream_handler.setFormatter(JsonFormatter())
    else:
        stream_handler = RichHandler(
            rich_tracebacks=True,
            show_path=False,
            markup=False,
            console_kwargs={"no_color": no_color, "stderr": True},
        )
        stream_handler.setFormatter(logging.Formatter("%(message)s"))

    stream_handler.addFilter(redaction)
    root.addHandler(stream_handler)

    if file:
        fh = logging.FileHandler(file, encoding="utf-8")
        fh.setFormatter(JsonFormatter())
        fh.addFilter(redaction)
        root.addHandler(fh)
