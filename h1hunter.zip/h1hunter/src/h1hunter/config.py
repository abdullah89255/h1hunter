"""Application configuration loading and validation."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from h1hunter.exceptions import ConfigurationError

__all__ = [
    "AppConfig", "LoggingSettings", "PassiveSourceSettings",
    "DEFAULT_CONFIG_PATH", "DEFAULT_SCOPE_PATH",
    "load_app_config", "get_secret",
]

DEFAULT_CONFIG_PATH = Path("config/config.yaml")
DEFAULT_SCOPE_PATH = Path("config/scope.yaml")


class LoggingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "WARNING"
    format: Literal["console", "json"] = "console"
    file: str | None = None


class PassiveSourceSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    enabled: bool = False
    options: dict[str, Any] = Field(default_factory=dict)


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    timeout_seconds: float = Field(default=10.0, gt=0, le=120)
    max_concurrency: int = Field(default=3, ge=1, le=50)
    requests_per_second: float = Field(default=2.0, gt=0, le=100)
    max_retries: int = Field(default=2, ge=0, le=5)
    max_requests: int = Field(default=500, ge=1, le=100_000)
    max_response_bytes: int = Field(default=1_048_576, ge=1024, le=52_428_800)
    output_dir: Path = Path("output")
    user_agent: str = "h1hunter/0.4 (+authorized-security-research)"
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    enabled_modules: list[str] = Field(default_factory=list)
    passive_sources: list[PassiveSourceSettings] = Field(default_factory=list)


def load_app_config(path: str | Path | None = None) -> AppConfig:
    if path is None:
        return AppConfig()
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigurationError(f"configuration file not found: {config_path}")
    try:
        raw = config_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigurationError(f"cannot read configuration {config_path}: {exc}") from exc
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML in {config_path}: {exc}") from exc
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise ConfigurationError(f"configuration must be a mapping: {config_path}")
    try:
        return AppConfig(**data)
    except ValidationError as exc:
        raise ConfigurationError(f"invalid configuration {config_path}: {exc}") from exc


def get_secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None
