"""Command-line interface for h1hunter."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

import httpx
from rich.console import Console
from rich.table import Table

from h1hunter import __version__
from h1hunter.checks import (
    ApiDocsCheck, ExposureCheck, HeadersCheck, ReflectionCheck,
    SocketTlsProbe, TlsCheck,
)
from h1hunter.checks.base import CheckContext, CheckProtocol
from h1hunter.config import (
    DEFAULT_CONFIG_PATH, DEFAULT_SCOPE_PATH, AppConfig, load_app_config,
)
from h1hunter.engine.safety import SafetyEngine, SafetyPolicy
from h1hunter.exceptions import (
    ConfigurationError, H1HunterError, SafetyError,
    ScopeParseError, ScopeViolation, StorageError,
)
from h1hunter.logging_config import configure_logging
from h1hunter.models.asset import ScopeStatus
from h1hunter.models.finding import SeverityLevel
from h1hunter.models.scope import EntryKind, ScopeEntry
from h1hunter.recon.dns import (
    DnsInspector, DnsResolver, DnsResolverProtocol, DnsResult,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult
from h1hunter.recon.passive import PassiveReconEngine
from h1hunter.recon.registry import build_sources_from_config
from h1hunter.recon.runner import run_concurrently
from h1hunter.reporting import (
    read_findings_json, write_csv, write_findings_csv, write_findings_json,
    write_findings_markdown, write_json, write_records_json,
)
from h1hunter.scope.parser import load_scope_file
from h1hunter.scope.validator import ScopeValidator
from h1hunter.storage import AssetRepository, Database
from h1hunter.utils.deduplication import deduplicate_findings

__all__ = ["build_parser", "main"]

logger = logging.getLogger(__name__)

EXIT_OK = 0
EXIT_DENIED = 1
EXIT_USAGE = 2
EXIT_INTERRUPTED = 130


# --------------------------------------------------------------------------- helpers


def _resolve_scope_path(args) -> Path:
    explicit = getattr(args, "file", None) or getattr(args, "scope", None)
    return Path(explicit) if explicit else DEFAULT_SCOPE_PATH


def _planned_action(entry: ScopeEntry) -> str:
    match entry.kind:
        case EntryKind.DOMAIN:
            return "resolve + bounded HTTP probe of the apex"
        case EntryKind.WILDCARD:
            return "candidates must be discovered; each is validated before probing"
        case EntryKind.URL:
            return "resolve + bounded HTTP probe within the authorized path prefix"
        case EntryKind.IP | EntryKind.CIDR:
            return "literal-IP targets only; each is validated before connecting"
    return "no action planned"


def _read_target_lines(path: Path) -> list[str]:
    if not path.exists():
        raise ConfigurationError(f"targets file not found: {path}")
    if not path.is_file():
        raise ConfigurationError(f"targets path is not a file: {path}")
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigurationError(f"cannot read targets file {path}: {exc}") from exc
    result: list[str] = []
    for line in text.splitlines():
        candidate = line.split("#", 1)[0].strip()
        if candidate:
            result.append(candidate)
    return result


def _infer_format(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return "csv"
    if suffix == ".json":
        return "json"
    if suffix in (".md", ".markdown"):
        return "markdown"
    return "json"


def _require_active(engine: SafetyEngine, console: Console) -> bool:
    if engine.is_killed:
        console.print(f"[red]kill switch is engaged:[/red] {engine.kill_reason}")
        return False
    if not engine.policy.active_checks:
        console.print(
            "[red]active checks are disabled.[/red] Set 'active_checks: true' "
            "and 'policy_reviewed: true' in the scope file."
        )
        return False
    return True


def _collect_targets(args) -> list[str]:
    targets: list[str] = list(getattr(args, "target", []) or [])
    targets_file = getattr(args, "targets_file", None)
    if targets_file:
        targets.extend(_read_target_lines(Path(targets_file)))
    seen: set[str] = set()
    unique: list[str] = []
    for t in targets:
        if t not in seen:
            seen.add(t)
            unique.append(t)
    return unique


def _make_resolver(app_config: AppConfig) -> DnsResolverProtocol:
    return DnsResolver(timeout_seconds=app_config.timeout_seconds)


def _make_http_client(app_config: AppConfig) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=app_config.timeout_seconds,
        follow_redirects=False,
        trust_env=False,
        headers={"User-Agent": app_config.user_agent},
    )


def _make_tls_probe() -> SocketTlsProbe:
    return SocketTlsProbe()


def _print_active_plan(
    console: Console, engine: SafetyEngine, targets: list[str], *, kind: str,
) -> None:
    console.print(f"[bold]h1hunter recon {kind} — DRY RUN[/bold]")
    console.print("[bold]No network traffic will be sent.[/bold]\n")
    console.print(f"Program:           {engine.validator.program_name}")
    console.print(f"Policy reviewed:   {engine.validator.policy_reviewed}")
    console.print(f"Active checks:     {engine.policy.active_checks}")
    console.print(f"Rate limit:        {engine.policy.requests_per_second:g} req/s")
    console.print(f"Max concurrency:   {engine.policy.max_concurrency}")
    console.print(f"Timeout:           {engine.policy.timeout_seconds:g}s")
    console.print(f"Request budget:    {engine.policy.max_requests}")
    console.print(f"Max response size: {engine.policy.max_response_bytes} bytes\n")
    table = Table(title=f"Planned {kind} targets (scope evaluation only)")
    table.add_column("Target", style="cyan")
    table.add_column("Decision")
    table.add_column("Reason")
    for target in targets:
        decision = engine.validator.evaluate(target)
        if decision.allowed:
            table.add_row(target, "[green]ALLOW[/green]", decision.reason)
        else:
            table.add_row(target, "[red]DENY[/red]", decision.reason)
    console.print(table)
    if not engine.policy.active_checks:
        console.print(
            "\n[yellow]Active checks are disabled; a real run would refuse to "
            "start.[/yellow]"
        )


# ---------------------------------------------------------------------------- commands


def cmd_version(args, console):
    console.print(f"h1hunter {__version__}")
    return EXIT_OK


def cmd_scope_validate(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    console.print(f"[green]Scope file is valid:[/green] {scope_path}")
    console.print(f"Program:          {scope.program.name}")
    console.print(f"Policy reviewed:  {scope.program.policy_reviewed}")
    console.print(f"Allowed entries:  {len(scope.allowed)}")
    console.print(f"Excluded entries: {len(scope.excluded)}")
    console.print(f"Active checks:    {scope.settings.active_checks}")
    console.print(
        f"Rate limit:       {scope.settings.requests_per_second:g} req/s, "
        f"concurrency {scope.settings.max_concurrency}"
    )
    console.print(
        f"Budget:           {scope.settings.max_requests} requests, "
        f"{scope.settings.timeout_seconds:g}s timeout"
    )
    if not scope.program.policy_reviewed:
        console.print(
            "[yellow]Warning: policy_reviewed is false. Active scanning will be "
            "refused until you review the current program policy.[/yellow]"
        )
    return EXIT_OK


def cmd_scope_check(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    validator = ScopeValidator(scope)
    decision = validator.evaluate(args.target)
    if decision.allowed:
        console.print(f"[green]ALLOWED[/green]  {args.target}")
    else:
        console.print(f"[red]DENIED[/red]   {args.target}")
    console.print(f"Reason: {decision.reason}")
    if decision.normalized_host:
        console.print(f"Normalized host: {decision.normalized_host}")
    return EXIT_OK if decision.allowed else EXIT_DENIED


def cmd_plan(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    validator = ScopeValidator(scope)
    policy = SafetyPolicy.from_scope(scope)
    console.print("[bold]h1hunter dry run — no network traffic will be sent[/bold]")
    console.print()
    console.print(f"Scope file:        {scope_path}")
    console.print(f"Program:           {scope.program.name}")
    console.print(f"Policy reviewed:   {scope.program.policy_reviewed}")
    console.print(f"Active checks:     {policy.active_checks}")
    console.print(f"Rate limit:        {policy.requests_per_second:g} req/s")
    console.print(f"Max concurrency:   {policy.max_concurrency}")
    console.print(f"Request budget:    {policy.max_requests}")
    console.print(f"Timeout:           {policy.timeout_seconds:g}s")
    console.print(
        f"Private networks:  {'allowed' if policy.allow_private_networks else 'blocked'}"
    )
    console.print()
    allowed_table = Table(title="Authorized scope entries")
    allowed_table.add_column("Entry", style="cyan")
    allowed_table.add_column("Kind")
    allowed_table.add_column("Planned action")
    for entry in scope.allowed:
        allowed_table.add_row(entry.raw, entry.kind.value, _planned_action(entry))
    console.print(allowed_table)
    if scope.excluded:
        console.print()
        excluded_table = Table(title="Excluded entries (always denied)")
        excluded_table.add_column("Entry", style="magenta")
        excluded_table.add_column("Kind")
        for entry in scope.excluded:
            excluded_table.add_row(entry.raw, entry.kind.value)
        console.print(excluded_table)
    if args.targets:
        console.print()
        candidate_table = Table(title="Candidate evaluation (no traffic sent)")
        candidate_table.add_column("Target")
        candidate_table.add_column("Decision")
        candidate_table.add_column("Reason")
        for target in args.targets:
            decision = validator.evaluate(target)
            if decision.allowed:
                candidate_table.add_row(target, "[green]ALLOW[/green]", decision.reason)
            else:
                candidate_table.add_row(target, "[red]DENY[/red]", decision.reason)
        console.print(candidate_table)
    console.print()
    if policy.active_checks:
        console.print("[green]An active run would be permitted to start.[/green]")
    else:
        console.print(
            "[yellow]Active checks are disabled; an active run would refuse to "
            "start.[/yellow]"
        )
    return EXIT_OK


def cmd_recon_passive(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    if not scope.settings.passive_recon:
        console.print(
            "[red]passive_recon is disabled in the scope settings; refusing to "
            "run.[/red]"
        )
        return EXIT_USAGE
    app_config = load_app_config(args.config) if args.config else AppConfig()
    sources = build_sources_from_config(app_config.passive_sources)
    if not sources:
        console.print(
            "[red]no enabled passive sources configured; add at least one entry "
            "under 'passive_sources' in your config file.[/red]"
        )
        return EXIT_USAGE
    validator = ScopeValidator(scope)
    engine = PassiveReconEngine(sources, validator=validator)
    result = asyncio.run(engine.run())
    console.print(
        f"[green]Passive recon complete:[/green] "
        f"{len(result.assets)} unique assets from {len(result.sources_run)} "
        f"source(s) in {result.duration_seconds:.2f}s"
    )
    for name, error in result.sources_failed:
        console.print(f"[yellow]source {name!r} failed:[/yellow] {error}")
    if result.assets:
        summary = Table(title="Discovered assets")
        summary.add_column("Hostname", style="cyan")
        summary.add_column("Status")
        summary.add_column("Sources")
        for asset in result.assets[:25]:
            sources_str = ",".join(
                str(s) for s in asset.metadata.get("sources", [asset.source])
            )
            status = asset.scope_status.value
            colour = {
                ScopeStatus.IN_SCOPE.value: "green",
                ScopeStatus.EXCLUDED.value: "magenta",
                ScopeStatus.OUT_OF_SCOPE.value: "yellow",
            }.get(status, "white")
            summary.add_row(asset.hostname, f"[{colour}]{status}[/{colour}]", sources_str)
        if len(result.assets) > 25:
            summary.add_row("…", f"({len(result.assets) - 25} more)", "")
        console.print(summary)
    if args.db:
        with Database(args.db) as db:
            repo = AssetRepository(db)
            repo.upsert_many(result.assets)
            console.print(f"[green]Persisted assets to[/green] {args.db}")
    if args.output:
        fmt = args.format or _infer_format(args.output)
        if fmt == "json":
            write_json(result.assets, args.output)
        elif fmt == "csv":
            write_csv(result.assets, args.output)
        else:
            console.print(f"[red]unsupported output format: {fmt}[/red]")
            return EXIT_USAGE
        console.print(f"[green]Wrote[/green] {args.output}")
    console.print(
        "[dim]Discovered assets are unvalidated. Run each through "
        "'h1hunter scope check' before any active testing.[/dim]"
    )
    return EXIT_OK


def cmd_recon_dns(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    app_config = load_app_config(args.config) if args.config else AppConfig()
    engine = SafetyEngine.from_scope(scope)
    targets = _collect_targets(args)
    if not targets:
        console.print("[red]no targets provided (use --target or --targets-file)[/red]")
        return EXIT_USAGE
    if args.dry_run:
        _print_active_plan(console, engine, targets, kind="dns")
        return EXIT_OK
    if not _require_active(engine, console):
        return EXIT_USAGE
    resolver = _make_resolver(app_config)
    inspector = DnsInspector(engine, resolver)
    console.print(
        f"[bold]Inspecting DNS for {len(targets)} target(s)[/bold] "
        f"(concurrency {engine.policy.max_concurrency}, "
        f"rate {engine.policy.requests_per_second:g} req/s)"
    )

    async def run() -> list[DnsResult]:
        return await run_concurrently(
            targets, inspector.inspect, engine.policy.max_concurrency
        )

    try:
        results = asyncio.run(run())
    except KeyboardInterrupt:
        engine.kill("interrupted by operator")
        console.print("[yellow]interrupted[/yellow]")
        return EXIT_INTERRUPTED
    table = Table(title="DNS inspection results")
    table.add_column("Hostname", style="cyan")
    table.add_column("Records")
    table.add_column("Status")
    for r in results:
        if r.skipped:
            table.add_row(r.hostname, "-", f"[yellow]skipped: {r.skip_reason}[/yellow]")
            continue
        bits = ", ".join(f"{k}={len(v)}" for k, v in sorted(r.records.items()))
        status = "ok" if r.records else "[dim]no records[/dim]"
        if r.errors:
            status = f"[yellow]partial ({len(r.errors)} errors)[/yellow]"
        table.add_row(r.hostname, bits or "-", status)
    console.print(table)
    console.print(
        f"\nBudget used: {engine.requests_made} / {engine.policy.max_requests} "
        f"(remaining {engine.budget_remaining})"
    )
    if args.output:
        write_records_json(results, args.output)
        console.print(f"[green]Wrote[/green] {args.output}")
    return EXIT_OK


def cmd_recon_probe(args, console):
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    app_config = load_app_config(args.config) if args.config else AppConfig()
    engine = SafetyEngine.from_scope(scope)
    targets = _collect_targets(args)
    if not targets:
        console.print("[red]no targets provided (use --target or --targets-file)[/red]")
        return EXIT_USAGE
    if args.dry_run:
        _print_active_plan(console, engine, targets, kind="probe")
        return EXIT_OK
    if not _require_active(engine, console):
        return EXIT_USAGE
    resolver = _make_resolver(app_config)
    console.print(
        f"[bold]Probing {len(targets)} target(s)[/bold] "
        f"(concurrency {engine.policy.max_concurrency}, "
        f"rate {engine.policy.requests_per_second:g} req/s)"
    )

    async def run() -> list[ProbeResult]:
        async with _make_http_client(app_config) as client:
            prober = HttpProber(engine, client, resolver)
            return await run_concurrently(
                targets, prober.probe, engine.policy.max_concurrency
            )

    try:
        results = asyncio.run(run())
    except KeyboardInterrupt:
        engine.kill("interrupted by operator")
        console.print("[yellow]interrupted[/yellow]")
        return EXIT_INTERRUPTED
    table = Table(title="HTTP probe results")
    table.add_column("URL", style="cyan")
    table.add_column("Status")
    table.add_column("Bytes")
    table.add_column("Redirects")
    table.add_column("Notes")
    for r in results:
        status = str(r.status_code) if r.status_code is not None else "-"
        bytes_str = f"{r.body_bytes}{'+' if r.truncated else ''}"
        notes = r.error or ("[yellow]body truncated[/yellow]" if r.truncated else "")
        table.add_row(r.url, status, bytes_str, str(len(r.redirects)), notes)
    console.print(table)
    console.print(
        f"\nBudget used: {engine.requests_made} / {engine.policy.max_requests} "
        f"(remaining {engine.budget_remaining})"
    )
    if args.output:
        write_records_json(results, args.output)
        console.print(f"[green]Wrote[/green] {args.output}")
    return EXIT_OK


# --------------------------------------------------------------- Phase 4 checks


def _instantiate_check(
    module: str, engine: SafetyEngine, client: httpx.AsyncClient,
    resolver: DnsResolverProtocol,
) -> CheckProtocol:
    if module == "headers":
        return HeadersCheck(HttpProber(engine, client, resolver))
    if module == "exposure":
        return ExposureCheck(HttpProber(engine, client, resolver))
    if module == "api-docs":
        return ApiDocsCheck(HttpProber(engine, client, resolver))
    if module == "reflection":
        return ReflectionCheck(HttpProber(engine, client, resolver))
    if module == "tls":
        return TlsCheck(_make_tls_probe())
    raise ConfigurationError(f"unknown check module: {module}")


def _render_findings_table(console: Console, findings) -> None:
    if not findings:
        console.print("[yellow]No findings.[/yellow]")
        return
    table = Table(title=f"Findings ({len(findings)})")
    table.add_column("Severity", style="cyan")
    table.add_column("Title")
    table.add_column("Asset")
    table.add_column("Verification")
    for f in findings:
        colour = {
            SeverityLevel.CRITICAL: "red",
            SeverityLevel.HIGH: "red",
            SeverityLevel.MEDIUM: "yellow",
            SeverityLevel.LOW: "green",
            SeverityLevel.INFO: "dim",
        }[f.severity]
        table.add_row(
            f"[{colour}]{f.severity.value}[/{colour}]",
            f.title, f.affected_asset, f.verification_status.value,
        )
    console.print(table)


def _write_findings(findings, output: Path, fmt: str) -> None:
    if fmt == "json":
        write_findings_json(findings, output)
    elif fmt == "csv":
        write_findings_csv(findings, output)
    elif fmt == "markdown":
        write_findings_markdown(findings, output)
    else:
        raise ConfigurationError(f"unsupported findings format: {fmt}")


def _run_check_module(module: str, args, console) -> int:
    scope_path = _resolve_scope_path(args)
    scope = load_scope_file(scope_path)
    app_config = load_app_config(args.config) if args.config else AppConfig()
    engine = SafetyEngine.from_scope(scope)
    targets = _collect_targets(args)
    if not targets:
        console.print("[red]no targets provided (use --target or --targets-file)[/red]")
        return EXIT_USAGE
    if args.dry_run:
        _print_active_plan(console, engine, targets, kind=f"check {module}")
        return EXIT_OK
    if not _require_active(engine, console):
        return EXIT_USAGE
    resolver = _make_resolver(app_config)
    console.print(
        f"[bold]Running '{module}' check on {len(targets)} target(s)[/bold] "
        f"(concurrency {engine.policy.max_concurrency}, "
        f"rate {engine.policy.requests_per_second:g} req/s)"
    )

    async def run():
        async with _make_http_client(app_config) as client:
            context = CheckContext(engine=engine, client=client, resolver=resolver)
            check = _instantiate_check(module, engine, client, resolver)

            async def one(target: str):
                return await check.run(target, context)

            batches = await run_concurrently(
                targets, one, engine.policy.max_concurrency
            )
            return [f for batch in batches for f in batch]

    try:
        raw_findings = asyncio.run(run())
    except KeyboardInterrupt:
        engine.kill("interrupted by operator")
        console.print("[yellow]interrupted[/yellow]")
        return EXIT_INTERRUPTED
    findings = deduplicate_findings(raw_findings)
    _render_findings_table(console, findings)
    console.print(
        f"\nBudget used: {engine.requests_made} / {engine.policy.max_requests} "
        f"(remaining {engine.budget_remaining})"
    )
    output = getattr(args, "output", None)
    if output:
        fmt = getattr(args, "format", None) or _infer_format(output)
        _write_findings(findings, output, fmt)
        console.print(f"[green]Wrote {len(findings)} finding(s) to[/green] {output}")
    console.print(
        "[dim]Findings are heuristic. Verify manually before submitting to a "
        "program.[/dim]"
    )
    return EXIT_OK


def cmd_check_headers(args, console):
    return _run_check_module("headers", args, console)


def cmd_check_tls(args, console):
    return _run_check_module("tls", args, console)


def cmd_check_exposure(args, console):
    return _run_check_module("exposure", args, console)


def cmd_check_api_docs(args, console):
    return _run_check_module("api-docs", args, console)


def cmd_check_reflection(args, console):
    return _run_check_module("reflection", args, console)


def cmd_report(args, console):
    findings = read_findings_json(args.input)
    output = args.output or Path(f"report.{args.format}")
    if output.exists():
        console.print(f"[red]refusing to overwrite existing file:[/red] {output}")
        return EXIT_USAGE
    _write_findings(findings, output, args.format)
    console.print(
        f"[green]Wrote {len(findings)} finding(s) as {args.format} to[/green] {output}"
    )
    return EXIT_OK


# ------------------------------------------------------------------------------ parser


def _add_check_common(parser: argparse.ArgumentParser, *, dry_run_help: str) -> None:
    parser.add_argument("--file", type=Path, default=None)
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument(
        "--target", action="append", default=[], metavar="TARGET",
        help="Repeatable target.",
    )
    parser.add_argument(
        "--targets-file", type=Path, default=None,
        help="Read newline-separated targets from this file.",
    )
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument(
        "--format", choices=("json", "csv", "markdown"), default=None,
        help="Report format (inferred from --output extension by default).",
    )
    parser.add_argument("--dry-run", action="store_true", help=dry_run_help)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="h1hunter",
        description=(
            "Safe-by-default reconnaissance and low-impact check toolkit for "
            "authorized HackerOne bug bounty programs."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--scope", type=Path, default=None)
    parser.add_argument("-v", "--verbose", action="count", default=0)
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("--log-format", choices=("console", "json"), default=None)
    parser.add_argument(
        "--version", action="version", version=f"h1hunter {__version__}"
    )

    sub = parser.add_subparsers(dest="command", required=True)

    v = sub.add_parser("version", help="Print the toolkit version.")
    v.set_defaults(handler=cmd_version)

    scope_p = sub.add_parser("scope", help="Inspect and validate program scope.")
    scope_sub = scope_p.add_subparsers(dest="scope_command", required=True)
    sv = scope_sub.add_parser("validate")
    sv.add_argument("--file", type=Path, default=None)
    sv.set_defaults(handler=cmd_scope_validate)
    sc = scope_sub.add_parser("check")
    sc.add_argument("--file", type=Path, default=None)
    sc.add_argument("--target", required=True)
    sc.set_defaults(handler=cmd_scope_check)

    plan_p = sub.add_parser("plan", help="Show what an active run would do.")
    plan_p.add_argument("--file", type=Path, default=None)
    plan_p.add_argument("--targets", nargs="*", default=[])
    plan_p.set_defaults(handler=cmd_plan)

    recon_p = sub.add_parser("recon", help="Reconnaissance commands.")
    recon_sub = recon_p.add_subparsers(dest="recon_command", required=True)

    passive_p = recon_sub.add_parser("passive")
    passive_p.add_argument("--file", type=Path, default=None)
    passive_p.add_argument("--config", type=Path, default=None)
    passive_p.add_argument("--output", type=Path, default=None)
    passive_p.add_argument("--format", choices=("json", "csv"), default=None)
    passive_p.add_argument("--db", type=Path, default=None)
    passive_p.set_defaults(handler=cmd_recon_passive)

    dns_p = recon_sub.add_parser("dns")
    _add_check_common(dns_p, dry_run_help="Show the plan; send no traffic.")
    dns_p.set_defaults(handler=cmd_recon_dns)

    probe_p = recon_sub.add_parser("probe")
    _add_check_common(probe_p, dry_run_help="Show the plan; send no traffic.")
    probe_p.set_defaults(handler=cmd_recon_probe)

    check_p = sub.add_parser("check", help="Low-impact security checks.")
    check_sub = check_p.add_subparsers(dest="check_command", required=True)

    for name, handler, help_text in (
        ("headers", cmd_check_headers, "Inspect HTTP security headers."),
        ("tls", cmd_check_tls, "Inspect TLS certificate and protocol."),
        ("exposure", cmd_check_exposure, "Request a small set of well-known paths."),
        ("api-docs", cmd_check_api_docs, "Check conventional API docs locations."),
        ("reflection", cmd_check_reflection, "Check for marker reflection."),
    ):
        p = check_sub.add_parser(name, help=help_text)
        _add_check_common(p, dry_run_help="Show the plan; send no traffic.")
        p.set_defaults(handler=handler)

    report_p = sub.add_parser(
        "report", help="Re-emit a findings file in another format."
    )
    report_p.add_argument("--input", type=Path, required=True)
    report_p.add_argument("--output", type=Path, default=None)
    report_p.add_argument(
        "--format", choices=("json", "csv", "markdown"), required=True
    )
    report_p.set_defaults(handler=cmd_report)

    return parser


# -------------------------------------------------------------------------------- main


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    console = Console(no_color=args.no_color, highlight=False)

    try:
        app_config = load_app_config(args.config) if args.config else AppConfig()
    except ConfigurationError as exc:
        console.print(f"[red]configuration error:[/red] {exc}")
        return EXIT_USAGE

    if args.verbose >= 2:
        level = "DEBUG"
    elif args.verbose == 1:
        level = "INFO"
    else:
        level = app_config.logging.level

    configure_logging(
        level=level,
        fmt=args.log_format or app_config.logging.format,
        file=app_config.logging.file,
        no_color=args.no_color,
    )

    try:
        return int(args.handler(args, console))
    except ScopeParseError as exc:
        console.print(f"[red]scope error:[/red] {exc}")
        return EXIT_USAGE
    except ScopeViolation as exc:
        console.print(f"[red]scope violation:[/red] {exc}")
        return EXIT_DENIED
    except ConfigurationError as exc:
        console.print(f"[red]configuration error:[/red] {exc}")
        return EXIT_USAGE
    except StorageError as exc:
        console.print(f"[red]storage error:[/red] {exc}")
        return EXIT_USAGE
    except SafetyError as exc:
        console.print(f"[red]safety error:[/red] {exc}")
        return EXIT_DENIED
    except H1HunterError as exc:
        console.print(f"[red]error:[/red] {exc}")
        return EXIT_DENIED
    except KeyboardInterrupt:
        console.print("[yellow]interrupted[/yellow]")
        return EXIT_INTERRUPTED


if __name__ == "__main__":
    sys.exit(main())
