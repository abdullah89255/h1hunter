"""Console entry point referenced by the ``h1hunter`` script."""

from __future__ import annotations

from h1hunter.cli import main

__all__ = ["main"]

if __name__ == "__main__":
    raise SystemExit(main())
