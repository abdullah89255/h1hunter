"""h1hunter — safe-by-default reconnaissance toolkit for authorized HackerOne programs."""

from __future__ import annotations

__version__ = "0.4.0"
__all__ = ["__version__"]
