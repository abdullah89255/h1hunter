"""Hostname, path, and target normalization."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from urllib.parse import urlsplit

import idna

from h1hunter.exceptions import ScopeParseError

__all__ = [
    "ParsedTarget", "normalize_hostname", "normalize_path", "parse_target",
    "is_ip_literal", "to_ip", "derive_domain",
]

Address = ipaddress.IPv4Address | ipaddress.IPv6Address

_ASCII_LABEL_RE = re.compile(r"^[a-z0-9_]([a-z0-9_-]*[a-z0-9_])?$")
_SUPPORTED_SCHEMES = frozenset({"http", "https"})


def _strip_brackets(value: str) -> str:
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        return value[1:-1]
    return value


def is_ip_literal(value: str) -> bool:
    if not isinstance(value, str):
        return False
    try:
        ipaddress.ip_address(_strip_brackets(value))
    except ValueError:
        return False
    return True


def to_ip(value: str) -> Address:
    try:
        return ipaddress.ip_address(_strip_brackets(value))
    except ValueError as exc:
        raise ScopeParseError(f"not an IP address: {value!r}") from exc


def _to_ascii(host: str) -> str:
    try:
        return idna.encode(host, uts46=True).decode("ascii")
    except idna.IDNAError as exc:
        if _ascii_fallback(host) is not None:
            return host
        raise ScopeParseError(f"invalid hostname {host!r}: {exc}") from exc


def _ascii_fallback(host: str) -> str | None:
    labels = host.split(".")
    if not labels:
        return None
    for label in labels:
        if not label or len(label) > 63:
            return None
        if not _ASCII_LABEL_RE.match(label):
            return None
    if len(host) > 253:
        return None
    return host


def normalize_hostname(host: str) -> str:
    if not isinstance(host, str):
        raise ScopeParseError(f"hostname must be a string, got {type(host).__name__}")
    candidate = _strip_brackets(host).rstrip(".")
    if not candidate:
        raise ScopeParseError(f"hostname is empty: {host!r}")
    if " " in candidate or "\t" in candidate:
        raise ScopeParseError(f"hostname contains whitespace: {host!r}")
    if "/" in candidate or "@" in candidate or "?" in candidate or "#" in candidate:
        raise ScopeParseError(f"hostname contains a URL component: {host!r}")
    candidate = candidate.lower()
    if is_ip_literal(candidate):
        return str(to_ip(candidate))
    if ".." in candidate:
        raise ScopeParseError(f"hostname contains an empty label: {host!r}")
    return _to_ascii(candidate)


def normalize_path(path: str) -> str:
    if not path:
        return "/"
    if not path.startswith("/"):
        path = "/" + path
    while "//" in path:
        path = path.replace("//", "/")
    if len(path) > 1:
        path = path.rstrip("/") or "/"
    return path


def derive_domain(hostname: str) -> str | None:
    """Approximate registrable domain (final two labels). Not PSL-correct."""
    if is_ip_literal(hostname):
        return None
    labels = hostname.split(".")
    if len(labels) < 2:
        return None
    return ".".join(labels[-2:])


@dataclass(frozen=True, slots=True)
class ParsedTarget:
    raw: str
    host: str
    scheme: str | None
    port: int | None
    path: str
    is_url: bool

    @property
    def is_ip(self) -> bool:
        return is_ip_literal(self.host)

    def display(self) -> str:
        if not self.is_url:
            return self.host
        port = f":{self.port}" if self.port is not None else ""
        return f"{self.scheme}://{self.host}{port}{self.path}"


def _parse_port(parts) -> int | None:
    try:
        return parts.port
    except ValueError as exc:
        raise ScopeParseError(f"invalid port in {parts.geturl()!r}: {exc}") from exc


def _parse_url(raw: str) -> ParsedTarget:
    parts = urlsplit(raw)
    scheme = (parts.scheme or "").lower()
    if scheme not in _SUPPORTED_SCHEMES:
        raise ScopeParseError(f"unsupported URL scheme {scheme!r} in {raw!r}")
    if not parts.hostname:
        raise ScopeParseError(f"URL has no hostname: {raw!r}")
    return ParsedTarget(
        raw=raw, host=normalize_hostname(parts.hostname), scheme=scheme,
        port=_parse_port(parts), path=normalize_path(parts.path), is_url=True,
    )


def parse_target(target: str) -> ParsedTarget:
    if not isinstance(target, str):
        raise ScopeParseError(f"target must be a string, got {type(target).__name__}")
    raw = target.strip()
    if not raw:
        raise ScopeParseError("target is empty")
    if "://" in raw:
        return _parse_url(raw)
    if is_ip_literal(raw):
        return ParsedTarget(
            raw=raw, host=str(to_ip(raw)), scheme=None, port=None, path="/",
            is_url=False,
        )
    parts = urlsplit("//" + raw)
    if not parts.hostname:
        raise ScopeParseError(f"cannot parse target: {raw!r}")
    return ParsedTarget(
        raw=raw, host=normalize_hostname(parts.hostname), scheme=None,
        port=_parse_port(parts), path=normalize_path(parts.path), is_url=False,
    )
