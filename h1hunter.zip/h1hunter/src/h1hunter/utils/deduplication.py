"""Deterministic, source-attributing deduplication for assets and findings."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from h1hunter.models.asset import Asset
from h1hunter.models.finding import ConfidenceLevel, Finding

__all__ = ["deduplicate_assets", "deduplicate_findings"]


def _merge_dns(target: dict[str, list[str]], other: dict[str, list[str]]) -> None:
    for rtype, values in other.items():
        bucket = target.setdefault(rtype, [])
        for value in values:
            if value not in bucket:
                bucket.append(value)
        bucket.sort()


def deduplicate_assets(assets: Iterable[Asset]) -> list[Asset]:
    groups: dict[str, list[Asset]] = {}
    for asset in assets:
        groups.setdefault(asset.dedup_key(), []).append(asset)

    merged: list[Asset] = []
    for hostname in sorted(groups):
        group = groups[hostname]
        group.sort(key=lambda a: (a.discovered_at, a.source))
        primary = group[0]
        sources = sorted({a.source for a in group})
        first_seen = group[0].discovered_at
        last_seen = group[-1].discovered_at
        combined_metadata: dict[str, object] = {}
        for asset in group:
            for key, value in asset.metadata.items():
                combined_metadata.setdefault(key, value)
        combined_metadata["sources"] = sources
        combined_metadata["first_seen"] = first_seen.isoformat()
        combined_metadata["last_seen"] = last_seen.isoformat()
        combined_metadata["discovery_count"] = len(group)
        dns_records: dict[str, list[str]] = {}
        for asset in group:
            _merge_dns(dns_records, asset.dns_records)
        merged.append(
            Asset(
                hostname=primary.hostname,
                domain=primary.domain,
                source=primary.source,
                discovered_at=primary.discovered_at,
                scope_status=primary.scope_status,
                dns_records=dns_records,
                metadata=combined_metadata,
            )
        )
    return merged


_CONFIDENCE_RANK = {
    ConfidenceLevel.LOW: 0,
    ConfidenceLevel.MEDIUM: 1,
    ConfidenceLevel.HIGH: 2,
}


def deduplicate_findings(findings: Iterable[Finding]) -> list[Finding]:
    groups: dict[tuple[str, str, str, str], list[Finding]] = {}
    for finding in findings:
        groups.setdefault(finding.dedup_key(), []).append(finding)

    result: list[Finding] = []
    for key in sorted(groups):
        group = groups[key]
        group.sort(key=lambda f: (
            -f.severity.rank, -_CONFIDENCE_RANK[f.confidence], f.discovered_at,
        ))
        primary = group[0]
        if len(group) == 1:
            result.append(primary)
            continue
        merged_evidence: dict[str, Any] = {}
        for finding in group:
            merged_evidence.update(finding.evidence)
        result.append(primary.model_copy(update={"evidence": merged_evidence}))
    return result
