"""Pure helpers with no project-internal dependencies."""

from __future__ import annotations
