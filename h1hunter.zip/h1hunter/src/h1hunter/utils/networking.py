"""Network destination classification."""

from __future__ import annotations

import ipaddress

__all__ = [
    "METADATA_ADDRESSES", "ip_block_reason", "is_metadata_endpoint",
    "is_public_destination",
]

Address = ipaddress.IPv4Address | ipaddress.IPv6Address

METADATA_ADDRESSES = frozenset(
    {
        "169.254.169.254", "169.254.170.2", "100.100.100.200",
        "192.0.0.192", "fd00:ec2::254",
    }
)


def _as_address(value: str | Address) -> Address:
    if isinstance(value, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
        return value
    if isinstance(value, (ipaddress.IPv4Network, ipaddress.IPv6Network)):
        return value.network_address
    try:
        return ipaddress.ip_address(str(value).strip().strip("[]"))
    except ValueError as exc:
        raise ValueError(f"not an IP address: {value!r}") from exc


def _unwrap(addr: Address) -> Address:
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        return addr.ipv4_mapped
    return addr


def is_metadata_endpoint(value: str | Address) -> bool:
    return str(_unwrap(_as_address(value))) in METADATA_ADDRESSES


def ip_block_reason(
    value: str | Address, *, allow_private: bool = False
) -> str | None:
    addr = _unwrap(_as_address(value))
    if addr.is_multicast:
        return "multicast address"
    if addr.is_unspecified:
        return "unspecified address"
    if addr.is_loopback:
        return "loopback address"
    if is_metadata_endpoint(addr):
        return "cloud metadata endpoint"
    if addr.is_link_local:
        return "link-local address"
    if addr.is_reserved:
        return "reserved address"
    if addr.is_private:
        return None if allow_private else "private address"
    if not addr.is_global:
        return None if allow_private else "non-globally-routable address"
    return None


def is_public_destination(value: str | Address, *, allow_private: bool = False) -> bool:
    return ip_block_reason(value, allow_private=allow_private) is None
