"""The centralized scope-enforcement API."""

from __future__ import annotations

import logging

from h1hunter.exceptions import (
    ScopeNotReviewedError, ScopeParseError, ScopeViolation,
)
from h1hunter.models.scope import ScopeConfig, ScopeDecision
from h1hunter.scope.matcher import entry_matches
from h1hunter.utils.normalization import ParsedTarget, parse_target

__all__ = ["ScopeValidator"]

logger = logging.getLogger(__name__)


class ScopeValidator:
    def __init__(self, scope: ScopeConfig) -> None:
        self._scope = scope

    @property
    def scope(self) -> ScopeConfig:
        return self._scope

    @property
    def program_name(self) -> str:
        return self._scope.program.name

    @property
    def policy_reviewed(self) -> bool:
        return self._scope.program.policy_reviewed

    @property
    def active_checks_enabled(self) -> bool:
        return self._scope.settings.active_checks and self._scope.program.policy_reviewed

    def evaluate(self, target: str) -> ScopeDecision:
        try:
            parsed = parse_target(target)
        except ScopeParseError as exc:
            return ScopeDecision(
                target=target, normalized_host=None, allowed=False,
                reason=f"target could not be parsed: {exc}", matched_rule=None,
            )

        for entry in self._scope.excluded:
            if entry_matches(entry, parsed):
                return ScopeDecision(
                    target=target, normalized_host=parsed.host, allowed=False,
                    reason=f"target matches exclusion {entry.describe()!r}",
                    matched_rule=entry.raw,
                )

        for entry in self._scope.allowed:
            if entry_matches(entry, parsed):
                return ScopeDecision(
                    target=target, normalized_host=parsed.host, allowed=True,
                    reason=f"target matches allowed entry {entry.describe()!r}",
                    matched_rule=entry.raw,
                )

        return ScopeDecision(
            target=target, normalized_host=parsed.host, allowed=False,
            reason="target does not match any allowed scope entry",
            matched_rule=None,
        )

    def is_allowed(self, target: str) -> bool:
        return self.evaluate(target).allowed

    def require(self, target: str) -> ParsedTarget:
        decision = self.evaluate(target)
        if not decision.allowed:
            raise ScopeViolation(f"target {target!r} is out of scope: {decision.reason}")
        return parse_target(target)

    def require_active_authorization(self) -> None:
        if not self._scope.program.policy_reviewed:
            raise ScopeNotReviewedError(
                f"program {self._scope.program.name!r} has policy_reviewed=false; "
                "review the current program policy and set policy_reviewed: true "
                "before running any active test"
            )
        if not self._scope.settings.active_checks:
            raise ScopeNotReviewedError(
                "active_checks is disabled in the scope settings; enable it "
                "explicitly to permit active network testing"
            )
