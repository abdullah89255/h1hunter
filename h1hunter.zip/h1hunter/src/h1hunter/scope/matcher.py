"""Scope entry matching."""

from __future__ import annotations

import ipaddress

from h1hunter.models.scope import EntryKind, ScopeEntry
from h1hunter.utils.normalization import ParsedTarget, to_ip

__all__ = ["entry_matches"]

_DEFAULT_PORTS = {"http": 80, "https": 443}


def entry_matches(entry: ScopeEntry, target: ParsedTarget) -> bool:
    match entry.kind:
        case EntryKind.DOMAIN:
            return _matches_domain(entry, target)
        case EntryKind.WILDCARD:
            return _matches_wildcard(entry, target)
        case EntryKind.URL:
            return _matches_url(entry, target)
        case EntryKind.IP:
            return _matches_ip(entry, target)
        case EntryKind.CIDR:
            return _matches_cidr(entry, target)
    return False


def _matches_domain(entry: ScopeEntry, target: ParsedTarget) -> bool:
    return entry.host is not None and target.host == entry.host


def _matches_wildcard(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.host is None:
        return False
    apex = entry.host
    host = target.host
    if host == apex:
        return False
    return host.endswith("." + apex)


def _matches_ip(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.network is None or not target.is_ip:
        return False
    return to_ip(target.host) == to_ip(entry.network)


def _matches_cidr(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.network is None or not target.is_ip:
        return False
    network = ipaddress.ip_network(entry.network, strict=False)
    addr = to_ip(target.host)
    if addr.version != network.version:
        return False
    return addr in network


def _path_matches(prefix: str, path: str) -> bool:
    if prefix in ("", "/"):
        return True
    if path == prefix:
        return True
    return path.startswith(prefix.rstrip("/") + "/")


def _matches_url(entry: ScopeEntry, target: ParsedTarget) -> bool:
    if entry.host is None or not target.is_url:
        return False
    if target.host != entry.host:
        return False
    if entry.scheme is not None and target.scheme != entry.scheme:
        return False
    if entry.port is not None:
        if target.port != entry.port:
            return False
    else:
        default = _DEFAULT_PORTS.get(entry.scheme or "")
        if target.port is not None and default is not None and target.port != default:
            return False
    if entry.path_prefix is not None and not _path_matches(entry.path_prefix, target.path):
        return False
    return True
