"""Scope parsing, matching, and the centralized authorization API."""

from __future__ import annotations

from h1hunter.scope.matcher import entry_matches
from h1hunter.scope.parser import load_scope_file, parse_scope_entry, parse_scope_text
from h1hunter.scope.validator import ScopeValidator

__all__ = [
    "ScopeValidator", "entry_matches", "load_scope_file",
    "parse_scope_entry", "parse_scope_text",
]
