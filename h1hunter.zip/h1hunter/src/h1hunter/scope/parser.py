"""Scope file parsing."""

from __future__ import annotations

import ipaddress
import logging
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from h1hunter.exceptions import ScopeParseError
from h1hunter.models.scope import (
    EntryKind, ProgramInfo, ScopeConfig, ScopeEntry, ScopeSettings,
)
from h1hunter.utils.normalization import (
    is_ip_literal, normalize_hostname, parse_target, to_ip,
)

__all__ = ["load_scope_file", "parse_scope_entry", "parse_scope_text"]

logger = logging.getLogger(__name__)

_Network = ipaddress.IPv4Network | ipaddress.IPv6Network


def _try_network(value: str) -> _Network | None:
    if "/" not in value:
        return None
    try:
        return ipaddress.ip_network(value, strict=False)
    except ValueError:
        return None


def parse_scope_entry(raw: str) -> ScopeEntry:
    if not isinstance(raw, str):
        raise ScopeParseError(f"scope entry must be a string, got {type(raw).__name__}")
    value = raw.strip()
    if not value:
        raise ScopeParseError("scope entry is empty")

    if value.startswith("*."):
        apex = value[2:]
        if not apex:
            raise ScopeParseError(f"wildcard entry has no apex domain: {raw!r}")
        if "*" in apex:
            raise ScopeParseError(f"unsupported wildcard placement: {raw!r}")
        if "/" in apex or ":" in apex:
            raise ScopeParseError(f"wildcard entry must be a bare domain: {raw!r}")
        host = normalize_hostname(apex)
        if is_ip_literal(host):
            raise ScopeParseError(f"wildcard entry cannot target an IP address: {raw!r}")
        if "." not in host:
            raise ScopeParseError(f"wildcard apex must be a registrable domain: {raw!r}")
        return ScopeEntry(raw=raw, kind=EntryKind.WILDCARD, host=host)

    if "*" in value:
        raise ScopeParseError(f"unsupported wildcard placement: {raw!r}")

    if "://" in value:
        parsed = parse_target(value)
        return ScopeEntry(
            raw=raw, kind=EntryKind.URL, host=parsed.host, scheme=parsed.scheme,
            port=parsed.port, path_prefix=parsed.path,
        )

    if is_ip_literal(value):
        addr = to_ip(value)
        return ScopeEntry(
            raw=raw, kind=EntryKind.IP, host=str(addr), network=str(addr),
        )

    network = _try_network(value)
    if network is not None:
        return ScopeEntry(raw=raw, kind=EntryKind.CIDR, network=str(network))

    host = normalize_hostname(value)
    if "." not in host:
        raise ScopeParseError(
            f"domain entry must contain at least one dot (single-label hosts are "
            f"rejected): {raw!r}"
        )
    return ScopeEntry(raw=raw, kind=EntryKind.DOMAIN, host=host)


def _parse_entry_list(value: Any, *, field: str, source: str) -> list[ScopeEntry]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ScopeParseError(f"'{field}' must be a list in {source}")
    entries: list[ScopeEntry] = []
    for item in value:
        try:
            entries.append(parse_scope_entry(item))
        except ScopeParseError as exc:
            raise ScopeParseError(
                f"invalid entry in '{field}' of {source}: {exc}"
            ) from exc
    return entries


def _log_conflicts(allowed: list[ScopeEntry], excluded: list[ScopeEntry]) -> None:
    allowed_raw = {entry.raw for entry in allowed}
    for entry in excluded:
        if entry.raw in allowed_raw:
            logger.warning(
                "entry %r appears in both 'allowed' and 'excluded'; exclusion wins",
                entry.raw,
            )


def parse_scope_text(text: str, *, source: str = "<memory>") -> ScopeConfig:
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ScopeParseError(f"invalid YAML in {source}: {exc}") from exc
    if data is None:
        raise ScopeParseError(f"scope document is empty: {source}")
    if not isinstance(data, dict):
        raise ScopeParseError(f"scope document must be a mapping: {source}")

    program_raw = data.get("program")
    if not isinstance(program_raw, dict):
        raise ScopeParseError(f"scope document is missing a 'program' mapping: {source}")
    try:
        program = ProgramInfo(**program_raw)
    except ValidationError as exc:
        raise ScopeParseError(f"invalid 'program' section in {source}: {exc}") from exc

    allowed = _parse_entry_list(data.get("allowed"), field="allowed", source=source)
    if not allowed:
        raise ScopeParseError(f"scope document defines no allowed assets: {source}")

    excluded = _parse_entry_list(data.get("excluded"), field="excluded", source=source)

    settings_raw = data.get("settings") or {}
    if not isinstance(settings_raw, dict):
        raise ScopeParseError(f"'settings' must be a mapping in {source}")
    try:
        settings = ScopeSettings(**settings_raw)
    except ValidationError as exc:
        raise ScopeParseError(f"invalid 'settings' section in {source}: {exc}") from exc

    _log_conflicts(allowed, excluded)

    try:
        return ScopeConfig(
            program=program, allowed=allowed, excluded=excluded, settings=settings,
        )
    except ValidationError as exc:
        raise ScopeParseError(f"invalid scope in {source}: {exc}") from exc


def load_scope_file(path: str | Path) -> ScopeConfig:
    scope_path = Path(path)
    if not scope_path.exists():
        raise ScopeParseError(f"scope file not found: {scope_path}")
    if not scope_path.is_file():
        raise ScopeParseError(f"scope path is not a file: {scope_path}")
    try:
        text = scope_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ScopeParseError(f"cannot read scope file {scope_path}: {exc}") from exc
    return parse_scope_text(text, source=str(scope_path))
