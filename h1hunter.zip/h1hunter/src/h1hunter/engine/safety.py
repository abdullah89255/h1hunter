"""The safety engine — the only path from target string to request."""

from __future__ import annotations

import logging
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field

from h1hunter.engine.rate_limiter import TokenBucketRateLimiter
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged, SafetyError,
)
from h1hunter.models.scope import ScopeConfig
from h1hunter.scope.validator import ScopeValidator
from h1hunter.utils.normalization import ParsedTarget
from h1hunter.utils.networking import ip_block_reason

__all__ = ["AuditEvent", "CircuitBreaker", "SafetyEngine", "SafetyPolicy"]

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SafetyPolicy:
    active_checks: bool = False
    max_concurrency: int = 3
    requests_per_second: float = 2.0
    timeout_seconds: float = 10.0
    max_response_bytes: int = 1_048_576
    max_requests: int = 500
    allow_private_networks: bool = False

    @classmethod
    def from_scope(cls, scope: ScopeConfig) -> "SafetyPolicy":
        s = scope.settings
        return cls(
            active_checks=s.active_checks and scope.program.policy_reviewed,
            max_concurrency=s.max_concurrency,
            requests_per_second=s.requests_per_second,
            timeout_seconds=s.timeout_seconds,
            max_response_bytes=s.max_response_bytes,
            max_requests=s.max_requests,
            allow_private_networks=s.allow_private_networks,
        )


@dataclass(frozen=True, slots=True)
class AuditEvent:
    timestamp: float
    action: str
    target: str
    decision: str
    detail: str = ""


@dataclass(slots=True)
class CircuitBreaker:
    failure_threshold: int = 5
    reset_timeout: float = 60.0
    _failures: int = field(default=0, init=False)
    _opened_at: float | None = field(default=None, init=False)

    def record_success(self) -> None:
        self._failures = 0
        self._opened_at = None

    def record_failure(self, *, now: float | None = None) -> None:
        self._failures += 1
        if self._failures >= self.failure_threshold and self._opened_at is None:
            self._opened_at = now if now is not None else time.monotonic()
            logger.warning(
                "circuit breaker opened after %d consecutive failures",
                self._failures,
            )

    @property
    def failure_count(self) -> int:
        return self._failures

    @property
    def is_open(self) -> bool:
        if self._opened_at is None:
            return False
        if (time.monotonic() - self._opened_at) >= self.reset_timeout:
            self._failures = 0
            self._opened_at = None
            return False
        return True


class SafetyEngine:
    def __init__(
        self,
        validator: ScopeValidator,
        policy: SafetyPolicy,
        *,
        limiter: TokenBucketRateLimiter | None = None,
        circuit_breaker: CircuitBreaker | None = None,
    ) -> None:
        self._validator = validator
        self._policy = policy
        self._limiter = limiter or TokenBucketRateLimiter(policy.requests_per_second)
        self._breaker = circuit_breaker or CircuitBreaker()
        self._requests = 0
        self._killed = False
        self._kill_reason: str | None = None
        self._audit: list[AuditEvent] = []

    @classmethod
    def from_scope(cls, scope: ScopeConfig) -> "SafetyEngine":
        return cls(ScopeValidator(scope), SafetyPolicy.from_scope(scope))

    @property
    def validator(self) -> ScopeValidator:
        return self._validator

    @property
    def policy(self) -> SafetyPolicy:
        return self._policy

    @property
    def requests_made(self) -> int:
        return self._requests

    @property
    def budget_remaining(self) -> int:
        return max(0, self._policy.max_requests - self._requests)

    @property
    def is_killed(self) -> bool:
        return self._killed

    @property
    def kill_reason(self) -> str | None:
        return self._kill_reason

    @property
    def audit_log(self) -> tuple[AuditEvent, ...]:
        return tuple(self._audit)

    def kill(self, reason: str) -> None:
        self._killed = True
        self._kill_reason = reason
        self._record("kill_switch", "-", "engaged", reason)
        logger.warning("kill switch engaged: %s", reason)

    def require_active_mode(self) -> None:
        if self._killed:
            raise KillSwitchEngaged(self._kill_reason or "kill switch engaged")
        if not self._policy.active_checks:
            raise SafetyError(
                "active checks are disabled by policy; refusing to send network "
                "traffic. Set 'active_checks: true' and 'policy_reviewed: true' "
                "in the scope file."
            )

    def check_destination(self, address: str) -> None:
        reason = ip_block_reason(
            address, allow_private=self._policy.allow_private_networks
        )
        if reason is not None:
            self._record("destination_check", address, "blocked", reason)
            raise DestinationBlocked(f"refusing to connect to {address}: {reason}")

    async def authorize(self, target: str) -> ParsedTarget:
        self.require_active_mode()
        if self._breaker.is_open:
            raise CircuitOpen("circuit breaker is open; pausing active requests")
        if self._requests >= self._policy.max_requests:
            raise BudgetExhausted(
                f"request budget of {self._policy.max_requests} exhausted"
            )
        parsed = self._validator.require(target)
        await self._limiter.acquire()
        self._requests += 1
        self._record("authorize", target, "allowed", f"normalized host {parsed.host}")
        return parsed

    def record_success(self) -> None:
        self._breaker.record_success()

    def record_failure(self) -> None:
        self._breaker.record_failure()

    @asynccontextmanager
    async def guard(self, target: str) -> AsyncIterator[ParsedTarget]:
        parsed = await self.authorize(target)
        try:
            yield parsed
        except Exception:
            self.record_failure()
            raise
        else:
            self.record_success()

    def _record(self, action: str, target: str, decision: str, detail: str = "") -> None:
        event = AuditEvent(
            timestamp=time.time(), action=action, target=target,
            decision=decision, detail=detail,
        )
        self._audit.append(event)
        logger.debug(
            "audit action=%s target=%s decision=%s detail=%s",
            action, target, decision, detail,
        )
