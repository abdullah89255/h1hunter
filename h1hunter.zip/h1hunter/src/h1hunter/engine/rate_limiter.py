"""Async token-bucket rate limiter."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable

__all__ = ["TokenBucketRateLimiter"]


class TokenBucketRateLimiter:
    def __init__(
        self,
        rate: float,
        *,
        capacity: float | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], Awaitable[None]] | None = None,
    ) -> None:
        if rate <= 0:
            raise ValueError("rate must be greater than zero")
        self._rate = float(rate)
        self._capacity = float(capacity) if capacity is not None else max(1.0, float(rate))
        if self._capacity <= 0:
            raise ValueError("capacity must be greater than zero")
        self._tokens = self._capacity
        self._clock = clock
        self._sleep: Callable[[float], Awaitable[None]] = sleep or asyncio.sleep
        self._updated = clock()
        self._lock = asyncio.Lock()

    @property
    def rate(self) -> float:
        return self._rate

    @property
    def capacity(self) -> float:
        return self._capacity

    @property
    def tokens(self) -> float:
        return self._tokens

    async def acquire(self, tokens: float = 1.0) -> float:
        if tokens <= 0:
            raise ValueError("tokens must be greater than zero")
        if tokens > self._capacity:
            raise ValueError(
                f"cannot acquire {tokens} tokens from a bucket of capacity {self._capacity}"
            )
        waited = 0.0
        async with self._lock:
            while True:
                now = self._clock()
                elapsed = now - self._updated
                if elapsed > 0:
                    self._tokens = min(
                        self._capacity, self._tokens + elapsed * self._rate
                    )
                    self._updated = now
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return waited
                delay = (tokens - self._tokens) / self._rate
                waited += delay
                await self._sleep(delay)
