"""Allow ``python -m h1hunter``."""

from __future__ import annotations

from h1hunter.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
