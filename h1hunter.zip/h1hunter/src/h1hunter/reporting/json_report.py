"""JSON export for asset and finding records."""

from __future__ import annotations

import dataclasses
import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset
from h1hunter.models.finding import Finding

__all__ = [
    "write_json", "write_records_json", "write_findings_json", "read_findings_json",
]


def write_json(assets: Iterable[Asset], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    payload = [asset.model_dump(mode="json") for asset in assets]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def _to_mapping(record: Any) -> Any:
    if dataclasses.is_dataclass(record) and not isinstance(record, type):
        return dataclasses.asdict(record)
    if hasattr(record, "model_dump"):
        return record.model_dump(mode="json")
    if isinstance(record, Mapping):
        return dict(record)
    return record


def write_records_json(records: Iterable[Any], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    payload = [_to_mapping(r) for r in records]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                payload, indent=2, sort_keys=True, ensure_ascii=False, default=str,
            ) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def write_findings_json(findings: Iterable[Finding], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    payload = [f.model_dump(mode="json") for f in ordered]
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                payload, indent=2, sort_keys=True, ensure_ascii=False, default=str,
            ) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def read_findings_json(path: str | Path) -> list[Finding]:
    source = Path(path)
    if not source.exists():
        raise StorageError(f"findings file not found: {source}")
    try:
        text = source.read_text(encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot read {source}: {exc}") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise StorageError(f"invalid JSON in {source}: {exc}") from exc
    if not isinstance(data, list):
        raise StorageError(f"findings file must contain a JSON array: {source}")
    return [Finding.model_validate(entry) for entry in data]
