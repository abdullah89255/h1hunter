"""Markdown report for findings.

Designed as a HackerOne draft: title, severity, evidence, impact, and
remediation, with an explicit statement of what has NOT been verified.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path

from h1hunter.exceptions import StorageError
from h1hunter.models.finding import Finding, SeverityLevel

__all__ = ["render_findings_markdown", "write_findings_markdown"]

_SEVERITY_ICON = {
    SeverityLevel.CRITICAL: "[CRITICAL]",
    SeverityLevel.HIGH: "[HIGH]",
    SeverityLevel.MEDIUM: "[MEDIUM]",
    SeverityLevel.LOW: "[LOW]",
    SeverityLevel.INFO: "[INFO]",
}


def render_findings_markdown(
    findings: Iterable[Finding],
    *,
    program_name: str = "unknown",
    generated_at: datetime | None = None,
) -> str:
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    when = generated_at or datetime.now(timezone.utc)
    lines: list[str] = []
    lines.append(f"# h1hunter findings — {program_name}")
    lines.append("")
    lines.append(f"_Generated {when.isoformat()} — {len(ordered)} finding(s)._")
    lines.append("")
    lines.append(
        "> **Authorization notice.** Findings are heuristic observations "
        "produced by automated checks against assets explicitly listed in the "
        "operator's scope file. Nothing here has been verified by hand unless "
        "the finding's verification status says so. Do not paste this report "
        "directly into a HackerOne submission without manual review."
    )
    lines.append("")
    if not ordered:
        lines.append("_No findings._")
        return "\n".join(lines) + "\n"
    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("| --- | --- |")
    for level in (
        SeverityLevel.CRITICAL, SeverityLevel.HIGH, SeverityLevel.MEDIUM,
        SeverityLevel.LOW, SeverityLevel.INFO,
    ):
        count = sum(1 for f in ordered if f.severity is level)
        if count:
            lines.append(f"| {level.value} | {count} |")
    lines.append("")
    for finding in ordered:
        lines.extend(_render_finding(finding))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _render_finding(finding: Finding) -> list[str]:
    lines: list[str] = []
    lines.append(f"## {_SEVERITY_ICON[finding.severity]} {finding.title}")
    lines.append("")
    lines.append(f"- **ID:** `{finding.id}`")
    lines.append(f"- **Category:** `{finding.category}`")
    lines.append(f"- **Severity:** {finding.severity.value}")
    lines.append(f"- **Confidence:** {finding.confidence.value}")
    lines.append(f"- **Verification:** {finding.verification_status.value}")
    lines.append(f"- **Detected by:** `{finding.detection_module}`")
    lines.append(f"- **Affected asset:** `{finding.affected_asset}`")
    if finding.affected_endpoint:
        lines.append(f"- **Endpoint:** `{finding.affected_endpoint}`")
    lines.append(f"- **Discovered:** {finding.discovered_at.isoformat()}")
    lines.append("")
    if finding.severity_rationale:
        lines.append("**Severity rationale.** " + finding.severity_rationale)
        lines.append("")
    if finding.potential_impact:
        lines.append("**Potential impact.** " + finding.potential_impact)
        lines.append("")
    if finding.reproduction:
        lines.append("**Reproduction.**")
        lines.append("")
        lines.append("```")
        lines.append(finding.reproduction)
        lines.append("```")
        lines.append("")
    if finding.evidence:
        lines.append("**Evidence.**")
        lines.append("")
        lines.append("```json")
        lines.append(
            json.dumps(finding.evidence, indent=2, sort_keys=True, default=str)
        )
        lines.append("```")
        lines.append("")
    if finding.remediation:
        lines.append("**Suggested remediation.** " + finding.remediation)
        lines.append("")
    return lines


def write_findings_markdown(
    findings: Iterable[Finding],
    path: str | Path,
    *,
    program_name: str = "unknown",
) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    text = render_findings_markdown(findings, program_name=program_name)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target
