"""Severity helpers.

Every severity in this toolkit is a conservative estimate. None of these
values are CVSS scores, and none of them predict a bounty outcome.
"""

from __future__ import annotations

from h1hunter.models.finding import SeverityLevel

__all__ = ["missing_header_severity", "merge_severity", "severity_order"]

_MISSING_HEADER_SEVERITY: dict[str, tuple[SeverityLevel, str]] = {
    "content-security-policy": (
        SeverityLevel.LOW,
        "CSP reduces the impact of injected content. Its absence is not "
        "exploitable on its own; impact depends on whether an injection "
        "point exists.",
    ),
    "strict-transport-security": (
        SeverityLevel.LOW,
        "HSTS prevents downgrade attacks and cookie theft on first visit. "
        "Absence requires a network-position attacker to exploit.",
    ),
    "x-content-type-options": (
        SeverityLevel.INFO,
        "X-Content-Type-Options: nosniff blocks MIME sniffing. Impact is "
        "contextual and typically secondary to another issue.",
    ),
    "referrer-policy": (
        SeverityLevel.INFO,
        "Referrer-Policy controls URL leakage to third parties. Missing "
        "policy is a privacy consideration, not a direct vulnerability.",
    ),
    "permissions-policy": (
        SeverityLevel.INFO,
        "Permissions-Policy restricts powerful browser features. Absence is "
        "informational unless a specific feature is being abused.",
    ),
}


def missing_header_severity(header_name: str) -> tuple[SeverityLevel, str]:
    key = header_name.lower()
    if key in _MISSING_HEADER_SEVERITY:
        return _MISSING_HEADER_SEVERITY[key]
    return (
        SeverityLevel.INFO,
        f"Missing {header_name} is informational without corroborating evidence.",
    )


def severity_order(level: SeverityLevel) -> int:
    return level.rank


def merge_severity(a: SeverityLevel, b: SeverityLevel) -> SeverityLevel:
    return a if a.rank >= b.rank else b
