"""CSV export for assets and findings."""

from __future__ import annotations

import csv
from collections.abc import Iterable
from pathlib import Path

from h1hunter.exceptions import StorageError
from h1hunter.models.asset import Asset
from h1hunter.models.finding import Finding

__all__ = [
    "CSV_COLUMNS", "FINDING_CSV_COLUMNS", "write_csv", "write_findings_csv",
]

CSV_COLUMNS = (
    "hostname", "domain", "source", "discovered_at", "scope_status",
    "sources", "first_seen", "last_seen", "discovery_count",
    "dns_record_types", "dns_record_count",
)

FINDING_CSV_COLUMNS = (
    "id", "title", "category", "severity", "confidence",
    "verification_status", "affected_asset", "affected_endpoint",
    "detection_module", "discovered_at", "severity_rationale", "remediation",
)


def _row(asset: Asset) -> dict[str, str]:
    meta = asset.metadata or {}
    sources = meta.get("sources") or [asset.source]
    return {
        "hostname": asset.hostname,
        "domain": asset.domain or "",
        "source": asset.source,
        "discovered_at": asset.discovered_at.isoformat(),
        "scope_status": asset.scope_status.value,
        "sources": ";".join(str(s) for s in sources),
        "first_seen": str(meta.get("first_seen", asset.discovered_at.isoformat())),
        "last_seen": str(meta.get("last_seen", asset.discovered_at.isoformat())),
        "discovery_count": str(meta.get("discovery_count", 1)),
        "dns_record_types": ";".join(sorted(asset.dns_records)),
        "dns_record_count": str(sum(len(v) for v in asset.dns_records.values())),
    }


def write_csv(assets: Iterable[Asset], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(assets, key=lambda a: a.hostname)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
            writer.writeheader()
            for asset in ordered:
                writer.writerow(_row(asset))
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target


def write_findings_csv(findings: Iterable[Finding], path: str | Path) -> Path:
    target = Path(path)
    if target.exists():
        raise StorageError(f"refusing to overwrite existing file: {target}")
    ordered = sorted(findings, key=lambda f: (-f.severity.rank, f.id))
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FINDING_CSV_COLUMNS)
            writer.writeheader()
            for finding in ordered:
                writer.writerow({
                    "id": finding.id, "title": finding.title,
                    "category": finding.category,
                    "severity": finding.severity.value,
                    "confidence": finding.confidence.value,
                    "verification_status": finding.verification_status.value,
                    "affected_asset": finding.affected_asset,
                    "affected_endpoint": finding.affected_endpoint or "",
                    "detection_module": finding.detection_module,
                    "discovered_at": finding.discovered_at.isoformat(),
                    "severity_rationale": finding.severity_rationale,
                    "remediation": finding.remediation,
                })
    except OSError as exc:
        raise StorageError(f"cannot write {target}: {exc}") from exc
    return target
