"""Exception hierarchy for h1hunter."""

from __future__ import annotations

__all__ = [
    "H1HunterError",
    "ConfigurationError",
    "ScopeError",
    "ScopeParseError",
    "ScopeViolation",
    "ScopeNotReviewedError",
    "SafetyError",
    "KillSwitchEngaged",
    "BudgetExhausted",
    "CircuitOpen",
    "DestinationBlocked",
    "PassiveSourceError",
    "StorageError",
]


class H1HunterError(Exception):
    """Base class for all h1hunter errors."""


class ConfigurationError(H1HunterError):
    """Configuration is missing, unreadable, or fails validation."""


class ScopeError(H1HunterError):
    """Base class for scope-related failures."""


class ScopeParseError(ScopeError):
    """A scope entry or scope file could not be parsed or validated."""


class ScopeViolation(ScopeError):
    """A target is not authorized by the active program scope."""


class ScopeNotReviewedError(ScopeViolation):
    """Active testing was attempted without a reviewed policy or explicit opt-in."""


class SafetyError(H1HunterError):
    """Base class for safety-control refusals."""


class KillSwitchEngaged(SafetyError):
    """The kill switch is engaged; no further requests are permitted."""


class BudgetExhausted(SafetyError):
    """The configured request budget has been exhausted."""


class CircuitOpen(SafetyError):
    """The circuit breaker is open after repeated failures."""


class DestinationBlocked(SafetyError):
    """A resolved network destination is not permitted by policy."""


class PassiveSourceError(H1HunterError):
    """A passive reconnaissance source could not be loaded or read."""


class StorageError(H1HunterError):
    """A persistence or export operation failed."""
