"""Opt-in, bounded HTTP probing.

Every request is scope-validated, budgeted, and rate-limited through the
centralized ``SafetyEngine``. Before any request is sent, the hostname is
resolved and every resolved IP is checked against the destination policy.
Redirects are re-validated hop by hop: an out-of-scope ``Location`` is
recorded and refused, never followed.

Response bodies are read incrementally and truncated at
``policy.max_response_bytes``. Sensitive headers are redacted before the
result reaches any caller. Response bodies are never persisted.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin

import httpx

from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged,
    SafetyError, ScopeViolation,
)
from h1hunter.logging_config import redact_mapping
from h1hunter.recon.dns import DnsResolverProtocol
from h1hunter.utils.normalization import is_ip_literal

__all__ = ["HttpProber", "ProbeResult", "RedirectEvent", "REDIRECT_STATUS_CODES"]

logger = logging.getLogger(__name__)

REDIRECT_STATUS_CODES = frozenset({301, 302, 303, 307, 308})
DEFAULT_MAX_REDIRECTS = 5
_PREVIEW_CHARS = 2048


@dataclass(frozen=True, slots=True)
class RedirectEvent:
    from_url: str
    to_url: str
    refused: bool = False
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class ProbeResult:
    url: str
    final_url: str
    status_code: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
    body_preview: str = ""
    body_bytes: int = 0
    truncated: bool = False
    duration_seconds: float = 0.0
    redirects: list[RedirectEvent] = field(default_factory=list)
    resolved_ips: dict[str, list[str]] = field(default_factory=dict)
    error: str | None = None


class HttpProber:
    def __init__(
        self,
        engine: SafetyEngine,
        client: httpx.AsyncClient,
        resolver: DnsResolverProtocol,
        *,
        max_redirects: int = DEFAULT_MAX_REDIRECTS,
    ) -> None:
        if max_redirects < 0:
            raise ValueError("max_redirects must be >= 0")
        self._engine = engine
        self._client = client
        self._resolver = resolver
        self._max_redirects = max_redirects

    @property
    def max_redirects(self) -> int:
        return self._max_redirects

    async def probe(self, url: str) -> ProbeResult:
        start = time.monotonic()
        current_url = url
        redirects: list[RedirectEvent] = []
        resolved_ips: dict[str, list[str]] = {}

        for _hop in range(self._max_redirects + 1):
            try:
                parsed = await self._engine.authorize(current_url)
            except (
                ScopeViolation, SafetyError, BudgetExhausted,
                CircuitOpen, KillSwitchEngaged,
            ) as exc:
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )

            try:
                ips = await self._resolve_and_check(parsed.host)
            except DestinationBlocked as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )
            except SafetyError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start, str(exc)
                )
            resolved_ips[parsed.host] = ips

            try:
                info = await self._send(current_url)
            except httpx.TimeoutException as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"timeout: {exc}",
                )
            except httpx.HTTPError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"http error: {exc}",
                )
            except OSError as exc:
                self._engine.record_failure()
                return self._failure(
                    url, current_url, redirects, resolved_ips, start,
                    f"network error: {exc}",
                )
            else:
                self._engine.record_success()

            status = info["status_code"]
            location = info["headers"].get("location")

            if status in REDIRECT_STATUS_CODES and location:
                next_url = urljoin(current_url, location)
                decision = self._engine.validator.evaluate(next_url)
                if not decision.allowed:
                    redirects.append(
                        RedirectEvent(
                            from_url=current_url, to_url=next_url,
                            refused=True, reason=decision.reason,
                        )
                    )
                    logger.info(
                        "redirect from %s to %s refused: %s",
                        current_url, next_url, decision.reason,
                    )
                    return ProbeResult(
                        url=url, final_url=current_url, status_code=status,
                        headers=info["headers"], body_preview=info["body_preview"],
                        body_bytes=info["body_bytes"], truncated=info["truncated"],
                        duration_seconds=time.monotonic() - start,
                        redirects=redirects, resolved_ips=resolved_ips,
                        error=f"redirect refused: {decision.reason}",
                    )
                redirects.append(
                    RedirectEvent(from_url=current_url, to_url=next_url)
                )
                current_url = next_url
                continue

            return ProbeResult(
                url=url, final_url=current_url, status_code=status,
                headers=info["headers"], body_preview=info["body_preview"],
                body_bytes=info["body_bytes"], truncated=info["truncated"],
                duration_seconds=time.monotonic() - start,
                redirects=redirects, resolved_ips=resolved_ips, error=None,
            )

        return self._failure(
            url, current_url, redirects, resolved_ips, start,
            f"exceeded {self._max_redirects} redirects",
        )

    async def _resolve_and_check(self, hostname: str) -> list[str]:
        if is_ip_literal(hostname):
            self._engine.check_destination(hostname)
            return [hostname]
        ips: list[str] = []
        for rtype in ("A", "AAAA"):
            try:
                answers = await self._resolver.resolve(hostname, rtype)
            except Exception as exc:  # noqa: BLE001
                logger.debug("resolve %s/%s failed: %s", hostname, rtype, exc)
                continue
            for ip in answers:
                self._engine.check_destination(ip)
                if ip not in ips:
                    ips.append(ip)
        if not ips:
            raise SafetyError(
                f"could not resolve a permitted destination for {hostname!r}"
            )
        return ips

    async def _send(self, url: str) -> dict[str, object]:
        request = self._client.build_request(
            "GET", url, timeout=self._engine.policy.timeout_seconds,
        )
        response = await self._client.send(
            request, stream=True, follow_redirects=False,
        )
        try:
            status_code = response.status_code
            raw_headers = {k: str(v) for k, v in response.headers.items()}
            headers = redact_mapping(raw_headers)
            headers = {k: str(v) for k, v in headers.items()}

            cap = self._engine.policy.max_response_bytes
            chunks: list[bytes] = []
            total = 0
            truncated = False
            async for chunk in response.aiter_bytes():
                remaining = cap - total
                if remaining <= 0:
                    truncated = True
                    break
                if len(chunk) > remaining:
                    chunks.append(chunk[:remaining])
                    total = cap
                    truncated = True
                    break
                chunks.append(chunk)
                total += len(chunk)
            body = b"".join(chunks)
            preview = _decode_preview(body)
            return {
                "status_code": status_code, "headers": headers,
                "body_preview": preview, "body_bytes": total,
                "truncated": truncated,
            }
        finally:
            await response.aclose()

    def _failure(
        self,
        original_url: str,
        current_url: str,
        redirects: list[RedirectEvent],
        resolved_ips: dict[str, list[str]],
        start: float,
        error: str,
    ) -> ProbeResult:
        return ProbeResult(
            url=original_url, final_url=current_url,
            duration_seconds=time.monotonic() - start,
            redirects=redirects, resolved_ips=resolved_ips, error=error,
        )


def _decode_preview(body: bytes) -> str:
    try:
        text = body.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return ""
    return text[:_PREVIEW_CHARS]
