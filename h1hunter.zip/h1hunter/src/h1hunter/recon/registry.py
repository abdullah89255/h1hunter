"""Build passive providers from application configuration."""

from __future__ import annotations

from collections.abc import Iterable

from h1hunter.config import PassiveSourceSettings
from h1hunter.exceptions import ConfigurationError, PassiveSourceError
from h1hunter.recon.passive import PassiveSource
from h1hunter.recon.providers import FileSource, TextSource

__all__ = ["build_source", "build_sources_from_config", "SUPPORTED_SOURCE_TYPES"]

SUPPORTED_SOURCE_TYPES = frozenset({"file", "text"})


def build_source(settings: PassiveSourceSettings) -> PassiveSource:
    options = settings.options or {}
    kind = options.get("type")
    if kind not in SUPPORTED_SOURCE_TYPES:
        raise ConfigurationError(
            f"passive source {settings.name!r} has unsupported type {kind!r}; "
            f"supported types are {sorted(SUPPORTED_SOURCE_TYPES)}"
        )
    path = options.get("path")
    if not isinstance(path, str) or not path:
        raise ConfigurationError(
            f"passive source {settings.name!r} is missing a string 'path' option"
        )
    try:
        if kind == "file":
            return FileSource(settings.name, path)
        return TextSource(settings.name, path)
    except PassiveSourceError as exc:
        raise ConfigurationError(
            f"cannot build passive source {settings.name!r}: {exc}"
        ) from exc


def build_sources_from_config(
    settings: Iterable[PassiveSourceSettings],
) -> list[PassiveSource]:
    sources: list[PassiveSource] = []
    for entry in settings:
        if not entry.enabled:
            continue
        sources.append(build_source(entry))
    return sources
