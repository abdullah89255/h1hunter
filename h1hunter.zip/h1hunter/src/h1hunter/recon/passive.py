"""Passive reconnaissance engine.

Providers are pluggable and independent. The engine:
  * runs each enabled provider, tolerating per-provider failures,
  * normalizes every discovered hostname,
  * deduplicates by hostname while keeping every source,
  * optionally annotates ``scope_status`` from a ``ScopeValidator`` for
    reporting. Annotation is *informational only*. It never authorizes a probe.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable

from h1hunter.models.asset import Asset, ScopeStatus, utcnow
from h1hunter.scope.validator import ScopeValidator
from h1hunter.utils.deduplication import deduplicate_assets

__all__ = ["PassiveReconEngine", "PassiveReconResult", "PassiveSource"]

logger = logging.getLogger(__name__)


@runtime_checkable
class PassiveSource(Protocol):
    """A provider of passively discovered assets.

    Implementations must not probe program targets. Reading local files,
    consuming pre-collected OSINT, or querying approved third-party data
    services the operator has configured are valid; sending requests to
    in-scope hosts is not.
    """
    name: str

    async def discover(self) -> list[Asset]: ...


@dataclass(frozen=True, slots=True)
class PassiveReconResult:
    assets: list[Asset]
    sources_run: list[str]
    sources_failed: list[tuple[str, str]]
    started_at: datetime
    finished_at: datetime

    @property
    def duration_seconds(self) -> float:
        return (self.finished_at - self.started_at).total_seconds()


class PassiveReconEngine:
    def __init__(
        self,
        sources: Sequence[PassiveSource],
        *,
        validator: ScopeValidator | None = None,
    ) -> None:
        self._sources = list(sources)
        self._validator = validator

    @property
    def sources(self) -> tuple[PassiveSource, ...]:
        return tuple(self._sources)

    async def run(self) -> PassiveReconResult:
        started_at = utcnow()
        collected: list[Asset] = []
        run: list[str] = []
        failed: list[tuple[str, str]] = []

        for source in self._sources:
            try:
                found = await source.discover()
            except Exception as exc:  # noqa: BLE001 - provider-isolated failure
                logger.warning("passive source %r failed: %s", source.name, exc)
                failed.append((source.name, str(exc)))
                continue
            logger.info(
                "passive source %r returned %d assets", source.name, len(found)
            )
            run.append(source.name)
            collected.extend(found)

        deduped = deduplicate_assets(collected)
        if self._validator is not None:
            deduped = [self._annotate(asset) for asset in deduped]

        return PassiveReconResult(
            assets=deduped,
            sources_run=run,
            sources_failed=failed,
            started_at=started_at,
            finished_at=utcnow(),
        )

    def _annotate(self, asset: Asset) -> Asset:
        """Attach an informational ``scope_status``. Does not authorize a probe."""
        decision = self._validator.evaluate(asset.hostname)  # type: ignore[union-attr]
        if decision.allowed:
            status = ScopeStatus.IN_SCOPE
        elif decision.matched_rule is not None:
            status = ScopeStatus.EXCLUDED
        else:
            status = ScopeStatus.OUT_OF_SCOPE
        return asset.model_copy(update={"scope_status": status})
