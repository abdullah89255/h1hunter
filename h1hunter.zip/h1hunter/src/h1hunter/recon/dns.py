"""Opt-in DNS inspection.

Every DNS query is scope-validated, budgeted, and rate-limited through the
centralized ``SafetyEngine``. DNS answers are informational only — they never
grant authorization to connect to the resolved hosts.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Protocol

import dns.asyncresolver
import dns.exception
import dns.rdatatype

from h1hunter.engine.safety import SafetyEngine
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, KillSwitchEngaged, SafetyError, ScopeViolation,
)

__all__ = [
    "DEFAULT_RECORD_TYPES", "DnsInspector", "DnsResolver",
    "DnsResolverProtocol", "DnsResult",
]

logger = logging.getLogger(__name__)

DEFAULT_RECORD_TYPES: tuple[str, ...] = ("A", "AAAA", "CNAME", "MX", "TXT", "NS")


@dataclass(frozen=True, slots=True)
class DnsResult:
    """The outcome of inspecting one hostname.

    ``skipped`` is set when the safety engine refused the query — the hostname
    was out of scope, the budget was exhausted, or the kill switch was engaged.
    ``errors`` holds per-record-type failures; a partial result still populates
    ``records`` with whatever succeeded.
    """
    hostname: str
    records: dict[str, list[str]] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)
    skipped: bool = False
    skip_reason: str | None = None


class DnsResolverProtocol(Protocol):
    """Injected resolver interface — enables deterministic tests."""

    async def resolve(self, hostname: str, record_type: str) -> list[str]: ...


class DnsResolver:
    """Real dnspython-backed resolver with bounded timeouts."""

    def __init__(self, timeout_seconds: float = 5.0) -> None:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        self._timeout = float(timeout_seconds)

    @property
    def timeout_seconds(self) -> float:
        return self._timeout

    async def resolve(self, hostname: str, record_type: str) -> list[str]:
        resolver = dns.asyncresolver.Resolver(configure=True)
        resolver.timeout = self._timeout
        resolver.lifetime = self._timeout
        try:
            answer = await resolver.resolve(hostname, record_type)
        except (
            dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers,
        ):
            return []
        except (dns.exception.DNSException, OSError) as exc:
            raise RuntimeError(
                f"DNS query failed for {hostname}/{record_type}: {exc}"
            ) from exc
        results: list[str] = []
        for rdata in answer:
            text = str(rdata)
            if record_type == "CNAME":
                text = text.rstrip(".")
            results.append(text)
        return results


class DnsInspector:
    def __init__(
        self,
        engine: SafetyEngine,
        resolver: DnsResolverProtocol,
        *,
        record_types: tuple[str, ...] = DEFAULT_RECORD_TYPES,
    ) -> None:
        self._engine = engine
        self._resolver = resolver
        self._record_types = tuple(record_types)

    @property
    def record_types(self) -> tuple[str, ...]:
        return self._record_types

    async def inspect(self, hostname: str) -> DnsResult:
        try:
            parsed = await self._engine.authorize(hostname)
        except (
            ScopeViolation, SafetyError, BudgetExhausted,
            CircuitOpen, KillSwitchEngaged,
        ) as exc:
            logger.info("DNS query for %r refused: %s", hostname, exc)
            return DnsResult(hostname=hostname, skipped=True, skip_reason=str(exc))

        records: dict[str, list[str]] = {}
        errors: dict[str, str] = {}
        for rtype in self._record_types:
            try:
                answers = await self._resolver.resolve(parsed.host, rtype)
            except Exception as exc:  # noqa: BLE001 — per-record isolation
                logger.debug("DNS %s/%s failed: %s", parsed.host, rtype, exc)
                errors[rtype] = str(exc)
                continue
            if answers:
                records[rtype] = answers
        return DnsResult(hostname=parsed.host, records=records, errors=errors)
