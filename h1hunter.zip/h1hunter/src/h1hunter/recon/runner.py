"""Bounded concurrent fan-out."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from typing import TypeVar

__all__ = ["run_concurrently"]

T = TypeVar("T")
R = TypeVar("R")


async def run_concurrently(
    items: Sequence[T],
    factory: Callable[[T], Awaitable[R]],
    limit: int,
) -> list[R]:
    """Run ``factory(item)`` for every item, at most ``limit`` at a time.

    Returns results in the same order as ``items``. Raises ``ValueError`` if
    ``limit`` < 1. Cancellation propagates.
    """
    if limit < 1:
        raise ValueError("limit must be >= 1")
    semaphore = asyncio.Semaphore(limit)

    async def one(item: T) -> R:
        async with semaphore:
            return await factory(item)

    return await asyncio.gather(*(one(item) for item in items))
