"""Newline-delimited hostname provider.

Blank lines and lines beginning with ``#`` are ignored. Comments may also
appear after a hostname if separated by ``#``. Malformed lines are skipped with
a warning; a missing file raises ``PassiveSourceError``.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from h1hunter.exceptions import PassiveSourceError
from h1hunter.models.asset import Asset
from h1hunter.utils.normalization import derive_domain, normalize_hostname

__all__ = ["TextSource"]

logger = logging.getLogger(__name__)


class TextSource:
    def __init__(self, name: str, path: str | Path) -> None:
        if not name:
            raise PassiveSourceError("TextSource requires a non-empty name")
        self.name = name
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    async def discover(self) -> list[Asset]:
        if not self._path.exists():
            raise PassiveSourceError(f"file not found: {self._path}")
        if not self._path.is_file():
            raise PassiveSourceError(f"not a file: {self._path}")
        try:
            text = self._path.read_text(encoding="utf-8")
        except OSError as exc:
            raise PassiveSourceError(f"cannot read {self._path}: {exc}") from exc
        assets: list[Asset] = []
        now = datetime.now(timezone.utc)
        for lineno, line in enumerate(text.splitlines(), start=1):
            candidate = line.split("#", 1)[0].strip()
            if not candidate:
                continue
            try:
                hostname = normalize_hostname(candidate)
            except Exception as exc:  # noqa: BLE001 - per-line isolation
                logger.warning(
                    "text source %r skipped line %d (%r): %s",
                    self.name, lineno, candidate, exc,
                )
                continue
            assets.append(
                Asset(
                    hostname=hostname, domain=derive_domain(hostname),
                    source=self.name, discovered_at=now,
                )
            )
        return assets
