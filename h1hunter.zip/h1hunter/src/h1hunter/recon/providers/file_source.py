"""JSON file provider.

Accepts either a bare list of hostnames, a list of asset objects, or an object
with an ``assets`` key containing either of those. Malformed individual entries
are logged and skipped; a missing or unreadable file raises
``PassiveSourceError``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from h1hunter.exceptions import PassiveSourceError
from h1hunter.models.asset import Asset
from h1hunter.utils.normalization import derive_domain, normalize_hostname

__all__ = ["FileSource"]

logger = logging.getLogger(__name__)


class FileSource:
    def __init__(self, name: str, path: str | Path) -> None:
        if not name:
            raise PassiveSourceError("FileSource requires a non-empty name")
        self.name = name
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    async def discover(self) -> list[Asset]:
        if not self._path.exists():
            raise PassiveSourceError(f"file not found: {self._path}")
        if not self._path.is_file():
            raise PassiveSourceError(f"not a file: {self._path}")
        try:
            text = self._path.read_text(encoding="utf-8")
        except OSError as exc:
            raise PassiveSourceError(f"cannot read {self._path}: {exc}") from exc
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise PassiveSourceError(f"invalid JSON in {self._path}: {exc}") from exc
        entries = self._extract_entries(data)
        assets: list[Asset] = []
        for index, entry in enumerate(entries):
            asset = self._build_asset(entry, index)
            if asset is not None:
                assets.append(asset)
        return assets

    @staticmethod
    def _extract_entries(data: Any) -> list[Any]:
        if isinstance(data, dict) and "assets" in data:
            inner = data["assets"]
            if not isinstance(inner, list):
                raise PassiveSourceError("'assets' key must contain a list")
            return inner
        if isinstance(data, list):
            return data
        raise PassiveSourceError("JSON must be a list or an object with an 'assets' key")

    def _build_asset(self, entry: Any, index: int) -> Asset | None:
        try:
            if isinstance(entry, str):
                hostname = normalize_hostname(entry)
                return Asset(
                    hostname=hostname, domain=derive_domain(hostname),
                    source=self.name,
                    discovered_at=datetime.now(timezone.utc),
                )
            if isinstance(entry, dict):
                raw_host = entry.get("hostname")
                if not isinstance(raw_host, str) or not raw_host:
                    raise ValueError("missing or invalid 'hostname'")
                hostname = normalize_hostname(raw_host)
                discovered_at = self._parse_timestamp(entry.get("discovered_at"))
                metadata = entry.get("metadata") or {}
                if not isinstance(metadata, dict):
                    raise ValueError("'metadata' must be an object")
                dns_records = entry.get("dns_records") or {}
                if not isinstance(dns_records, dict):
                    raise ValueError("'dns_records' must be an object")
                return Asset(
                    hostname=hostname,
                    domain=entry.get("domain") or derive_domain(hostname),
                    source=self.name, discovered_at=discovered_at,
                    dns_records=dns_records, metadata=metadata,
                )
        except Exception as exc:  # noqa: BLE001 - per-entry isolation
            logger.warning(
                "file source %r skipped entry %d: %s", self.name, index, exc,
            )
            return None
        logger.warning(
            "file source %r skipped entry %d: unsupported type %s",
            self.name, index, type(entry).__name__,
        )
        return None

    @staticmethod
    def _parse_timestamp(value: Any) -> datetime:
        if value is None:
            return datetime.now(timezone.utc)
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        if isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError(f"invalid timestamp {value!r}") from exc
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        raise ValueError(f"unsupported timestamp type: {type(value).__name__}")
