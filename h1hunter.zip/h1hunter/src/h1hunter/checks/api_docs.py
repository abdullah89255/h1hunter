"""API documentation discovery.

Checks a small set of conventional API-documentation locations. Discovery is
reported as informational. Presence of documentation is not a vulnerability.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["API_DOC_PATHS", "ApiDocsCheck"]

logger = logging.getLogger(__name__)

API_DOC_PATHS: tuple[str, ...] = (
    "/swagger.json", "/openapi.json", "/api-docs",
    "/swagger-ui.html", "/.well-known/openapi.json",
)


class ApiDocsCheck:
    name = "api_docs"
    category = "api_documentation"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        findings: list[Finding] = []
        base = target.rstrip("/")
        for path in API_DOC_PATHS:
            url = f"{base}{path}"
            result = await self._prober.probe(url)
            if result.status_code is None or result.status_code >= 400:
                continue
            findings.append(_finding_for(self, url, result))
        return findings


def _finding_for(check: ApiDocsCheck, url: str, result: ProbeResult) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="api_docs_reachable", asset=url, endpoint=url,
        ),
        title=f"Publicly reachable API documentation: {url}",
        category="api_docs_reachable",
        affected_asset=url,
        affected_endpoint=url,
        detection_module=check.name,
        evidence={
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "content_length": result.headers.get("content-length"),
            "body_bytes": result.body_bytes,
        },
        reproduction=(
            f"Request {url} as an unauthenticated client and observe the "
            "status code."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.INFO,
        severity_rationale=(
            "Publicly reachable API documentation is common and usually "
            "intended. It is informational because it may aid reconnaissance "
            "but is not a vulnerability on its own."
        ),
        potential_impact=(
            "Documentation may reveal endpoint names, parameters, or auth "
            "flows. Only meaningful when combined with an authorization flaw."
        ),
        remediation=(
            "Confirm that public documentation is intended. If not, restrict "
            "access at the edge or require authentication."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.UNVERIFIED,
    )
