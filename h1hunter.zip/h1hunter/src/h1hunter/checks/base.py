"""Shared interfaces for check modules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import httpx

from h1hunter.engine.safety import SafetyEngine
from h1hunter.models.finding import Finding
from h1hunter.recon.dns import DnsResolverProtocol

__all__ = ["CheckContext", "CheckProtocol"]


@dataclass(frozen=True, slots=True)
class CheckContext:
    """Everything a check needs to run one target."""
    engine: SafetyEngine
    client: httpx.AsyncClient
    resolver: DnsResolverProtocol


class CheckProtocol(Protocol):
    """A security check module."""
    name: str
    category: str

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        """Return findings for ``target``. Must not raise on ordinary failures."""
        ...
