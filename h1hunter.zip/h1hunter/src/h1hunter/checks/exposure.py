"""Limited public-exposure checks.

Only a small, fixed allowlist of paths is requested. Response bodies are
NEVER stored. Evidence records only the HTTP status, content type, and
content length.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["EXPOSURE_PATHS", "ExposureCheck"]

logger = logging.getLogger(__name__)

EXPOSURE_PATHS: tuple[tuple[str, str, SeverityLevel], ...] = (
    ("/.well-known/security.txt", "expected", SeverityLevel.INFO),
    ("/robots.txt", "informational", SeverityLevel.INFO),
    ("/.env", "sensitive_file", SeverityLevel.MEDIUM),
    ("/.git/HEAD", "sensitive_file", SeverityLevel.MEDIUM),
    ("/.well-known/change-password", "informational", SeverityLevel.INFO),
)


class ExposureCheck:
    name = "exposure"
    category = "public_exposure"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        findings: list[Finding] = []
        base = target.rstrip("/")
        for path, kind, severity in EXPOSURE_PATHS:
            url = f"{base}{path}"
            result = await self._prober.probe(url)
            if result.status_code is None or result.status_code >= 400:
                continue
            if kind == "expected":
                continue
            findings.append(_finding_for(self, url, kind, severity, result))
        return findings


def _finding_for(
    check: ExposureCheck, url: str, kind: str,
    severity: SeverityLevel, result: ProbeResult,
) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category=f"exposed:{kind}", asset=url, endpoint=url,
        ),
        title=f"Publicly reachable path: {url}",
        category=f"exposed:{kind}",
        affected_asset=url,
        affected_endpoint=url,
        detection_module=check.name,
        evidence={
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "content_length": result.headers.get("content-length"),
            "body_bytes": result.body_bytes,
            "truncated": result.truncated,
        },
        reproduction=(
            f"Request {url} as an unauthenticated client and observe the "
            "status code. Do not exfiltrate any body content."
        ),
        confidence=ConfidenceLevel.LOW,
        severity=severity,
        severity_rationale=(
            "A reachable path is not proof of a vulnerability. Impact depends "
            "on whether the resource is intended to be public and whether it "
            "contains sensitive data. Manual verification is required."
        ),
        potential_impact=(
            "If the resource contains configuration, secrets, or source "
            "history, exposure could assist an attacker. This check does not "
            "download or verify any content."
        ),
        remediation=(
            "Confirm whether the path is intended to be public. If not, "
            "remove it from the web root or restrict access at the edge."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )
