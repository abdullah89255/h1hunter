"""Harmless input reflection check.

A unique random marker string is inserted into one URL query parameter the
researcher has explicitly designated as a reflection test point. The response
is fetched through the SafetyEngine and inspected for the marker. No script,
no payload, no server-side code execution is attempted.

The finding explicitly states that reflection alone is NOT XSS.
"""

from __future__ import annotations

import logging
import secrets
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult

__all__ = ["ReflectionCheck"]

logger = logging.getLogger(__name__)


class ReflectionCheck:
    name = "reflection"
    category = "input_reflection"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        marker = _new_marker()
        injected_url = _inject_marker(target, marker)
        if injected_url is None:
            logger.info("reflection check skipped %s: no query parameters", target)
            return []

        result = await self._prober.probe(injected_url)
        if result.status_code is None or result.error is not None:
            return []
        if marker not in result.body_preview:
            return []
        return [_reflection_finding(self, target, injected_url, marker, result)]


def _new_marker() -> str:
    return "h1h" + secrets.token_hex(6)


def _inject_marker(url: str, marker: str) -> str | None:
    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    if not pairs:
        return None
    name, _ = pairs[0]
    new_pairs = [(name, marker)] + pairs[1:]
    return urlunsplit(
        (parts.scheme, parts.netloc, parts.path, urlencode(new_pairs), parts.fragment)
    )


def _reflection_finding(
    check: ReflectionCheck, target: str, injected_url: str,
    marker: str, result: ProbeResult,
) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="marker_reflected",
            asset=target, endpoint=injected_url,
        ),
        title="Marker string reflected in response body",
        category="marker_reflected",
        affected_asset=target,
        affected_endpoint=injected_url,
        detection_module=check.name,
        evidence={
            "marker": marker,
            "status_code": result.status_code,
            "content_type": result.headers.get("content-type"),
            "reflected": True,
        },
        reproduction=(
            f"Request {injected_url} and search the response body for the "
            f"marker {marker!r}. The marker is reflected."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.INFO,
        severity_rationale=(
            "Reflection alone is NOT cross-site scripting. Whether the "
            "reflection is exploitable depends on the execution context, "
            "encoding, and content type. Manual verification is required."
        ),
        potential_impact=(
            "If the reflection occurs in an executable context without "
            "appropriate encoding, it may be exploitable as XSS. In JSON, "
            "plain text, or properly encoded HTML, impact is low or none."
        ),
        remediation=(
            "Confirm the reflection is intentional. Contextually encode all "
            "output and add a Content-Security-Policy that would prevent "
            "script execution."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )
