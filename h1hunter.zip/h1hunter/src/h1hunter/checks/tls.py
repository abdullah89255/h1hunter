"""TLS certificate and protocol inspection.

The check authorizes the target through the SafetyEngine, enforces the
destination policy, and then delegates the handshake to an injectable
``TlsProbe``. Certificate verification is ENABLED by default. Tests inject a
stub probe so no real socket is opened.
"""

from __future__ import annotations

import asyncio
import logging
import socket
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol

from h1hunter.checks.base import CheckContext
from h1hunter.exceptions import (
    BudgetExhausted, CircuitOpen, DestinationBlocked, KillSwitchEngaged,
    SafetyError, ScopeViolation,
)
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, SeverityLevel, VerificationStatus,
)
from h1hunter.utils.normalization import ParsedTarget

__all__ = ["SocketTlsProbe", "TlsCheck", "TlsProbe", "TlsResult"]

logger = logging.getLogger(__name__)

_EXPIRY_WARN_DAYS = 30
_WEAK_PROTOCOLS = frozenset({"TLSv1", "TLSv1.1", "SSLv3"})


@dataclass(frozen=True, slots=True)
class TlsResult:
    host: str
    port: int
    subject: str | None = None
    issuer: str | None = None
    not_before: datetime | None = None
    not_after: datetime | None = None
    protocol: str | None = None
    cipher: str | None = None
    error: str | None = None


class TlsProbe(Protocol):
    async def inspect(self, host: str, port: int, timeout: float) -> TlsResult: ...


class SocketTlsProbe:
    """Real TLS probe using Python's ``ssl`` module.

    Certificate verification is enabled by default.
    """

    def __init__(self, *, verify: bool = True) -> None:
        self._verify = verify

    async def inspect(self, host: str, port: int, timeout: float) -> TlsResult:
        return await asyncio.get_running_loop().run_in_executor(
            None, self._inspect_sync, host, port, timeout
        )

    def _inspect_sync(self, host: str, port: int, timeout: float) -> TlsResult:
        context = ssl.create_default_context()
        if not self._verify:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        try:
            with socket.create_connection((host, port), timeout=timeout) as raw:
                with context.wrap_socket(raw, server_hostname=host) as tls:
                    cert = tls.getpeercert()
                    cipher = tls.cipher()
                    return TlsResult(
                        host=host, port=port,
                        subject=_format_name(cert.get("subject")),
                        issuer=_format_name(cert.get("issuer")),
                        not_before=_parse_cert_time(cert.get("notBefore")),
                        not_after=_parse_cert_time(cert.get("notAfter")),
                        protocol=tls.version(),
                        cipher=cipher[0] if cipher else None,
                    )
        except (ssl.SSLError, socket.error, OSError) as exc:
            return TlsResult(host=host, port=port, error=str(exc))


def _format_name(entries) -> str | None:
    if not entries:
        return None
    parts: list[str] = []
    for rdn in entries:
        for key, value in rdn:
            parts.append(f"{key}={value}")
    return ", ".join(parts) if parts else None


def _parse_cert_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.strptime(value, "%b %d %H:%M:%S %Y %Z")
    except ValueError:
        return None
    return parsed.replace(tzinfo=timezone.utc)


class TlsCheck:
    name = "tls"
    category = "tls"

    def __init__(self, probe: TlsProbe) -> None:
        self._probe = probe

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        try:
            parsed = await context.engine.authorize(target)
        except (
            ScopeViolation, SafetyError, BudgetExhausted,
            CircuitOpen, KillSwitchEngaged,
        ) as exc:
            logger.info("tls check skipped %s: %s", target, exc)
            return []

        scheme, host, port = _scheme_host_port(parsed)
        if scheme != "https":
            logger.info("tls check skipped %s: not an https target", target)
            return []

        try:
            await _enforce_destination(context, host)
        except (DestinationBlocked, SafetyError) as exc:
            logger.info("tls check refused %s: %s", host, exc)
            return []

        result = await self._probe.inspect(
            host, port, timeout=context.engine.policy.timeout_seconds
        )
        if result.error is not None:
            return [_error_finding(self, target, result)]
        return _lifetime_findings(self, target, result)


def _scheme_host_port(parsed: ParsedTarget) -> tuple[str, str, int]:
    scheme = parsed.scheme or "https"
    port = parsed.port or (443 if scheme == "https" else 80)
    return scheme, parsed.host, port


async def _enforce_destination(context: CheckContext, host: str) -> None:
    seen = False
    for rtype in ("A", "AAAA"):
        try:
            answers = await context.resolver.resolve(host, rtype)
        except Exception:  # noqa: BLE001
            continue
        for ip in answers:
            context.engine.check_destination(ip)
            seen = True
    if not seen:
        context.engine.check_destination(host)


def _error_finding(check: TlsCheck, target: str, result: TlsResult) -> Finding:
    return Finding(
        id=Finding.make_id(
            module=check.name, category="tls_error", asset=target, endpoint=None,
        ),
        title="TLS handshake or certificate verification failed",
        category="tls_error",
        affected_asset=target,
        affected_endpoint=f"{result.host}:{result.port}",
        detection_module=check.name,
        evidence={"host": result.host, "port": result.port, "error": result.error},
        reproduction=(
            f"Connect to {result.host}:{result.port} with certificate "
            "verification enabled. The handshake fails."
        ),
        confidence=ConfidenceLevel.MEDIUM,
        severity=SeverityLevel.MEDIUM,
        severity_rationale=(
            "A failed TLS handshake prevents secure use of the endpoint. "
            "Exploitability depends on how the service is reached."
        ),
        potential_impact=(
            "Clients may be unable to establish a secure connection, or may "
            "fail closed and refuse the service."
        ),
        remediation=(
            "Renew or replace the certificate and ensure the full chain is "
            "served. Do not disable client verification to work around it."
        ),
        scope_validation="in_scope",
        verification_status=VerificationStatus.REQUIRES_INVESTIGATION,
    )


def _lifetime_findings(check: TlsCheck, target: str, result: TlsResult) -> list[Finding]:
    findings: list[Finding] = []
    now = datetime.now(timezone.utc)

    if result.not_after is not None:
        remaining = (result.not_after - now).days
        if remaining <= 0:
            findings.append(
                _expiry_finding(check, target, result, remaining, expired=True)
            )
        elif remaining <= _EXPIRY_WARN_DAYS:
            findings.append(
                _expiry_finding(check, target, result, remaining, expired=False)
            )

    if result.protocol is not None and result.protocol in _WEAK_PROTOCOLS:
        findings.append(
            Finding(
                id=Finding.make_id(
                    module=check.name, category="tls_weak_protocol",
                    asset=target, endpoint=f"{result.host}:{result.port}",
                ),
                title=f"Deprecated TLS protocol negotiated: {result.protocol}",
                category="tls_weak_protocol",
                affected_asset=target,
                affected_endpoint=f"{result.host}:{result.port}",
                detection_module=check.name,
                evidence={"protocol": result.protocol, "cipher": result.cipher},
                reproduction=(
                    f"Connect to {result.host}:{result.port} and read the "
                    "negotiated protocol version."
                ),
                confidence=ConfidenceLevel.HIGH,
                severity=SeverityLevel.LOW,
                severity_rationale=(
                    "Deprecated TLS versions are weaker than TLS 1.2+. "
                    "Exploitation requires a network-position attacker."
                ),
                potential_impact=(
                    "Traffic may be recoverable or downgradeable by an "
                    "attacker positioned on the network path."
                ),
                remediation=(
                    "Disable TLS 1.0/1.1 and SSLv3; require TLS 1.2 or later."
                ),
                scope_validation="in_scope",
                verification_status=VerificationStatus.UNVERIFIED,
            )
        )
    return findings


def _expiry_finding(
    check: TlsCheck, target: str, result: TlsResult, remaining_days: int,
    *, expired: bool,
) -> Finding:
    category = "tls_certificate_expired" if expired else "tls_certificate_expiring"
    title = (
        "TLS certificate is expired" if expired
        else f"TLS certificate expires in {remaining_days} day(s)"
    )
    severity = SeverityLevel.MEDIUM if expired else SeverityLevel.LOW
    rationale = (
        "An expired certificate causes clients to fail closed. Impact is "
        "availability and trust, not direct compromise."
        if expired
        else "Imminent expiry will cause a service outage if not renewed."
    )
    return Finding(
        id=Finding.make_id(
            module=check.name, category=category, asset=target,
            endpoint=f"{result.host}:{result.port}",
        ),
        title=title,
        category=category,
        affected_asset=target,
        affected_endpoint=f"{result.host}:{result.port}",
        detection_module=check.name,
        evidence={
            "host": result.host, "port": result.port,
            "not_after": result.not_after.isoformat() if result.not_after else None,
            "subject": result.subject, "issuer": result.issuer,
            "days_remaining": remaining_days,
        },
        reproduction=f"Inspect the certificate served by {result.host}:{result.port}.",
        confidence=ConfidenceLevel.HIGH,
        severity=severity,
        severity_rationale=rationale,
        potential_impact=(
            "Clients will refuse to connect or users will see security "
            "warnings. Availability impact only."
        ),
        remediation="Renew the certificate before it expires.",
        scope_validation="in_scope",
        verification_status=VerificationStatus.UNVERIFIED,
    )
