"""HTTP security header inspection.

Missing headers are reported with contextual severity. A missing header is
never classified as a vulnerability on its own.
"""

from __future__ import annotations

import logging

from h1hunter.checks.base import CheckContext
from h1hunter.models.finding import (
    ConfidenceLevel, Finding, VerificationStatus,
)
from h1hunter.recon.http_probe import HttpProber, ProbeResult
from h1hunter.reporting.severity import missing_header_severity

__all__ = ["INSPECTED_HEADERS", "HeadersCheck"]

logger = logging.getLogger(__name__)

INSPECTED_HEADERS: tuple[str, ...] = (
    "content-security-policy",
    "strict-transport-security",
    "x-content-type-options",
    "referrer-policy",
    "permissions-policy",
)


class HeadersCheck:
    name = "headers"
    category = "security_headers"

    def __init__(self, prober: HttpProber) -> None:
        self._prober = prober

    async def run(self, target: str, context: CheckContext) -> list[Finding]:
        result = await self._prober.probe(target)
        if result.error is not None or result.status_code is None:
            logger.info("headers check skipped %s: %s", target, result.error)
            return []
        return _findings_from_probe(self, result)


def _findings_from_probe(check: HeadersCheck, result: ProbeResult) -> list[Finding]:
    findings: list[Finding] = []
    present = {k.lower() for k in result.headers}

    for header in INSPECTED_HEADERS:
        if header in present:
            continue
        if header == "strict-transport-security" and not result.final_url.startswith(
            "https://"
        ):
            continue

        severity, rationale = missing_header_severity(header)
        findings.append(
            Finding(
                id=Finding.make_id(
                    module=check.name,
                    category=f"missing_header:{header}",
                    asset=result.final_url,
                    endpoint=header,
                ),
                title=f"Missing security header: {header}",
                category=f"missing_header:{header}",
                affected_asset=result.final_url,
                affected_endpoint=header,
                detection_module=check.name,
                evidence={
                    "status_code": result.status_code,
                    "checked_headers": sorted(present),
                    "missing_header": header,
                    "response_bytes": result.body_bytes,
                },
                reproduction=(
                    f"GET {result.final_url} and inspect the response headers. "
                    f"The '{header}' header is not present."
                ),
                confidence=ConfidenceLevel.HIGH,
                severity=severity,
                severity_rationale=rationale,
                potential_impact=(
                    "Impact depends on the surrounding application and on "
                    "whether a separate injection or downgrade vector exists."
                ),
                remediation=f"Add an appropriate '{header}' response header.",
                scope_validation="in_scope",
                verification_status=VerificationStatus.UNVERIFIED,
            )
        )
    return findings
