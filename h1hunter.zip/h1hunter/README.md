# h1hunter

Safe-by-default reconnaissance and low-impact check toolkit for authorized
HackerOne bug bounty programs.

## Phases

- **Phase 1** — scope enforcement, safety engine, dry-run planning.
- **Phase 2** — passive reconnaissance (local files only), asset storage, JSON/CSV export.
- **Phase 3** — opt-in DNS inspection and HTTP probing with redirect re-validation,
  size caps, concurrency limits, request budgets, cancellation, kill switch.
- **Phase 4** — security-header, TLS, exposure, API-docs, and reflection checks;
  normalized finding model; deduplication; JSON/CSV/Markdown reports.

## Requirements

- Python 3.12+

## Install

### Linux / macOS

    python3.12 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

### Windows PowerShell

    py -3.12 -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

### Windows Command Prompt

    py -3.12 -m venv .venv
    .venv\Scripts\activate.bat
    python -m pip install --upgrade pip
    python -m pip install -e ".[dev]"

## Configure

    cp config/config.example.yaml config/config.yaml
    cp config/scope.example.yaml  config/scope.yaml

Edit `config/scope.yaml` and replace every placeholder with assets you are
authorized to test. Set `program.policy_reviewed: true` only after reading the
current program policy. Active testing also requires `settings.active_checks: true`.

## Commands

    h1hunter version
    h1hunter scope validate --file config/scope.yaml
    h1hunter scope check    --file config/scope.yaml --target https://api.example.net/v1
    h1hunter plan           --file config/scope.yaml --targets example.com attacker.test

    h1hunter recon passive  --file config/scope.yaml --config config/config.yaml \
                            --output output/passive.json --db output/assets.db
    h1hunter recon dns      --file config/scope.yaml --targets-file data/hosts.txt --dry-run
    h1hunter recon probe    --file config/scope.yaml --targets-file data/urls.txt  --dry-run

    h1hunter check headers  --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check tls      --file config/scope.yaml --targets-file data/hosts.txt --dry-run
    h1hunter check exposure --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check api-docs --file config/scope.yaml --targets-file data/urls.txt --dry-run
    h1hunter check reflection --file config/scope.yaml \
                              --target "https://www.example.com/search?q=x" --dry-run

    h1hunter report --input output/headers.json --format markdown --output output/headers.md

## Tests

    pytest -q                # full suite
    pytest -q -m safety      # safety regression suite only

Every test uses `httpx.MockTransport`, stub resolvers, or stub TLS probes.
No test opens a socket.

## Authorization

Authorization depends on the current program policy, not on domain ownership and
not on whether a host responds to a probe. Never scan a target you are not
explicitly permitted to test.
